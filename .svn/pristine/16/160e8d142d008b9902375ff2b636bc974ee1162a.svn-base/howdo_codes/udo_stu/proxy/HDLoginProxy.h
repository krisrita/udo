//
//  HDLoginProxy.h
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

typedef void (^HDLoginBlockBack)(HDCommonResult *result);
typedef void (^HDLoginOutBlockBack)(HDCommonResult *result);


#import <Foundation/Foundation.h>

@interface HDLoginProxy : NSObject

+ (instancetype)sharedInstance;

-(void)loginWithContext:(UIViewController *)vc result:(HDLoginBlockBack)block;

-(void)logout;

@end
