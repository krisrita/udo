//
//  HDPractiseProxy.h
//  udo_stu
//
//  Created by nobody on 6/16/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDPractiseProxy : NSObject

+ (instancetype)sharedInstance;

// 做练习
- (void)doPractise:(UIViewController *)viewController practiseType:(HDPractiseType)practiseType chapterOrSection:(id)chapterOrSection;

// 显示答题报告
- (void)showPractiseReport:(UIViewController *)viewController practiseType:(HDPractiseType)practiseType chapterOrSection:(id)chapterOrSection;

@end
