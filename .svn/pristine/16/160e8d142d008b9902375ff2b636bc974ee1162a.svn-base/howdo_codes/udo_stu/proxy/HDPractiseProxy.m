//
//  HDPractiseProxy.m
//  udo_stu
//
//  Created by nobody on 6/16/15.
//  All rights reserved.
//

#import "HDPractiseProxy.h"
#import "HDPractiseViewController.h"
#import "HDAnswerReportViewController.h"
#import "HDPractiseController.h"

@implementation HDPractiseProxy

+ (instancetype)sharedInstance
{
    static HDPractiseProxy * shareInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        shareInstance = [[self alloc] init];
    });
    return shareInstance;
}

- (void)doPractise:(UIViewController *)viewController practiseType:(HDPractiseType)practiseType chapterOrSection:(id)chapterOrSection
{
    if ([self getPractiseNum:chapterOrSection] <= 0) {
        [HDLoading startAnimating:@"暂无练习，敬请期待"];
        [HDLoading stopAnimating:@"暂无练习，敬请期待"];
        return;
    }
    
    if (HD_PRACTISE_TYPE_CHAPTER == practiseType) {
        HDChapterModel *model = (HDChapterModel *)chapterOrSection;
        if (model.hasPracticed) {
            [self showPractiseReport:viewController practiseType:practiseType chapterOrSection:model];
            return;
        }
    }
    else if (HD_PRACTISE_TYPE_SECTION == practiseType) {
        HDSectionModel *model = (HDSectionModel *)chapterOrSection;
        if (model.hasPracticed) {
            [self showPractiseReport:viewController practiseType:practiseType chapterOrSection:model];
            return;
        }
    }
    
    
    if (practiseType == HD_PRACTISE_TYPE_SECTION) {
        // MYTODO
        HDPractiseController *practise = [[HDPractiseController alloc] init];
        practise.practiseType = HD_PRACTISE_TYPE_SECTION;
        practise.sectionModel = chapterOrSection;
        [viewController.navigationController pushViewController:practise animated:YES];
        return;
    }

    HDPractiseViewController *practiseViewController = [[HDPractiseViewController alloc]init];
    practiseViewController.practiseType = practiseType;
    practiseViewController.chapterOrSectionModel = chapterOrSection;
    [viewController.navigationController pushViewController:practiseViewController animated:YES];
}

- (void)showPractiseReport:(UIViewController *)viewController practiseType:(HDPractiseType)practiseType chapterOrSection:(id)chapterOrSection
{
    [HDLoading startAnimating:@"正在获取答题报告..."];
    NSInteger chapterOrSectionId = [self getChapterOrSectionId:chapterOrSection];
    [[HDManager sharedInstance].courseService getPractiseReport:chapterOrSectionId resultBack:^(HDServiceResult *result, id object) {
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            if (object && [object isKindOfClass:[HDPractiseReportModel class]]) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [HDLoading stopAnimating];
                    HDAnswerReportViewController *answerReportViewController = [[HDAnswerReportViewController alloc] init];
                    answerReportViewController.practiseType = practiseType;
                    answerReportViewController.practiseReportModel = object;
                    answerReportViewController.chapterOrSectionModel = chapterOrSection;
                    [viewController.navigationController pushViewController:answerReportViewController animated:YES];

                });
            }
        }
        else {
            [result show];
        }
        [HDLoading stopAnimating];
    }];
}

- (NSInteger)getChapterOrSectionId:(id)chapterOrSectionModel
{
    NSInteger Id = 0;
    
    if (chapterOrSectionModel) {
        if ([chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)chapterOrSectionModel;
            Id = chapter.Id;
        }
        else if ([chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)chapterOrSectionModel;
            Id = section.Id;
        }
    }
    
    return Id;
}

- (NSInteger)getPractiseNum:(id)chapterOrSectionModel
{
    NSInteger practiseNum = 0;
    
    if (chapterOrSectionModel) {
        if ([chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)chapterOrSectionModel;
            practiseNum = chapter.practiseNum;
        }
        else if ([chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)chapterOrSectionModel;
            practiseNum = section.practiseNum;
        }
    }
    
    return practiseNum;
}

@end
