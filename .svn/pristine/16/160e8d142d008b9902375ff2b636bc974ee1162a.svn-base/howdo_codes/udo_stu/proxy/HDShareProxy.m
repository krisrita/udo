//
//  MCShareProxy.m
//
//  Created by nobody on 14-2-21.
//  . All rights reserved.
//

#import "HDShareProxy.h"
#import "HDShareView.h"
//#import "MCWaiting.h"
#import "HDLoginViewController.h"
@interface HDShareProxy()
{
    NSInteger tag;
}

@property (nonatomic,strong) NSString * shareTitle;
@property (nonatomic,strong) NSString * shareText;
@property (nonatomic,strong) NSString * shareImgUrl;
@property (nonatomic,strong) NSString * shareUrl;
@property (nonatomic,strong) UIViewController * controller;
@property (nonatomic,strong) HDShareBackBlock shareBlock;
@property (nonatomic,strong) UIImage * shareImg;
@property (nonatomic,strong) HDViewPoped dismiss;
@end



@implementation HDShareProxy

+ (instancetype)sharedInstance
{
    static HDShareProxy * shareInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        shareInstance = [[self alloc] init];
    });
    return shareInstance;
}


-(void)share:(UIViewController *)viewController
       title:(NSString *)shareTitle
        text:(NSString *)shareText
    imageUrl:(NSString *)shareImageUrl
       image:(UIImage *)image
 resourceUrl:(NSString *)shareUrl
  completion:(HDShareBackBlock)completion
   viewPoped:(MCShareViewPoped)popedBlock
viewDissMissed:(MCShareViewDismissed)dismissedBlock
{
        self.shareTitle = shareTitle;
        self.shareText = shareText;
        self.shareImgUrl = shareImageUrl;
        self.shareUrl = shareUrl;
        self.controller = viewController;
        self.shareBlock = completion;
        self.shareImg = image;
        self.dismiss = dismissedBlock;
        HDShareView *shareView = [[HDShareView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, 112)];
        shareView.delegate = self;
        BSbottomModel *model = [BSbottomModel sharedInstance];
        model.backgroundDisplayStyle = BSModalBackgroundDisplayStyleSolid;
        model.showCloseButton = NO;
        [[BSbottomModel sharedInstance] showWithContentView:shareView
                                                andAnimated:YES
                                                  showBlock:popedBlock
                                               dismissBlock:^{
            self.controller = nil;
            if (self.dismiss) {
                self.dismiss();
            }
            self.dismiss = nil;
        }];
}


-(void)shareViewBtnClick:(UIButton *)btn
{
    tag = btn.tag;

    [[BSbottomModel sharedInstance]hideAnimated:NO dismissBlock:^{
        [[HDShareData sharedInstance] share:btn.tag
                                     tittle:self.shareTitle
                                       test:self.shareText
                                      image:self.shareImg
                                   imageUrl:self.shareImgUrl
                                resourceUrl:self.shareUrl
//                           parentcontroller:[[[UIApplication sharedApplication] keyWindow]rootViewController]
                           parentcontroller:self.controller
                                 completion:^(HDCommonResult *result) {
                                     if (result.resultCode == HD_RESULT_CODE_FAILURE)
                                     {
//                                        [MCTip showSystemAlartTitle:@"提示" message:result.resultDesc];
                                     }
                                     if (self.shareBlock)
                                     {
                                         self.shareBlock(result);
                                         self.shareBlock = nil;
                                     }
                                 }];
        self.controller = nil;
        self.dismiss = nil;
    }];
}


@end
