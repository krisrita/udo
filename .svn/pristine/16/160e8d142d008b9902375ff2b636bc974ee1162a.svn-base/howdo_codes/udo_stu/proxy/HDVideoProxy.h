//
//  HDVideoProxy.h
//  udo_stu
//
//  Created by nobody on 6/20/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDVideoProxy : NSObject

+ (instancetype)sharedInstance;

- (void)showVideo:(UIViewController *)viewController chapterOrSectionModel:(id)chapterOrSectionModel answerModel:(id)answerModel;

@end
