//
//  HDLoginProxy.m
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#import "HDLoginProxy.h"
#import "HDGuideViewController.h"
#import "HDLoginDefine.h"

@interface HDLoginProxy ()

@property(nonatomic,copy)HDLoginBlockBack loginBlock;

@end

@implementation HDLoginProxy

+ (instancetype)sharedInstance
{
    static HDLoginProxy *instance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        instance = [[self alloc] init];
        [[NSNotificationCenter defaultCenter]addObserver:instance selector:@selector(loginSuccess) name:NOTIFICATION_LOGIN_SUCCESS object:nil];
    });
    return instance;
}
-(void)loginWithContext:(UIViewController *)vc result:(HDLoginBlockBack)block
{
    if (![[HDManager sharedInstance]isLogined])
    {
        self.loginBlock = block;
        HDGuideViewController * guide = [[HDGuideViewController alloc]init];
        MLNavigationController * guideNav =[[MLNavigationController alloc]initWithRootViewController: guide];
        guideNav.hidesBottomBarWhenPushed = YES;
        guideNav.navigationBarHidden = YES;
        [vc presentViewController:guideNav animated:NO completion:NULL];
    }
    else
    {
        if (block)
        {
            block([HDCommonResult resultWithData:HD_RESULT_CODE_SUCCESS resultDesc:@""]);
        }
    }
    
}

-(void)loginSuccess
{
    if (self.loginBlock)
    {
        self.loginBlock([HDCommonResult resultWithData:HD_RESULT_CODE_SUCCESS resultDesc:@""]);
        self.loginBlock = nil;
    }
}

-(void)logout
{
    
    [[HDManager sharedInstance] setCurrentUser:nil];

}
@end
