//
//  MCShareProxy.h
//
//  Created by nobody on 14-2-21.
//  . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDShareView.h"
#import "BSbottomModel.h"
#import "HDShareData.h"
@interface HDShareProxy : NSObject <ShareViewBtnClickDelegate>

+ (instancetype)sharedInstance;

/**
 *  直接调用此方法分享 返回结果在competion中
 *
 *  @param shareType  分享类型
 *  @param shareType  分享标题
 *  @param shareText  文字
 *  @param shareImage 图片
 *  @param shareImageUrl 图片地址
 *  @param shareUrl   链接
 *  @param viewcontroller （必须在放在navigationcontroller中）分享环境上下文
 *  @param completion 分享结果
 */
- (void)share:(UIViewController *)viewController
        title:(NSString *)shareTitle
         text:(NSString *)shareText
     imageUrl:(NSString *)shareImageUrl
        image:(UIImage *)image
  resourceUrl:(NSString *)shareUrl
   completion:(HDShareBackBlock)completion
    viewPoped:(MCShareViewPoped)popedBlock
viewDissMissed:(MCShareViewDismissed)dismissedBlock;


@end
