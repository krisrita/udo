//
//  HDVideoProxy.m
//  udo_stu
//
//  Created by nobody on 6/20/15.
//  All rights reserved.
//

#import "HDVideoProxy.h"
#import "HDVideoViewController.h"

@interface HDVideoProxy ()

@property (nonatomic, strong) id chapterOrSectionModel;
@property (nonatomic, strong) id answerModel;
@property (nonatomic, weak) UIViewController *viewController;

@end

@implementation HDVideoProxy

+ (instancetype)sharedInstance
{
    static HDVideoProxy * shareInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        shareInstance = [[self alloc] init];
    });
    return shareInstance;
}

- (void)showVideo:(UIViewController *)viewController chapterOrSectionModel:(id)chapterOrSectionModel answerModel:(id)answerModel
{
    self.viewController = viewController;
    self.chapterOrSectionModel = chapterOrSectionModel;
    self.answerModel = answerModel;
    
    BOOL allowWWAN = [[NSUserDefaults standardUserDefaults] boolForKey:@"HD_ALLOW_VIDEO_IN_WWAN_KEY"];
    
    HDNetworkStatus status =  [[HDNetwork sharedInstance] getNetworkStatus];
    if (!allowWWAN && HD_NETWORK_STATUS_WWAN == status) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"你正在使用非WIFI网络播放，会产生手机流量，是否继续？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"继续", nil];
        [alertView show];
    }
    else {
        [self showVideo];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        [self showVideo];
    }
}

- (void)showVideo
{
    HDVideoViewController *videoViewController = [[HDVideoViewController alloc]init];
    videoViewController.chapterOrSectionModel = self.chapterOrSectionModel;
    videoViewController.answerModel = self.answerModel;
    [self.viewController.navigationController pushViewController:videoViewController animated:YES];
}

@end
