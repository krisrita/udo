//
//  HDNetworkConfig.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDNetworkConfigDelegate.h"

typedef NS_ENUM(NSInteger, HDURLType) {
    URL_TYPE_TERMS = 0,
    URL_TYPE_SHARE,
    URL_TYPE_ABOUT
};

@interface HDNetworkConfig : NSObject<HDNetworkConfigDelegate>

+ (NSString *)getModuleUrl:(HDURLType)type;

@end
