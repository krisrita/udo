//
//  HDNetworkConfig.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDNetworkConfig.h"


// 连接正式服务器
#define API_ROOT_URL_PRODUCT @"http://182.92.226.49/"

// 连接测试服务器
#define API_ROOT_URL_DEBUG @"http://182.92.110.119/"

// API连接超时(ms)
#define API_CONNECT_TIMEOUT 20000

// API安全串(正式服务器)
#define API_SECURITY_KEY_PRODUCT @"0210@)!$howdo_udo)@!)2014"

// API安全串(测试服务器)
#define API_SECURITY_KEY_DEBUG @"howdo"

@implementation HDNetworkConfig

- (NSString *)getHttpServiceBaseUrl
{
    NSString *base = nil;
    if (_developmentMode) {
        base = [NSString stringWithFormat:@"%@", API_ROOT_URL_DEBUG];
    } else {
        base = [NSString stringWithFormat:@"%@", API_ROOT_URL_PRODUCT];
    }
    return base;
}

- (int)getHttpConnectTimeOut
{
    return API_CONNECT_TIMEOUT;
}

- (NSString *)getToken:(NSString *)url
{
    NSString *method = url;
    
    NSString *userId = ([HDManager sharedInstance].isLogined) ? [NSString stringWithFormat:@"%ld", (long)[HDManager sharedInstance].currentUser.Id] : @"0";
    
    NSString *secKey = _developmentMode ? API_SECURITY_KEY_DEBUG : API_SECURITY_KEY_PRODUCT;
    NSString *token = [NSString stringWithFormat:@"%@|%@|%@", userId, method, secKey, nil];
    
    return [token md5_32];
}


#pragma mark -app urls address

+ (NSString *)getModuleUrl:(HDURLType)type
{
    HDNetworkConfig *networkConfig = [[HDNetworkConfig alloc] init];
    NSString *baseUrl = [networkConfig getHttpServiceBaseUrl];
    
    NSString *path = nil;
    switch (type) {
        case URL_TYPE_TERMS:
            path = @"corp/protocol";
            break;
            
        case URL_TYPE_SHARE:
            path = @"http://www.howdo.cc/xjk.html";
            break;
            
        case URL_TYPE_ABOUT:
            path = @"corp/about";
            break;
            
        default:
            path = @"";
            break;
    }
    
    return URL_TYPE_SHARE == type ? path : [NSString stringWithFormat:@"%@%@?platform=ios", baseUrl, path];
}

@end
