//
//  HDDefine.h
//  udo_stu
//
//  Created by nobody on 6/7/15.
//  All rights reserved.
//

#ifndef udo_stu_HDDefine_h
#define udo_stu_HDDefine_h

// YES-测试环境  NO-正式环境
static BOOL _developmentMode = YES;

#define APP_ID @"1"

#define SHARE_TITLE @"老师还能这样讲？看到评论我都疯了！"
#define SHARE_CONTENT @""
#define SHARE_IMAGE_URL @"http://7qnco6.com2.z0.glb.qiniucdn.com/shareImg/300x300.jpg"

#define TAG_PRACTISE_REPORT_BACK_TO 90001

#define HD_LOGINUSER_INFO_KEY @"userInfo"
#define HD_ALLOW_VIDEO_IN_WWAN_KEY @"allowVideoInWWAN"

typedef NS_ENUM(NSInteger, HDActionStatus) {
    /** 没有任何行为 */
    HD_ACTION_STATUS_NONE    = 0,
    /** 顶过 */
    HD_ACTION_STATUS_LIKED   = 1,
    /** 踩过 */
    HD_ACTION_STATUS_UNLIKEd = 2
};

#endif
