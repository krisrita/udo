//
//  HDAppServiceDelegate.h
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDBaseServiceDelegate.h"

@protocol HDAppServiceDelegate <HDBaseServiceDelegate>

// 意见反馈
- (void)sendFeedback:(NSString *)contact content:(NSString *)content resultBack:(HDServiceBackObjectBlock)resultBack;

// 获取服务器的版本信息
- (void)getLastVersion:(NSString *)appId resultBack:(HDServiceBackObjectBlock)resultBack;

@end