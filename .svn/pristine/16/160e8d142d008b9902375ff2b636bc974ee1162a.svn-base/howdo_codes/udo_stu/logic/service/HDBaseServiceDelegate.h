//
//  HDBaseServiceDelegate.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDServiceResult.h"

typedef void (^HDServiceBackArrayBlock)(HDServiceResult *result, NSArray *items);
typedef void (^HDServiceBackObjectBlock)(HDServiceResult *result, id object);

@protocol HDBaseServiceDelegate <NSObject>

@end
