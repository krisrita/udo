//
//  HDUserService.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDUserService.h"

@implementation HDUserService

- (void)registerByMobilephone:(NSString *)mobilephone password:(NSString *)password verificationCode:(NSString *)code resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/register";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   mobilephone, @"mobile",
                                   password, @"password",
                                   code,@"vcode",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDUserModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            id userInfo = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    userInfo = [data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, userInfo);
            }
        }];
    }];
}

- (void)sendVerificationCode:(NSString *)mobilephone resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/sendcode";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   mobilephone, @"mobile",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"%@",responseObject);
        
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDDataModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, nil);
            }
        }];
    }];
}

- (void)loginByMobilephone:(NSString *)mobilephone password:(NSString *)password resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/login";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   mobilephone, @"mobile",
                                   password, @"password",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDUserModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            id userInfo = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    userInfo = [data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, userInfo);
            }
        }];
    }];
}

- (void)sendForgetPasswordCode:(NSString *)mobilephone resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/forgetpasswordsendcode";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   mobilephone, @"mobile",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"%@",responseObject);
        
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDDataModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, nil);
            }
        }];
    }];
}

- (void)checkForgetPasswordCode:(NSString *)mobilephone code:(NSString *)code resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/checkcode";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   mobilephone, @"mobile",
                                   code,@"code",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"%@",responseObject);
        
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDDataModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, nil);
            }
        }];
    }];
}

- (void)forgetPassword:(NSString *)mobilephone password:(NSString *)password verificationCode:(NSString *)code resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/forgetpassword";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   mobilephone, @"mobile",
                                   password, @"password",
                                   code,@"code",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDDataModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
            }
        }];

    }];
}

- (void)changeHeadImage:(NSInteger)userId imageData:(NSData *)imageData resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/sethead";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   nil];
    
    [[HDNetwork sharedInstance] upload:path
                            parameters:[self PreprocessUID:params]
                                  data:imageData
                                  name:@"file[]"
                              fileName:@"file.jpg"
                              mimeType:@"image/jpeg"
                            resultBack:^(HDCommonResult *result, id responseObject) {
                                NSString * imgStr = nil;
                                if (responseObject && [responseObject isKindOfClass:[NSDictionary class]])
                                {
                                    NSDictionary * imgDic = [responseObject objectForKey:@"data"];
                                    if (imgDic && [imgDic isKindOfClass:[NSDictionary class]])
                                    {
                                        NSString *  str = [imgDic objectForKey:@"image"];
                                        if (str && [str isKindOfClass:[NSString class]])
                                        {
                                            imgStr = str;
                                        }
                                    }
                                }
                                if (resultBack)
                                {
                                    resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc],imgStr);
                                }
                            }];
}

- (void)changeNickname:(NSInteger)userId nickname:(NSString *)nickname resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   nickname, @"name",
                                   nil];
    [self changeUserInfo:params resultBack:^(HDServiceResult *result, id object) {
        if (resultBack) {
            resultBack(result, object);
        }
    }];
}

- (void)changeGender:(NSInteger)userId gender:(HDGender)gender resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   [NSNumber numberWithInteger:gender], @"gender",
                                   nil];
    [self changeUserInfo:params resultBack:^(HDServiceResult *result, id object) {
        if (resultBack) {
            resultBack(result, object);
        }
    }];
}

- (void)changeSignature:(NSInteger)userId signature:(NSString *)signature resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   signature, @"sign",
                                   nil];
    [self changeUserInfo:params resultBack:^(HDServiceResult *result, id object) {
        if (resultBack) {
            resultBack(result, object);
        }
    }];
}

-(void)changeRegion:(NSInteger)userId provinceId:(NSInteger)provId cityId:(NSInteger)cityId regionId:(NSInteger)regionId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   [NSNumber numberWithInteger:provId], @"prov_id",
                                   [NSNumber numberWithInteger:cityId], @"city_id",
                                   [NSNumber numberWithInteger:regionId], @"area_id",
                                   nil];
    [self changeUserInfo:params resultBack:^(HDServiceResult *result, id object) {
        
        if (resultBack) {
            resultBack(result, object);
        }
    }];
}

- (void)changePassword:(NSInteger)userId oldPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/resetpassword";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   oldPassword, @"password_old",
                                   newPassword, @"password_new",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:nil analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
            }
   
        }];
    }];
}

- (void)checkBeforeChangeMobilephone:(NSInteger)userId password:(NSString *)password newMobilephone:(NSString *)newMobilephone resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/resetmobilecheck";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   password, @"password",
                                   newMobilephone, @"mobile_new",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"checkBeforeChangeMobilephone%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:nil analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
            }
         }];
    }];
}

- (void)changeMobilephone:(NSInteger)userId password:(NSString *)password newMobilephone:(NSString *)newMobilephone verificationCode:(NSString *)code resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"user/resetmobile";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:userId], @"uid",
                                   password, @"password",
                                   newMobilephone, @"new_mobile",
                                   code, @"code",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"changeMobilephone%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:nil analyzeResultBack:^(HDServiceResult *result, NSArray *data) {

        if (resultBack) {
            resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
        }
        }];

    }];
}

- (void)getRegionSource:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"datasource/region";
    
    [[HDNetwork sharedInstance] get:path parameters:nil resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"getRegionSource%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDRegionSourceModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            id regionSource = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    regionSource = [data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, regionSource);
            }
        }];
    }];
}

#pragma private methods

- (void)changeUserInfo:(NSMutableDictionary *)params resultBack:(HDServiceBackObjectBlock)resultBack {
    NSString *path = @"user/setprofile";
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"changeUserInfo%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:nil analyzeResultBack:^(HDServiceResult *result, NSArray *data) {

        if (resultBack) {
            resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
        }
        }];
   
    }];
}

@end
