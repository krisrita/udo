//
//  HDUserServiceDelegate.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDBaseServiceDelegate.h"

@protocol HDUserServiceDelegate <HDBaseServiceDelegate>

// 获取地区字典
- (void)getRegionSource:(HDServiceBackObjectBlock)resultBack;

// 手机号注册
- (void)registerByMobilephone:(NSString *)mobilephone
                     password:(NSString *)password
             verificationCode:(NSString *)code
                   resultBack:(HDServiceBackObjectBlock)resultBack;

// 发送验证码
- (void)sendVerificationCode:(NSString *)mobilephone
                  resultBack:(HDServiceBackObjectBlock)resultBack;

// 手机号登录
- (void)loginByMobilephone:(NSString *)mobilephone
                  password:(NSString *)password
                resultBack:(HDServiceBackObjectBlock)resultBack;

// 发送忘记密码验证码（step 1）
- (void)sendForgetPasswordCode:(NSString *)mobilephone resultBack:(HDServiceBackObjectBlock)resultBack;

// 校验密码验证码（step 2）
- (void)checkForgetPasswordCode:(NSString *)mobilephone code:(NSString *)code resultBack:(HDServiceBackObjectBlock)resultBack;

// 忘记密码（step 3）
- (void)forgetPassword:(NSString *)mobilephone password:(NSString *)password verificationCode:(NSString *)code resultBack:(HDServiceBackObjectBlock)resultBack;

// 忘记密码
- (void)forgetPassword:(NSString *)mobilephone
              password:(NSString *)password
      verificationCode:(NSString *)code
            resultBack:(HDServiceBackObjectBlock)resultBack;

// 更改头像
- (void)changeHeadImage:(NSInteger)userId
              imageData:(NSData *)imageData
             resultBack:(HDServiceBackObjectBlock)resultBack;

// 更改昵称
- (void)changeNickname:(NSInteger)userId
              nickname:(NSString *)nickname
            resultBack:(HDServiceBackObjectBlock)resultBack;

// 更改性别
- (void)changeGender:(NSInteger)userId
              gender:(HDGender)gender
          resultBack:(HDServiceBackObjectBlock)resultBack;

// 更改签名
- (void)changeSignature:(NSInteger)userId
              signature:(NSString *)signature
             resultBack:(HDServiceBackObjectBlock)resultBack;

// 更改地区
-(void)changeRegion:(NSInteger)userId
         provinceId:(NSInteger)provId
             cityId:(NSInteger)cityId
           regionId:(NSInteger)regionId
         resultBack:(HDServiceBackObjectBlock)resultBack;

// 更改密码
- (void)changePassword:(NSInteger)userId
           oldPassword:(NSString *)oldPassword
           newPassword:(NSString *)newPassword
            resultBack:(HDServiceBackObjectBlock)resultBack;


// 更改手机号前的验证(step 1)
- (void)checkBeforeChangeMobilephone:(NSInteger)userId
                            password:(NSString *)password
                      newMobilephone:(NSString *)newMobilephone
                          resultBack:(HDServiceBackObjectBlock)resultBack;

// 更改手机号（step 2）
- (void)changeMobilephone:(NSInteger)userId
                 password:(NSString *)password
           newMobilephone:(NSString *)newMobilephone
         verificationCode:(NSString *)code
               resultBack:(HDServiceBackObjectBlock)resultBack;

@end
