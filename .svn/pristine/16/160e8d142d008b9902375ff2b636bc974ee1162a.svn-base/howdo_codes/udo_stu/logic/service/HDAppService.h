//
//  HDAppService.h
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.All rights reserved.
//

#import "HDBaseService.h"
#import "HDAppServiceDelegate.h"

@interface HDAppService : HDBaseService <HDAppServiceDelegate>

@end
