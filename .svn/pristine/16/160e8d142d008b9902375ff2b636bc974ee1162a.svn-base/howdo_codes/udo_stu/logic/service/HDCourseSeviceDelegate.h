//
//  HDCourseSeviceDelegate.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDBaseServiceDelegate.h"

@protocol HDCourseSeviceDelegate <HDBaseServiceDelegate>

// 学校列表
- (void)getSchoolList:(NSInteger)cityId lastSchoolId:(NSInteger)lastSchoolId resultBack:(HDServiceBackArrayBlock)resultBack;

// 课程列表
- (void)getCourseList:(NSInteger)schoolId lastCourseId:(NSInteger)lastCourseId resultBack:(HDServiceBackArrayBlock)resultBack;

// 课程简介
- (void)getCourseIntro:(NSInteger)courseId resultBack:(HDServiceBackObjectBlock)resultBack;

// 课程下的章节列表
- (void)getChapterList:(NSInteger)courseId resultBack:(HDServiceBackArrayBlock)resultBack;

/**
 *  章节详细信息
 *
 *  @param sectionId  节id
 *  @param videoId    视频id
 */
- (void)getSectionDetail:(NSInteger)sectionId videoId:(NSInteger)videoId resultBack:(HDServiceBackObjectBlock)resultBack;

// 获取笔记列表
- (void)getNoteList:(NSInteger)sectionId resultBack:(HDServiceBackArrayBlock)resultBack;

// 顶 第一次调用+1/第二次调用-1/第三次调用+1...
- (void)like:(NSInteger)videoId resultBack:(HDServiceBackObjectBlock)resultBack;

// 踩 第一次调用+1/第二次调用-1/第三次调用+1...
- (void)dislike:(NSInteger)videoId resultBack:(HDServiceBackObjectBlock)resultBack;

// 获取课程下面的评论列表
- (void)getCommentList:(NSInteger)courseId lastCommentId:(NSInteger)lastCommentId resultBack:(HDServiceBackArrayBlock)resultBack;

// 获取节下面的评论列表
- (void)getCommentList:(NSInteger)courseId videoId:(NSInteger)videoId lastCommentId:(NSInteger)lastCommentId resultBack:(HDServiceBackArrayBlock)resultBack;

// 发表评论 sectionId和replyCommentId没有时传0  成功后返回HDCommentModel对象
- (void)sendComment:(NSString *)content courseId:(NSInteger)courseId videoId:(NSInteger)videoId replyCommentId:(NSInteger)replyCommentId resultBack:(HDServiceBackObjectBlock)resultBack;

// 举报某评论
- (void)reportComment:(NSInteger)commentId resultBack:(HDServiceBackObjectBlock)resultBack;

/**
 *  获取练习题
 *
 *  @param chapterOrSectionId chapterOrSectionId
 *  @param questionSeq        序号
 */
- (void)getPractiseQuestion:(NSInteger)chapterOrSectionId questionSeq:(NSInteger)questionSeq resultBack:(HDServiceBackObjectBlock)resultBack;

// 提交练习结果
- (void)submitPractiseAnswers:(NSInteger)chapterOrSectionId answers:(NSArray *)answers spentTime:(NSInteger)spentTime resultBack:(HDServiceBackObjectBlock)resultBack;

// 获取答题报告
- (void)getPractiseReport:(NSInteger)chapterOrSectionId resultBack:(HDServiceBackObjectBlock)resultBack;

// 错题解析
- (void)getQuestionParse:(NSInteger)chapterOrSectionId isOnlyWrong:(BOOL)isOnlyWrong questionSeq:(NSInteger)questionSeq resultBack:(HDServiceBackObjectBlock)resultBack;

/**
 *  试卷列表 paper/list
 *
 *  @param courseId   课程id
 *  @param paperId    试卷id
 *  @param type       0取新(下拉刷新),1取旧(上拉)
 */
- (void)getPaperListWithWithCourseId:(NSInteger)courseId paperId:(NSInteger)paperId type:(NSInteger)type resultBack:(HDServiceBackObjectBlock)resultBack;


@end
