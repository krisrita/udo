//
//  HDCourseService.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDCourseService.h"
#import "HDPaper.h"

@implementation HDCourseService

#pragma mark - 试卷列表 paper/list
- (void)getPaperListWithWithCourseId:(NSInteger)courseId paperId:(NSInteger)paperId type:(NSInteger)type resultBack:(HDServiceBackObjectBlock)resultBack {
    NSString *path = @"paper/list";
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:@(courseId) forKey:@"course_id"];
    [params setValue:@(paperId) forKey:@"paper_id"];
    [params setValue:@(type) forKey:@"type"];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDPaper class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, data);
            }
        }];
    }];
}

- (void)getSchoolList:(NSInteger)cityId lastSchoolId:(NSInteger)lastSchoolId resultBack:(HDServiceBackArrayBlock)resultBack
{
    NSString *path = @"school/list";
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    [params setObject:[NSNumber numberWithInteger:cityId] forKey:@"city_id"];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
//        HDLogInfo(@"getSchoolList%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDSchoolModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, data);
            }
        }];
    }];
}

- (void)getCourseList:(NSInteger)schoolId lastCourseId:(NSInteger)lastCourseId resultBack:(HDServiceBackArrayBlock)resultBack
{
    NSString *path = @"course/list";
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    [params setObject:[NSNumber numberWithInteger:schoolId] forKey:@"school_id"];
    [params setObject:[NSNumber numberWithInteger:lastCourseId] forKey:@"course_id"];
    [params setObject:[NSNumber numberWithInteger:1] forKey:@"type"];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getCourseList%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDCourseModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, data);
            }
        }];
    }];
}

- (void)getCourseIntro:(NSInteger)courseId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"course/profile";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:courseId], @"course_id",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getCourseIntro%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDCourseIntroModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            HDCourseIntroModel *courseIntro = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    courseIntro = (HDCourseIntroModel *)[data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, courseIntro);
            }

        }];
    }];
}

- (void)getChapterList:(NSInteger)courseId resultBack:(HDServiceBackArrayBlock)resultBack
{
    NSString *path = @"course/info";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:1], @"type",
                                   [NSNumber numberWithInteger:courseId], @"course_id",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getChapterList%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDChapterModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, data);
            }
        }];
    }];
}

- (void)getSectionDetail:(NSInteger)sectionId videoId:(NSInteger)videoId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"section/info";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:sectionId], @"section_id",
                                   [NSNumber numberWithInteger:videoId], @"video_id",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getSectionInfo%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDSectionDetailModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                if (data.count) {
                   resultBack(result, data[0]);
                }else{
                   resultBack(result, nil);
                }
               
            }
        }];
    }];
}

- (void)getCommentList:(NSInteger)courseId lastCommentId:(NSInteger)lastCommentId resultBack:(HDServiceBackArrayBlock)resultBack
{
    [self getCommentList:courseId videoId:0 lastCommentId:lastCommentId resultBack:^(HDServiceResult *result, NSArray *items) {
        if (resultBack) {
            resultBack(result, items);
        }
    }];
}

- (void)getCommentList:(NSInteger)courseId videoId:(NSInteger)videoId lastCommentId:(NSInteger)lastCommentId resultBack:(HDServiceBackArrayBlock)resultBack
{
    NSString *path = @"comment/list";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:courseId], @"course_id",
                                   [NSNumber numberWithInteger:lastCommentId], @"comment_id",
                                   [NSNumber numberWithInteger:1], @"type",
                                   nil];
    
    if (videoId > 0) {
        [params setObject:[NSNumber numberWithInteger:videoId] forKey:@"video_id"];
    }
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getCommentList%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDCommentModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, data);
            }
        }];
    }];
}

- (void)sendComment:(NSString *)content courseId:(NSInteger)courseId videoId:(NSInteger)videoId replyCommentId:(NSInteger)replyCommentId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"comment/publish";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:courseId], @"course_id",
                                   [NSNumber numberWithInteger:videoId], @"video_id",
                                   [NSNumber numberWithInteger:replyCommentId], @"comment_id",
                                   content, @"content",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"sendComment%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDCommentModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            HDCommentModel *comment = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    comment = (HDCommentModel *)[data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, comment);
            }
            
        }];
    }];
}

- (void)reportComment:(NSInteger)commentId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"comment/report";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:commentId], @"comment_id",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"reportComment%@",responseObject);
        if (resultBack) {
            resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
        }
    }];
}

- (void)getNoteList:(NSInteger)sectionId resultBack:(HDServiceBackArrayBlock)resultBack
{
    NSString *path = @"section/note";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:sectionId], @"section_id",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getNoteList%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDNoteModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            if (resultBack) {
                resultBack(result, data);
            }
        }];
    }];
}

- (void)like:(NSInteger)videoId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"video/like";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:videoId], @"video_id",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"like%@",responseObject);
        if (resultBack) {
            resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
        }
    }];
}

- (void)dislike:(NSInteger)videoId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"video/dislike";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:videoId], @"video_id",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"dislike%@",responseObject);
        if (resultBack) {
            resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
        }
    }];
}

#pragma mark 获取练习题
- (void)getPractiseQuestion:(NSInteger)chapterOrSectionId questionSeq:(NSInteger)questionSeq resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"section/practise";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:chapterOrSectionId], @"section_id",
                                   [NSNumber numberWithInteger:questionSeq], @"seq",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getPractise%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDQuestionModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            HDQuestionModel *question = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    question = (HDQuestionModel *)[data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, question);
            }
            
        }];
    }];
}

- (void)submitPractiseAnswers:(NSInteger)chapterOrSectionId answers:(NSArray *)answers spentTime:(NSInteger)spentTime resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"section/answer";
    
    NSMutableString *answers_str = [NSMutableString string];
    if (answers && [answers count] > 0) {
        for (HDAnswerModel *answer in answers) {
            if (answer && answer.questionId > 0) {
                if (answers_str.length > 0) {
                    [answers_str appendString:@","];
                }
                [answers_str appendFormat:@"%ld_%ld", (long)answer.questionId, (long)answer.optionId];
            }
        }
    }
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:chapterOrSectionId], @"section_id",
                                   [NSNumber numberWithInteger:spentTime], @"spend_time",
                                   answers_str, @"answer",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"submitPractiseAnswers%@",responseObject);
        if (resultBack) {
            resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
        }
    }];
}

- (void)getPractiseReport:(NSInteger)chapterOrSectionId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"practise/report";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:chapterOrSectionId], @"section_id",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getPractiseReport%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDPractiseReportModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            HDPractiseReportModel *practiseResult = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    practiseResult = (HDPractiseReportModel *)[data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, practiseResult);
            }
            
        }];
    }];

}

- (void)getQuestionParse:(NSInteger)chapterOrSectionId isOnlyWrong:(BOOL)isOnlyWrong questionSeq:(NSInteger)questionSeq resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = isOnlyWrong ? @"practise/wrong" : @"practise/parse";
    
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithInteger:chapterOrSectionId], @"section_id",
                                   [NSNumber numberWithInteger:questionSeq], @"seq",
                                   nil];
    
    [[HDNetwork sharedInstance] get:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        // HDLogInfo(@"getQuestionParse%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDPractiseReportModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            HDQuestionParseModel *questionPrase = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    questionPrase = (HDQuestionParseModel *)[data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, questionPrase);
            }
            
        }];
    }];
}

@end
