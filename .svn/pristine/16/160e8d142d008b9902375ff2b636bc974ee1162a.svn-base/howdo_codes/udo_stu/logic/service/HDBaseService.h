//
//  HDBaseService.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@class HDServiceResult;

typedef void (^HDAnalyzeBackBlock)(HDServiceResult *result, NSArray *data);

@interface HDBaseService : NSObject

- (void)analyzeDataWithResult:(HDCommonResult *)result responseData:(id)responseData modelClass:(Class)modelClass analyzeResultBack:(HDAnalyzeBackBlock)analyzeResultBack;

- (NSMutableDictionary *)PreprocessUID:(NSMutableDictionary *)params;

@end
