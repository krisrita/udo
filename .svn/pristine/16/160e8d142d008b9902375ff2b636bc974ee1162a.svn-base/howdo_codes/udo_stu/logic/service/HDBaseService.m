//
//  HDBaseService.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDBaseService.h"
#import "HDServiceResult.h"

#define USE_MANUAL_JSON_MAPPING

@implementation HDBaseService
- (void)analyzeDataWithResult:(HDCommonResult *)result responseData:(id)responseData modelClass:(Class)modelClass analyzeResultBack:(HDAnalyzeBackBlock)analyzeResultBack
{
    HDServiceResult *analyzeResult = nil;
    NSMutableArray *logicData = nil;
    if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
        @try {
            analyzeResult = [HDServiceResult resultWithData:responseData];
            if (HD_RESULT_CODE_SUCCESS == analyzeResult.resultCode) {
                if (responseData != nil && responseData != [NSNull null] && [responseData isKindOfClass:[NSDictionary class]]) {
                    id data = [responseData objectForKey:@"data"];
                    if (data != nil && data != [NSNull null]) {
                        logicData = [NSMutableArray array];
                        if ([data isKindOfClass:[NSArray class]]) {
                            for (id child in data) {
#ifdef USE_MANUAL_JSON_MAPPING
                                HDDataModel *dataModel = [modelClass modelWithData:child];
#else
                                MTLModel *dataModel = [MTLJSONAdapter modelOfClass:modelClass fromJSONDictionary:child error:nil];
#endif
                                if (dataModel) {
                                    [logicData addObject:dataModel];
                                }
                            }
                        }
                        else if ([data isKindOfClass:[NSDictionary class]]) {
#ifdef USE_MANUAL_JSON_MAPPING
                            HDDataModel *dataModel = [modelClass modelWithData:data];
#else
                            MTLModel *dataModel = [MTLJSONAdapter modelOfClass:modelClass fromJSONDictionary:data error:nil];
#endif
                            [logicData addObject:dataModel];
                        }
                    }
                }
            }
        }
        @catch (NSException *exception) {
            
            analyzeResult = [HDServiceResult resultWithError:nil];
        }
        @finally {
            
        }
    }
    else {
        
        analyzeResult = [HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc];
    }
    
    if (analyzeResultBack) {
        analyzeResultBack(analyzeResult, logicData);
    }
}

- (NSMutableDictionary *)PreprocessUID:(NSMutableDictionary *)params
{
    if (params) {
        if (![[params allKeys] containsObject:@"uid"]) {
            [params setObject:[NSNumber numberWithLong:[HDManager sharedInstance].isLogined ? [HDManager sharedInstance].currentUser.Id : 0]
                       forKey:@"uid"];
        }
        if (![[params allKeys] containsObject:@"platform"]) {
            [params setObject:@"ios" forKey:@"platform"];
        }
    }
    return params;
}

@end
