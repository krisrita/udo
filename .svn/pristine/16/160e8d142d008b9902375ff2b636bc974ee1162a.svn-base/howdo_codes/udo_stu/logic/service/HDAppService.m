//
//  HDAppService.m
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import "HDAppService.h"

@implementation HDAppService

- (void)sendFeedback:(NSString *)contact content:(NSString *)content resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"feedback/publish";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   content, @"content",
                                   contact, @"contact",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"sendFeedback%@",responseObject);
        if (resultBack) {
            resultBack([HDServiceResult resultWithData:result.resultCode resultDesc:result.resultDesc], nil);
        }
    }];
}

- (void)getLastVersion:(NSString *)appId resultBack:(HDServiceBackObjectBlock)resultBack
{
    NSString *path = @"app/version";
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   appId, @"appid",
                                   @"ios", @"platform",
                                   nil];
    
    [[HDNetwork sharedInstance] post:path parameters:[self PreprocessUID:params] resultBack:^(HDCommonResult *result, id responseObject) {
        HDLogInfo(@"getLastVersion%@",responseObject);
        [self analyzeDataWithResult:result responseData:responseObject modelClass:[HDVersionModel class] analyzeResultBack:^(HDServiceResult *result, NSArray *data) {
            HDVersionModel *version = nil;
            if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
                if (data && [data count] > 0) {
                    version = (HDVersionModel *)[data objectAtIndex:0];
                }
            }
            if (resultBack) {
                resultBack(result, version);
            }
            
        }];
    }];
}

@end
