//
//  HDServiceResult.h
//
//  Created by nobody on 14-1-23.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDServiceResult : HDCommonResult

+ (instancetype)resultWithData:(id)data;
+ (BOOL)isExposedToUser:(NSInteger)resultCode;
- (void)show;
+ (void)show:(NSString *)resultDesc;

@end
