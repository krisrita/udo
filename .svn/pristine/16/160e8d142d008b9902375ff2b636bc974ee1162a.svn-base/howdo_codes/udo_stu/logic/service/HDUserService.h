//
//  HDUserService.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDUserServiceDelegate.h"
#import "HDBaseService.h"

@interface HDUserService : HDBaseService <HDUserServiceDelegate>

@end
