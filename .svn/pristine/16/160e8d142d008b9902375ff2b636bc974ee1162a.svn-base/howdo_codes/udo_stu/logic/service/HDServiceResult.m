//
//  HDServiceResult.m
//
//  Created by nobody on 14-1-23.
//  All rights reserved.
//

#import "HDServiceResult.h"

@implementation HDServiceResult

#pragma mark - class method

+ (instancetype)resultWithData:(id)data
{
    HDServiceResult *serviceResult = [[self alloc] init];
    
    if (data != nil && data != [NSNull null] && [data isKindOfClass:[NSDictionary class]])
    {
        serviceResult.resultCode =(HDResultCode)[data integerForKey:@"errno"];
        serviceResult.resultDesc = [data stringForKey:@"error"];
        
        if (1 == serviceResult.resultCode)
        {
            serviceResult.resultCode = HD_RESULT_CODE_EMPTY;
        }
    }
    
    return serviceResult;
}

+ (BOOL)isExposedToUser:(NSInteger)resultCode
{
    BOOL bExposedToUser = NO;
    
    if (1 == resultCode % (-10)) {
        bExposedToUser = YES;
    }
    
    return bExposedToUser;
}

+ (void)show:(NSString *)resultDesc
{
    dispatch_async(dispatch_get_main_queue(), ^{
        // 统一显示结果信息的调用
        [HDTip showMessage:resultDesc];
    });
}

#pragma mark - instance method

- (void)show
{
    if (self.resultDesc && [self.resultDesc isKindOfClass:[NSString class]] && self.resultDesc.length > 0) {
        [[self class] show:self.resultDesc];
    }
}

@end
