//
//  HDPractise.h
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import "HDDataModel.h"

typedef NS_ENUM(NSInteger, HDPractiseType) {
    /** 章练习 */
    HD_PRACTISE_TYPE_CHAPTER,
    /** 节练习 */
    HD_PRACTISE_TYPE_SECTION
};

@protocol HDPractiseDelegate <NSObject>

// 计时时间通知界面显示
- (void)onTimer:(NSInteger)minutes seconds:(NSInteger)seconds;

@end

@interface HDPractise : NSObject

// 题目总数
@property (nonatomic, assign) NSInteger questionNum;

// 建立新的练习
+ (void)createPractise:(HDPractiseType)practiseType chapterOrSectionId:(NSInteger)csId;

// 获取当前练习题
+ (instancetype)currentPractise;

// 设置练习事件代理
- (void)setPractiseDelegate:(id<HDPractiseDelegate>)delegate;

// 准备练习题
- (void)preparePractise:(void(^)(HDCommonResult *result))resultBack;

// 开始计时
- (void)startPractise;

// 跳到指定题
- (void)jumpToQuestion:(NSInteger)questionSeq resultBack:(void(^)(BOOL isFirst, BOOL isFinished, HDQuestionModel *question))resultBack;

// 上一题
- (void)prevQuestion:(void(^)(BOOL isFirst, BOOL isFinished, HDQuestionModel *question))resultBack;

// 下一题
- (void)nextQuestion:(void(^)(BOOL isFirst, BOOL isFinished, HDQuestionModel *question))resultBack;

// 获取答题情况
- (NSArray *)getAnswers;

// 停止计时(点击提交答案按钮时用到)
- (void)stopPractise;

// 提交答题结果
- (void)submitAnswers:(void(^)(HDCommonResult *result))resultBack;


@end
