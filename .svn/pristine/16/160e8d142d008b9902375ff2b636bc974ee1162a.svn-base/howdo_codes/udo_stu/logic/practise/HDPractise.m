//
//  HDPractise.m
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import "HDPractise.h"

@interface HDPractise ()

@property (nonatomic, assign) NSInteger spentSeconds;
@property (nonatomic, assign) HDPractiseType practiseType;
@property (nonatomic, assign) NSInteger chapterOrSectionId;
/// 所有题目
@property (nonatomic, strong) NSMutableArray *questions;
@property (nonatomic, weak) id<HDPractiseDelegate> delegate;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) NSInteger currentSeq;

@end

@implementation HDPractise

static HDPractise *instance = nil;

+ (void)createPractise:(HDPractiseType)practiseType chapterOrSectionId:(NSInteger)csId
{
    instance = nil;
    instance = [[self alloc] initWithCharterSectionInfo:practiseType chapterOrSectionId:csId];
}

+ (instancetype)currentPractise
{
    if (!instance) {
        instance = [[self alloc] init];
    };
    return instance;
}

- (void)setPractiseDelegate:(id<HDPractiseDelegate>)delegate
{
    self.delegate = delegate;
}

#pragma mark 请求服务器
- (void)preparePractise:(void(^)(HDCommonResult *result))resultBack
{
    self.currentSeq = 1;
    __strong typeof(self) strongSelf = self;
    [[HDManager sharedInstance].courseService getPractiseQuestion:self.chapterOrSectionId questionSeq:self.currentSeq resultBack:^(HDServiceResult *result, id object) {
        __weak typeof(self) weakSelf = strongSelf;
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            if (object && [object isKindOfClass:[HDQuestionModel class]]) {
                HDQuestionModel *question = (HDQuestionModel *)object;
                if (weakSelf) {
                    weakSelf.questionNum = question.num;
                    [weakSelf cacheQuestion:question];
                }
            }
        }
        if (resultBack) {
            resultBack(result);
        }
    }];
    
    [self prepareNextQuestion:(self.currentSeq + 1)];
}

- (void)startPractise
{
    self.spentSeconds = 0;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
}

- (void)jumpToQuestion:(NSInteger)questionSeq resultBack:(void(^)(BOOL isFirst, BOOL isFinished, HDQuestionModel *question))resultBack
{
    if (self.currentSeq < 1 && self.currentSeq > self.questionNum) {
        return;
    }
    
    self.currentSeq = questionSeq;
    
    BOOL isFirst = (self.currentSeq == 1) ? YES : NO;
    BOOL isFinished = (self.currentSeq == self.questionNum) ? YES : NO;
    
    [self getQuestion:questionSeq resultBack:^(HDQuestionModel *question) {
        if (resultBack) {
            resultBack(isFirst, isFinished, question);
        }
    }];
    
}

- (void)prevQuestion:(void(^)(BOOL isFirst, BOOL isFinished, HDQuestionModel *question))resultBack
{
    if (self.currentSeq <= 1) {
        return;
    }
    
    self.currentSeq--;
    
    BOOL isFirst = (self.currentSeq == 1) ? YES : NO;
    BOOL isFinished = (self.currentSeq == self.questionNum) ? YES : NO;
    
    [self getQuestion:self.currentSeq resultBack:^(HDQuestionModel *question) {
        if (resultBack) {
            resultBack(isFirst, isFinished, question);
        }
    }];
    
}

- (void)nextQuestion:(void(^)(BOOL isFirst, BOOL isFinished, HDQuestionModel *question))resultBack
{
    if (self.currentSeq >= self.questionNum) {
        return;
    }
    
    self.currentSeq++;

    BOOL isFirst = (self.currentSeq == 1) ? YES : NO;
    BOOL isFinished = (self.currentSeq == self.questionNum) ? YES : NO;
    
    [self getQuestion:self.currentSeq resultBack:^(HDQuestionModel *question) {
        if (resultBack) {
            resultBack(isFirst, isFinished, question);
        }
    }];
    
}

- (NSArray *)getAnswers
{
    NSMutableArray *answers = [NSMutableArray array];
    
    for (NSInteger i = 0; i < self.questionNum; i++) {
        HDAnswerModel *answer = [[HDAnswerModel alloc] init];
        answer.questionSeq = i + 1;
        [answers addObject:answer];
    }
    
    @synchronized(self.questions) {
        for (HDQuestionModel *question in self.questions) {
            if (question.seq > 0 && question.seq <= [answers count]) {
                HDAnswerModel *answer = (HDAnswerModel *)[answers objectAtIndex:(question.seq - 1)];
                answer.questionId = question.Id;
                answer.questionSeq = question.seq;
                answer.optionId = question.optionId;
            }
        }
    }
    
    return answers;
}

- (void)stopPractise
{
    [self.timer invalidate];
    self.timer = nil;
    self.delegate = nil;
}

- (void)submitAnswers:(void(^)(HDCommonResult *result))resultBack
{
    [[HDManager sharedInstance].courseService submitPractiseAnswers:self.chapterOrSectionId answers:[self getAnswers] spentTime:self.spentSeconds resultBack:^(HDServiceResult *result, id object) {
        if (resultBack) {
            resultBack(result);
        }
    }];
}


#pragma private methods

- (instancetype)initWithCharterSectionInfo:(HDPractiseType)practiseType chapterOrSectionId:(NSInteger)csId
{
    if (self = [self init]) {
        self.practiseType = practiseType;
        self.chapterOrSectionId = csId;
    }
    return self;
}

- (instancetype)init
{
    if (self = [super init]) {
        self.questions = [NSMutableArray array];
        self.questionNum = 0;
    }
    return self;
}

- (void)dealloc {
    [self stopPractise];
    self.questions = nil;
}

- (void)onTimer {
    self.spentSeconds++;
    NSInteger seconds = self.spentSeconds % 60;
    NSInteger minutes = self.spentSeconds / 60;
    if (self.delegate && [self.delegate respondsToSelector:@selector(onTimer:seconds:)]) {
        [self.delegate onTimer:minutes seconds:seconds];
    }
}

- (void)prepareNextQuestion:(NSInteger)nextSeq
{
    if (nextSeq <= 0 || (self.questionNum > 0 && nextSeq > self.questionNum) || [self checkIfCached:nextSeq]) return;
    
    __strong typeof(self) strongSelf = self;
    [[HDManager sharedInstance].courseService getPractiseQuestion:self.chapterOrSectionId questionSeq:nextSeq resultBack:^(HDServiceResult *result, id object) {
        __weak typeof(self) weakSelf = strongSelf;
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            if (object && [object isKindOfClass:[HDQuestionModel class]]) {
                HDQuestionModel *question = (HDQuestionModel *)object;
                if (weakSelf) {
                    [weakSelf cacheQuestion:question];
                }
            }
        }
    }];
}

- (BOOL)checkIfCached:(NSInteger)seq
{
    BOOL cached = NO;
    @synchronized(self.questions) {
        if (self.questions) {
            for (HDQuestionModel *question in self.questions) {
                if (question.seq == seq) {
                    cached = YES;
                    break;
                }
            }
        }
    }
    return cached;
}

- (void)cacheQuestion:(HDQuestionModel *)question
{
    if ([self checkIfCached:question.seq]) return;
    
    @synchronized(self.questions) {
        if (self.questions) {
            [self.questions addObject:question];
        }
    }
}

- (void)getQuestion:(NSInteger)seq resultBack:(void(^)(HDQuestionModel *question))resultBack
{
    __block HDQuestionModel *question = nil;
    
    @synchronized(self.questions) {
        if (self.questions) {
            for (HDQuestionModel *cachedQuestion in self.questions) {
                if (cachedQuestion.seq == seq) {
                    question = cachedQuestion;
                    break;
                }
            }
        }
    }
    
    [self prepareNextQuestion:(seq - 1)];
    [self prepareNextQuestion:(seq + 1)];
    
    if (question) {
        if (resultBack) {
            resultBack(question);
        }
        return;
    }
    
    __strong typeof(self) strongSelf = self;
    [[HDManager sharedInstance].courseService getPractiseQuestion:self.chapterOrSectionId questionSeq:seq resultBack:^(HDServiceResult *result, id object) {
        __weak typeof(self) weakSelf = strongSelf;
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            if (object && [object isKindOfClass:[HDQuestionModel class]]) {
                question = (HDQuestionModel *)object;
                if (weakSelf) {
                    [weakSelf cacheQuestion:question];
                }
                if (resultBack) {
                    resultBack(question);
                }
            }
        }
    }];
}


@end
