//
//  HDTeacherModel.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDTeacherModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) HDHeadImageUrl *imageUrl;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *introduction;

@end
