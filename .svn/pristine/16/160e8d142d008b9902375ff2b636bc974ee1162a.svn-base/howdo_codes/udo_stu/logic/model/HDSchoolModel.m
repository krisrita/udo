//
//  HDSchoolModel.m
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDSchoolModel.h"

@implementation HDSchoolModel

+ (instancetype)modelWithData:(id)data {
    
    HDSchoolModel *model = [[HDSchoolModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"id"];
        model.name = [data stringForKey:@"name"];
        model.title = [data stringForKey:@"title"];
        model.imageUrl = [HDSchoolImageUrl imageUrlWithName:[data stringForKey:@"image"]];
        model.cityId = [data integerForKey:@"city_id"];
    }
    
    return model;
}

@end
