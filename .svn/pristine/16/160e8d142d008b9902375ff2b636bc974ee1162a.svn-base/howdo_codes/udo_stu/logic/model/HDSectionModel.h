//
//  HDSectionModel.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDSectionModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, assign) NSInteger courseId;
@property (nonatomic, assign) NSInteger chapterId;
@property (nonatomic, assign) NSInteger videoId;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, assign) NSInteger seq;
@property (nonatomic, strong) HDTime *duration;
@property (nonatomic, assign) BOOL hasStudied;
@property (nonatomic, assign) BOOL hasPracticed;
@property (nonatomic, assign) BOOL hasOpened;
@property (nonatomic, assign) BOOL isLast;
@property (nonatomic, assign) NSInteger practiseNum;
@property (nonatomic, assign) NSInteger noteNum;

@end
