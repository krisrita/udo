//
//  HDRegionModel.h
//  udo_stu
//
//  Created by nobody on 6/4/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDRegionModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *name;

@end
