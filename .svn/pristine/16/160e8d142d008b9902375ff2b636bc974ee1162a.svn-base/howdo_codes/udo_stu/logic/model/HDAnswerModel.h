//
//  HDAnswerModel.h
//  udo_stu
//
//  Created by nobody on 6/10/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDAnswerModel : HDDataModel

@property (nonatomic, assign) NSInteger questionId;
@property (nonatomic, assign) NSInteger questionSeq;
@property (nonatomic, assign) NSInteger optionId;
@property (nonatomic, assign) BOOL isCorrect;
@property (nonatomic, assign) NSInteger videoId;

@end
