//
//  HDSectionDetailModel.m
//  udo_stu
//
//  Created by nobody on 6/2/15.
//  All rights reserved.
//

#import "HDSectionDetailModel.h"

@implementation HDSectionDetailModel

+ (instancetype)modelWithData:(id)data {
    
    HDSectionDetailModel *model = [[HDSectionDetailModel alloc] init];
    if ([[self class] isValidData:data])  {
        model.Id = [data integerForKey:@"section_id"];
        model.courseId = [data integerForKey:@"course_id"];
        model.chapterId = [data integerForKey:@"chapter_id"];
        model.name = [data stringForKey:@"section_name"];
        model.seq = [data integerForKey:@"section_seq"];
        model.hasStudied = [data integerToBoolForKey:@"finished"];
        model.hasPracticed = [data integerToBoolForKey:@"practise_finished"];
        model.isLast = [data integerToBoolForKey:@"last"];
        model.duration = [HDTime timeWithSeconds:[data integerForKey:@"duration"]];
        
        model.videoId = [data integerForKey:@"video_id"];
        model.imageUrl = [HDVideoImageUrl imageUrlWithName:[data stringForKey:@"video_image"]];
        model.videoUrl = [data stringForKey:@"video_url"];
        model.watchedNum = [data integerForKey:@"video_view_num"];
        model.likedNum = [data integerForKey:@"video_like_num"];
        model.dislikedNum = [data integerForKey:@"video_dislike_num"];
        model.teacher = [HDTeacherModel modelWithData:[data objectForKey:@"teacher"]];
        
        model.actionStatus = [data integerForKey:@"is_user_like"];
        
    }
    
    return model;
}

@end
