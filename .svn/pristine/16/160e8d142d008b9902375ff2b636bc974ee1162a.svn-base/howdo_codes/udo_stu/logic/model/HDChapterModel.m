//
//  HDChapterModel.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDChapterModel.h"

@implementation HDChapterModel

+ (instancetype)modelWithData:(id)data {
    
    HDChapterModel *model = [[HDChapterModel alloc] init];
    if ([[self class] isValidData:data])  {
        model.Id = [data integerForKey:@"id"];
        model.courseId = [data integerForKey:@"course_id"];
        model.name = [data stringForKey:@"name"];
        model.leftOpenTime = [HDTime timeWithSeconds:[data integerForKey:@"open_time_remain"]];
        model.hasOpened = model.leftOpenTime.seconds <= 0 ? YES : NO;
        model.hasPracticed = [data integerToBoolForKey:@"practise_finished"];
        model.practiseNum = [data integerForKey:@"practise_num"];
        
        if (!model.hasOpened) {
            model.leftOpenTimeHint = [NSString stringWithFormat:@"距离开放还有%@天", conversionstring([model.leftOpenTime maxdays])];
        }
        
        id sectionList = [data objectForKey:@"section_list"];
        NSMutableArray *sections = [NSMutableArray array];
        if ([sectionList isKindOfClass:[NSArray class]]) {
            for (NSDictionary *item in (NSArray *)sectionList) {
                if ([item isKindOfClass:[NSDictionary class]]) {
                    HDSectionModel *section =  [HDSectionModel modelWithData:item];
                    section.hasOpened = model.hasOpened;
                    [sections addObject:section];
                }
            }
        }
        model.sections = [NSArray arrayWithArray:sections];
    }
    
    return model;
}

@end
