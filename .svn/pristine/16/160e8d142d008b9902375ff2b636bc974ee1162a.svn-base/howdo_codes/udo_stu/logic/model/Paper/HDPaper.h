//
//  HDPaper.h
//  udo_stu
//
//  Created by nobody on 15/7/3.
//   All rights reserved.
//

#import "HDDataModel.h"
/**
 *  试卷模型
 */
@interface HDPaper : HDDataModel
/// 试卷id
@property (nonatomic, assign) NSInteger Id;
/// 试卷名称
@property (nonatomic, strong) NSString *name;
/// 是否是最后看的试卷
@property (nonatomic, assign) BOOL isLast;
/// 视频列表
@property (nonatomic, strong) NSArray *practise_video_list;
/// 课程id
@property (nonatomic, assign) NSInteger course_id;

///// 总共的题目数
@property (nonatomic, assign) NSInteger practise_num;
///// 视频id
//@property (nonatomic, assign) NSInteger video_id;
@end
