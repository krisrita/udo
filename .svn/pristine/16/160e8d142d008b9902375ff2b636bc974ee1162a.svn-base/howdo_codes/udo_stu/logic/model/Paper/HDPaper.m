//
//  HDPaper.m
//  udo_stu
//
//  Created by nobody on 15/7/3.
//   All rights reserved.
//

#import "HDPaper.h"

@implementation HDPaper
+ (instancetype)modelWithData:(id)data {
    
    HDPaper *paper = [[HDPaper alloc] init];
    
    if ([[self class] isValidData:data])  {
        paper.Id = [[data objectForKey:@"id"] integerValue];
        paper.name = [data valueForKey:@"name"];
        paper.isLast = [[data valueForKey:@"last"] boolValue];
        paper.course_id = [[data objectForKey:@"course_id"] integerValue];
        
        // 视频id列表
        id videoListDict = [data objectForKey:@"practise_video_list"];
        if ([videoListDict isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = (NSDictionary *)videoListDict;
            NSMutableArray *practise_video_list = [NSMutableArray arrayWithCapacity:dict.count];
            paper.practise_num = dict.count;
            NSArray *allKeys = [dict.allKeys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
//                NSOrderedAscending = -1L, NSOrderedSame, NSOrderedDescending};
                if ([obj1 integerValue] < [obj2 integerValue]) {
                    return NSOrderedAscending;
                }
                return NSOrderedDescending;
            }];
            for (id key in allKeys) {
                [practise_video_list addObject:dict[key]];
            }
            paper.practise_video_list = practise_video_list;
        }
//        paper.video_id = [[data objectForKey:@"video_id"] integerValue];
    }
    
    return paper;
}

@end
