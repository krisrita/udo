//
//  HDPractiseReportModel.m
//  udo_stu
//
//  Created by nobody on 6/10/15.
//  All rights reserved.
//

#import "HDPractiseReportModel.h"

@implementation HDPractiseReportModel

+ (instancetype)modelWithData:(id)data {
    
    HDPractiseReportModel *model = [[HDPractiseReportModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.name = [NSString stringWithFormat:@"%@%@%@", [data stringForKey:@"course_name"], [data stringForKey:@"chapter_name"], [data stringForKey:@"section_name"]];
        model.completionTime = [data stringForKey:@"create_time_fmt"];
        model.correctRate = [data stringForKey:@"correct_rate"];
        model.spentTime = [data stringForKey:@"spend_time_fmt"];
        model.correctRateBeatRate = [data stringForKey:@"score_win_rate"];
        model.spentTimeBeatRate = [data stringForKey:@"spendtime_win_rate"];
        model.totalRank = [data stringForKey:@"total_rank"];
        model.rankHonor = [data stringForKey:@"rank_level"];
        
        id answerList = [data objectForKey:@"answer_list"];
        NSMutableArray *answers = [NSMutableArray array];
        if ([answerList isKindOfClass:[NSArray class]]) {
            for (NSDictionary *item in (NSArray *)answerList) {
                if ([item isKindOfClass:[NSDictionary class]]) {
                    HDAnswerModel *answer =  [HDAnswerModel modelWithData:item];
                    [answers addObject:answer];
                }
            }
        }
        model.answers = [NSArray arrayWithArray:answers];
     
    }
    
    return model;
}

@end
