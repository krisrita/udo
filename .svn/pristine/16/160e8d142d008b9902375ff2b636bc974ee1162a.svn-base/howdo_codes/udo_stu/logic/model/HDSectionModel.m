//
//  HDSectionModel.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDSectionModel.h"

@implementation HDSectionModel

+ (instancetype)modelWithData:(id)data {
    
    HDSectionModel *model = [[HDSectionModel alloc] init];
    if ([[self class] isValidData:data])  {
        model.Id = [data integerForKey:@"id"];
        model.chapterId = [data integerForKey:@"chapter_id"];
        model.courseId = [data integerForKey:@"course_id"];
        model.name = [data stringForKey:@"name"];
        model.seq = [data integerForKey:@"seq"];
        model.hasStudied = [data integerToBoolForKey:@"finished"];
        model.hasPracticed = [data integerToBoolForKey:@"practise_finished"];
        model.isLast = [data integerToBoolForKey:@"last"];
        model.duration = [HDTime timeWithSeconds:[data integerForKey:@"duration"]];
        model.practiseNum = [data integerForKey:@"practise_num"];
        model.noteNum = [data integerForKey:@"note_num"];
        model.videoId = [data integerForKey:@"video_id"];
    }
    
    return model;
}

@end
