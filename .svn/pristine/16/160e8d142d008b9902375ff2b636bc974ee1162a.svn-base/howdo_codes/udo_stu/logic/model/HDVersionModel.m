//
//  HDVersionModel.m
//  udo_stu
//
//  Created by nobody on 6/21/15.
//  All rights reserved.
//

#import "HDVersionModel.h"

@implementation HDVersionModel

+ (instancetype)modelWithData:(id)data {
    
    HDVersionModel *model = [[HDVersionModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.version = [data stringForKey:@"version"];
        model.downloadUrl = [data stringForKey:@"download_url"];
        model.forceUpdate = [data integerToBoolForKey:@"force_update"];
    }
    
    return model;
}

@end
