//
//  HDNoteModel.h
//  udo_stu
//
//  Created by nobody on 6/1/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDNoteModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) HDNoteImageUrl *imageUrl;
@property (nonatomic, assign) NSInteger seq;

@end
