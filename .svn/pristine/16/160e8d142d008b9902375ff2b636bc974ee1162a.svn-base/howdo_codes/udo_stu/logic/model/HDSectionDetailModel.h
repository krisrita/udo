//
//  HDSectionDetailModel.h
//  udo_stu
//
//  Created by nobody on 6/2/15.
//  All rights reserved.
//

#import "HDSectionModel.h"

@interface HDSectionDetailModel : HDSectionModel

@property (nonatomic, strong) HDTeacherModel *teacher;
@property (nonatomic, strong) HDVideoImageUrl *imageUrl;
@property (nonatomic, strong) NSString *videoUrl;
@property (nonatomic, assign) NSInteger watchedNum;
@property (nonatomic, assign) NSInteger likedNum;
@property (nonatomic, assign) NSInteger dislikedNum;
// 标识当前用户是否顶过或踩过该节视频
@property (nonatomic, assign) HDActionStatus actionStatus;

@end
