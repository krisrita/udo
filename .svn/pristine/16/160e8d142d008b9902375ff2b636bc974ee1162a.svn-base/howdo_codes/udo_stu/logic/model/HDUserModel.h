//
//  HDUserModel.h
//  udo_stu
//
//  Created by nobody on 5/30/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDUserModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *nickname;
@property (nonatomic, strong) HDHeadImageUrl *imageUrl;
@property (nonatomic, assign) HDGender gender;
@property (nonatomic, assign) NSInteger mobilephone;
@property (nonatomic, strong) NSString *signature;
@property (nonatomic, assign) NSInteger provId;
@property (nonatomic, assign) NSInteger cityId;
@property (nonatomic, assign) NSInteger regionId;
@property (nonatomic,copy) NSString *proName;
@property (nonatomic,copy) NSString * cityName;
@property (nonatomic,copy) NSString * regionName;
@property (nonatomic, copy) NSString * comeFrome;


+ (instancetype)modelWithAuthorData:(id)data;

-(NSDictionary *)toDictionay;

@end
