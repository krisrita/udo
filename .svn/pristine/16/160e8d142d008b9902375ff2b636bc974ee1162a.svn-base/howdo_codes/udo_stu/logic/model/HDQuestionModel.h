//
//  HDQuestionModel.h
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDQuestionModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *content;
@property (nonatomic, strong) NSString *url;
@property (nonatomic, assign) NSInteger seq;
@property (nonatomic, strong) NSArray *options;
@property (nonatomic, assign) NSInteger num;
@property (nonatomic, assign) NSInteger optionId;

@end
