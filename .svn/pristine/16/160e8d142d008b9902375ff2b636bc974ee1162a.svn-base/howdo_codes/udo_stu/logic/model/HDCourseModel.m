//
//  HDCourseModel.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDCourseModel.h"

@implementation HDCourseModel

+ (instancetype)modelWithData:(id)data {
    
    HDCourseModel *model = [[HDCourseModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"id"];
        model.name = [data stringForKey:@"name"];
        model.imageUrl = [HDCourseImageUrl imageUrlWithName:[data stringForKey:@"image"]];
        model.lastChapterSeq = [data integerForKey:@"last_chapter_seq"];
        model.lastSectionSeq = [data integerForKey:@"last_section_seq"];
        model.chapterNum = [data integerForKey:@"chapter_num"];
        model.sectionNum = [data integerForKey:@"section_num"];
        model.watchedNum = [data integerForKey:@"view_num"];
        model.likedNum = [data integerForKey:@"like_num"];
        model.dislikedNum = [data integerForKey:@"dislike_num"];
        model.commentNum = [data integerForKey:@"comment_num"];
        model.totalDuration = [HDTime timeWithSeconds:[data integerForKey:@"duration"]];
        model.type = [data integerForKey:@"type"];
        model.last_section_name = [data objectForKey:@"last_section_name"];
    }
    
    return model;
}
@end
