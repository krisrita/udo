//
//  HDUserModel.m
//  udo_stu
//
//  Created by nobody on 5/30/15.
//  All rights reserved.
//

#import "HDUserModel.h"

@implementation HDUserModel

+ (instancetype)modelWithData:(id)data {
    
    HDUserModel *model = [[HDUserModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"stuff_id"];
        model.nickname = [data stringForKey:@"stuff_name"];
        model.imageUrl = [HDHeadImageUrl imageUrlWithName:[data stringForKey:@"avator"]];
        model.mobilephone = [data integerForKey:@"mobile"];
        model.signature = [data stringForKey:@"sign"];
        model.gender = [data integerForKey:@"gender"];
        model.provId = [data integerForKey:@"prov_id"];
        model.cityId = [data integerForKey:@"city_id"];
        model.regionId = [data integerForKey:@"area_id"];
        
        NSDictionary * proDic = [data objectForKey:@"prov"];
        if (proDic && [proDic isKindOfClass:[NSDictionary class]])
        {
            NSString * proName = [proDic objectForKey:@"region_name"];
            if (proName && [proName isKindOfClass:[NSString class]]) {
                model.proName = proName;
            }
            model.provId = [proDic integerForKey:@"region_id"];
        }
        
        NSDictionary * cityDic = [data objectForKey:@"city"];
        if (cityDic && [cityDic isKindOfClass:[NSDictionary class]])
        {
            NSString * cityName = [cityDic objectForKey:@"region_name"];
            if (cityName && [cityName isKindOfClass:[NSString class]]) {
                model.cityName = cityName;
            }
            model.cityId = [cityDic integerForKey:@"region_id"];
        }
        
        NSDictionary * regionDic = [data objectForKey:@"area"];
        if (regionDic && [regionDic isKindOfClass:[NSDictionary class]])
        {
            NSString * regionName = [regionDic objectForKey:@"region_name"];
            if (regionName && [regionName isKindOfClass:[NSString class]]) {
                model.regionName = regionName;
            }
            model.cityId = [regionDic integerForKey:@"region_id"];

        }
        //这个字段不是服务器给的 是本地化解析的时候用的
//        model.comeFrome = [data stringForKey:@"comefrom"];

    }
    
    return model;
}

+ (instancetype)modelWithAuthorData:(id)data
{
    HDUserModel *model = [[HDUserModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"author_uid"];
        model.nickname = [data stringForKey:@"author_name"];
        model.imageUrl = [HDHeadImageUrl imageUrlWithName:[data stringForKey:@"author_avator"]];
    }
    
    return model;
}

-(NSString *)checkOutStr:(NSString *)str
{
    if (str && [str isKindOfClass:[NSString class]] && str.length > 0)
    {
        return str;
    }
    return @"";
}


-(NSDictionary *)toDictionay
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:[NSNumber numberWithInteger:self.Id] forKey:@"stuff_id"];
    [dic setObject:[self checkOutStr:self.nickname] forKey:@"stuff_name"];
    [dic setObject:[NSNumber numberWithInteger:self.mobilephone] forKey:@"mobile"];
    [dic setObject:[self checkOutStr:self.imageUrl.imageName] forKey:@"avator"];
    [dic setObject:[NSNumber numberWithInteger:self.gender] forKey:@"gender"];
    [dic setObject:[self checkOutStr:self.signature]  forKey:@"sign"];
    [dic setObject:[NSNumber numberWithInteger:self.cityId] forKey:@"city_id"];
    [dic setObject:[NSNumber numberWithInteger:self.regionId] forKey:@"area_id"];
    
    NSMutableDictionary * proDic = [NSMutableDictionary dictionary];
    if (self.proName && [self.proName isKindOfClass:[NSString class]]) {
        [proDic setObject:self.proName forKey:@"region_name"];
    }
    [proDic setObject:[NSNumber numberWithInteger:self.provId] forKey:@"region_id"];
    [dic setObject:proDic forKey:@"prov"];
    
    
    NSMutableDictionary * cityDic = [NSMutableDictionary dictionary];
    if (self.cityName && [self.cityName isKindOfClass:[NSString class]]) {
        [cityDic setObject:self.cityName forKey:@"region_name"];
    }
    [cityDic setObject:[NSNumber numberWithInteger:self.cityId] forKey:@"region_id"];
    [dic setObject:cityDic forKey:@"city"];
    
    NSMutableDictionary * areaDic = [NSMutableDictionary dictionary];
    if (self.regionName && [self.regionName isKindOfClass:[NSString class]]) {
        [areaDic setObject:self.regionName forKey:@"region_name"];
    }
    [areaDic setObject:[NSNumber numberWithInteger:self.cityId] forKey:@"region_id"];
    [dic setObject:areaDic forKey:@"area"];    
    
    return (NSDictionary *)dic;

}
@end
