//
//  HDSchoolModel.h
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDSchoolModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) HDSchoolImageUrl *imageUrl;
@property (nonatomic, assign) NSInteger cityId;

@end
