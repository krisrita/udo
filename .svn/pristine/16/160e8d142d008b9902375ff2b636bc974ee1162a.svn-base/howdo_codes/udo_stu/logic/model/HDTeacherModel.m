//
//  HDTeacherModel.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDTeacherModel.h"

@implementation HDTeacherModel

+ (instancetype)modelWithData:(id)data {
    
    HDTeacherModel *model = [[HDTeacherModel alloc] init];
    if ([[self class] isValidData:data])  {

        model.Id = [data integerForKey:@"id"];
        model.name = [data stringForKey:@"name"];
        model.introduction = [data stringForKey:@"info"];
        model.title = [data stringForKey:@"job_title"];
        model.imageUrl = [HDHeadImageUrl imageUrlWithName:[data stringForKey:@"avator"]];
    }
    
    return model;
}

@end
