//
//  MCMenuDataModel.h
//
//  Created by nobody on 14-9-1.
//  . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDMenuDataModel : NSObject

@property (nonatomic,copy)  NSString * menuImgStr;
@property (nonatomic,copy)  NSString * menuHighlightImgStr;


@property (nonatomic,copy)  NSString * menuTitle;

@property (nonatomic,assign)BOOL showTag;

@end
