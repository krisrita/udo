//
//  HDVideoModel.m
//  udo_stu
//
//  Created by nobody on 6/17/15.
//  All rights reserved.
//

#import "HDVideoModel.h"

@implementation HDVideoModel

+ (instancetype)modelWithData:(id)data {
    
    HDVideoModel *model = [[HDVideoModel alloc] init];
    if ([[self class] isValidData:data])  {
        model.Id = [data integerForKey:@"video_id"];
        model.imageUrl = [HDVideoImageUrl imageUrlWithName:[data stringForKey:@"video_image"]];
        model.videoUrl = [data stringForKey:@"video_url"];
        model.watchedNum = [data integerForKey:@"video_view_num"];
        model.likedNum = [data integerForKey:@"video_like_num"];
        model.dislikedNum = [data integerForKey:@"video_dislike_num"];
        model.teacher = [HDTeacherModel modelWithData:[data objectForKey:@"teacher"]];
        model.actionStatus = [data integerForKey:@"is_user_like"];
        
    }
    
    return model;
}

@end
