//
//  HDOptionModel.h
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDOptionModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *letterSeq;
@property (nonatomic, strong) NSString *content;
@property (nonatomic, strong) NSString *url;
@property (nonatomic, assign) BOOL selected;

@end
