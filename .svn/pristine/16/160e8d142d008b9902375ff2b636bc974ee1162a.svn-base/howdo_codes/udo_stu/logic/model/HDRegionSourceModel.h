//
//  HDRegionSourceModel.h
//  udo_stu
//
//  Created by nobody on 6/4/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDRegionSourceModel : HDDataModel

- (NSArray *)getProvinces;

- (NSArray *)getCitys:(NSInteger)parentId;

/**
 *  获取市下面的县
 *
 *  @param cityId cityId description
 *
 *  @return return value description
 */
-(NSArray *)getCountys:(NSInteger)cityId;

@end
