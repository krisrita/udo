//
//  HDCourseModel.h
//  udo_stu
//
//  Created by nobody on 15/5/31.
//  All rights reserved.
//

#import "HDDataModel.h"

typedef NS_ENUM(NSInteger, HDCouseListType) {
    HDCouseListTypeCourse, //课程
    HDCouseListTypePaper //试题
};

@interface HDCourseModel : HDDataModel
/// 课程id
@property (nonatomic, assign) NSInteger Id;
/// 课程名，如:华英六年级数学
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) HDCourseImageUrl *imageUrl;
/// 最后观看章
@property (nonatomic, assign) NSInteger lastChapterSeq;
/// 最后观看节
@property (nonatomic, assign) NSInteger lastSectionSeq;
@property (nonatomic, assign) NSInteger lastChapterId;
@property (nonatomic, assign) NSInteger lastSectionId;
/// 章总数
@property (nonatomic, assign) NSInteger chapterNum;
/// 节总数
@property (nonatomic, assign) NSInteger sectionNum;
/// 总共持续时间
@property (nonatomic, strong) HDTime *totalDuration;
/// 播放数
@property (nonatomic, assign) NSInteger watchedNum;
/// 赞数
@property (nonatomic, assign) NSInteger likedNum;
/// 踩数
@property (nonatomic, assign) NSInteger dislikedNum;
@property (nonatomic, assign) NSInteger commentNum;
@property (nonatomic, assign) HDCouseListType type;
/// type为1试卷时 最后看的试卷id
@property (nonatomic, assign) NSInteger last_chapter_id;
/// type为1试卷时 最后观看试卷的名称
@property (nonatomic, copy) NSString *last_section_name;

@end
