//
//  HDQuestionParseModel.h
//  udo_stu
//
//  Created by nobody on 6/11/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDQuestionParseModel : HDDataModel

@property (nonatomic, assign) NSInteger questionId;
@property (nonatomic, assign) NSInteger questionSeq;
@property (nonatomic, strong) NSString *questionContent;
@property (nonatomic, strong) NSString *answerSummary;
@property (nonatomic, strong) NSString *parseWord;
@property (nonatomic, strong) NSString *videoUrl;
@property (nonatomic, assign) NSInteger prevWrongQuestionSeq;
@property (nonatomic, assign) NSInteger nextWrongQuestionSeq;

@end
