//
//  HDChapterModel.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDChapterModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, assign) NSInteger courseId;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, assign) NSInteger seq;
@property (nonatomic, strong) NSArray *sections;
/// 距离开放剩余时间，为<=0， 说明已经开发
@property (nonatomic, strong) HDTime *leftOpenTime;
@property (nonatomic, strong) NSString *leftOpenTimeHint;
/// 是否开放
@property (nonatomic, assign) BOOL hasOpened;
@property (nonatomic, assign) BOOL hasPracticed;
@property (nonatomic, assign) NSInteger practiseNum;

@end
