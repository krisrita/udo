//
//  HDCommentModel.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDCommentModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *content;
@property (nonatomic, strong) HDDate *sentTime;
@property (nonatomic, strong) HDChapterModel *chapter;
@property (nonatomic, strong) HDSectionModel *section;
@property (nonatomic, strong) HDUserModel *sender;
@property (nonatomic, assign) BOOL isReply;
@property (nonatomic, strong) HDUserModel *replyUser;
@property (nonatomic, assign) HDActionStatus actionStatus;

/// 试卷序号，如果该值大于0，说明是试卷评论
@property (nonatomic, assign) NSInteger practise_seq;

@end
