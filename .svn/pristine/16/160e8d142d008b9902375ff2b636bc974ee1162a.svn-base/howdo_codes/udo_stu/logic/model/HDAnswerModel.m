//
//  HDAnswerModel.m
//  udo_stu
//
//  Created by nobody on 6/10/15.
//  All rights reserved.
//

#import "HDAnswerModel.h"

@implementation HDAnswerModel

+ (instancetype)modelWithData:(id)data {
    
    HDAnswerModel *model = [[HDAnswerModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.questionId = [data integerForKey:@"id"];
        model.questionSeq = [data integerForKey:@"seq"];
        model.isCorrect = [data integerToBoolForKey:@"correct"];
        model.videoId = [data integerForKey:@"video_id"];
    }
    
    return model;
}

@end
