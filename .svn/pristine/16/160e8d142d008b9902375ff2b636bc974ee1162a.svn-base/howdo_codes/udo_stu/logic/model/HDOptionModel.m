//
//  HDOptionModel.m
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import "HDOptionModel.h"

@implementation HDOptionModel

+ (instancetype)modelWithData:(id)data {
    
    HDOptionModel *model = [[HDOptionModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"id"];
        model.letterSeq = [data stringForKey:@"letter_seq"];
        model.content = [data stringForKey:@"content"];
        model.url = [data stringForKey:@"url"];
    }
    
    return model;
}

@end
