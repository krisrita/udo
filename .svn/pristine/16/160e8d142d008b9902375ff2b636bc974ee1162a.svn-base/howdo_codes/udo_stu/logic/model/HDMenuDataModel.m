//
//  MCMenuDataModel.m
//
//  Created by nobody on 14-9-1.
//  . All rights reserved.
//

#import "HDMenuDataModel.h"

@implementation HDMenuDataModel

@end
