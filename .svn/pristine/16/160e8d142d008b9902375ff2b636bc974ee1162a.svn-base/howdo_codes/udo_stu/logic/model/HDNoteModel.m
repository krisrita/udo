//
//  HDNoteModel.m
//  udo_stu
//
//  Created by nobody on 6/1/15.
//  All rights reserved.
//

#import "HDNoteModel.h"

@implementation HDNoteModel

+ (instancetype)modelWithData:(id)data {
    
    HDNoteModel *model = [[HDNoteModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"id"];
        model.seq = [data integerForKey:@"seq"];
        model.imageUrl = [HDNoteImageUrl imageUrlWithName:[data stringForKey:@"image"]];
    }
    
    return model;
}

@end
