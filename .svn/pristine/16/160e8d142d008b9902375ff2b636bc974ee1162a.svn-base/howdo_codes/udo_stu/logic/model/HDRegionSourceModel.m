//
//  HDRegionSourceModel.m
//  udo_stu
//
//  Created by nobody on 6/4/15.
//  All rights reserved.
//

#import "HDRegionSourceModel.h"

@interface HDRegionSourceModel ()

@property (nonatomic, strong) NSDictionary *regionData;

@end

@implementation HDRegionSourceModel

+ (instancetype)modelWithData:(id)data
{
    HDRegionSourceModel *model = [[HDRegionSourceModel alloc] init];
    if ([[self class] isValidData:data])  {
        model.regionData = [(NSDictionary *)data copy];
    }
    
    return model;
}

- (NSArray *)getProvinces
{
    return [self getCitys:0];
}

- (NSArray *)getCitys:(NSInteger)parentId;
{
    NSMutableArray *regions = [NSMutableArray array];
    
    NSString *pId = [NSString stringWithFormat: @"%ld", (long)parentId];
    
    if (self.regionData) {
        [self.regionData enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            if ([pId isEqualToString:key]) {
                
                [obj enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
                    HDRegionModel *region = [[HDRegionModel alloc] init];
                    region.Id = [key integerValue];
                    region.name = obj;
                    [regions addObject:region];
                }];
                
                *stop = YES;
            }
        }];
    }
    
    return [regions sortedArrayUsingComparator:^NSComparisonResult(HDRegionModel *p1, HDRegionModel *p2){
        return p1.Id > p2.Id;
    }];
}

-(NSArray *)getCountys:(NSInteger)cityId
{
    if(cityId > 0 )
    {
        NSString * cityIdStr = [[NSString alloc]initWithFormat:@"%ld",(long)cityId ];
        NSArray * ary = [self.regionData objectForKey:cityIdStr];
        return ary;
    }
    return nil;
}

@end
