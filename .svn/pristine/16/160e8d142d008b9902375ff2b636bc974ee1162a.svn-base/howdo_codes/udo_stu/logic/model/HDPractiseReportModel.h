//
//  HDPractiseReportModel.h
//  udo_stu
//
//  Created by nobody on 6/10/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDPractiseReportModel : HDDataModel

// 练习名称
@property (nonatomic, strong) NSString *name;

// 答题时间
@property (nonatomic, strong) NSString *completionTime;

// 正确率
@property (nonatomic, strong) NSString *correctRate;

// 用时
@property (nonatomic, strong) NSString *spentTime;

// 正确率击败的比例
@property (nonatomic, strong) NSString *correctRateBeatRate;

// 答题时间击败的比例
@property (nonatomic, strong) NSString *spentTimeBeatRate;

// 综合排名
@property (nonatomic, strong) NSString *totalRank;

// 排名封号
@property (nonatomic, strong) NSString *rankHonor;

// 答题卡
@property (nonatomic, strong) NSArray *answers;

@end
