//
//  HDCourseIntroModel.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDCourseIntroModel.h"

@implementation HDCourseIntroModel

+ (instancetype)modelWithData:(id)data {
    
    HDCourseIntroModel *model = [[HDCourseIntroModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"id"];
        model.introduction = [data stringForKey:@"info"];
        id teacherList = [data objectForKey:@"teachers"];
        NSMutableArray *teachers = [NSMutableArray array];
        if ([teacherList isKindOfClass:[NSArray class]]) {
            for (NSDictionary *item in (NSArray *)teacherList) {
                if ([item isKindOfClass:[NSDictionary class]]) {
                    HDTeacherModel *teacher =  [HDTeacherModel modelWithData:item];
                    [teachers addObject:teacher];
                }
            }
        }
        model.teachers = [NSArray arrayWithArray:teachers];
    }
    
    return model;
}

@end
