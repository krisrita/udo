//
//  HDRegionModel.m
//  udo_stu
//
//  Created by nobody on 6/4/15.
//  All rights reserved.
//

#import "HDRegionModel.h"

@implementation HDRegionModel

@end
