//
//  HDQuestionModel.m
//  udo_stu
//
//  Created by nobody on 6/6/15.
//  All rights reserved.
//

#import "HDQuestionModel.h"

@implementation HDQuestionModel

+ (instancetype)modelWithData:(id)data {
    
    HDQuestionModel *model = [[HDQuestionModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"subject_id"];
        model.content = [data stringForKey:@"subject_title"];
        model.seq = [data integerForKey:@"subject_seq"];
        model.num = [data integerForKey:@"subject_num"];
        model.url = [data stringForKey:@"url"];
//        if (model.url.length > 0) {
//            NSInteger uid = [HDManager sharedInstance].isLogined ? [HDManager sharedInstance].currentUser.Id : 0;
//            model.url = [model.url stringByAppendingFormat:@"?uid=%d&platform=ios", uid];
//        }
        
        id optionList = [data objectForKey:@"option_list"];
        NSMutableArray *options = [NSMutableArray array];
        if ([optionList isKindOfClass:[NSArray class]]) {
            for (NSDictionary *item in (NSArray *)optionList) {
                if ([item isKindOfClass:[NSDictionary class]]) {
                    HDOptionModel *option =  [HDOptionModel modelWithData:item];
                    [options addObject:option];
                }
            }
        }
        model.options = [NSArray arrayWithArray:options];
    }
    
    return model;
}

@end
