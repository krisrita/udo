//
//  HDQuestionParseModel.m
//  udo_stu
//
//  Created by nobody on 6/11/15.
//  All rights reserved.
//

#import "HDQuestionParseModel.h"

@implementation HDQuestionParseModel

+ (instancetype)modelWithData:(id)data {
    
    HDQuestionParseModel *model = [[HDQuestionParseModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.questionId = [data integerForKey:@"subject_id"];
        model.questionSeq = [data integerForKey:@"subject_seq"];
        model.questionContent = [data stringForKey:@"subject_title"];
        model.answerSummary = [data stringForKey:@"word"];
        model.parseWord = [data stringForKey:@"node_parse"];
        model.videoUrl = [data stringForKey:@"video_url"];
        model.prevWrongQuestionSeq = [data integerForKey:@"prev_seq"];
        model.nextWrongQuestionSeq = [data integerForKey:@"next_seq"];
    }
    
    return model;
}

@end
