//
//  HDCourseIntroModel.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDCourseIntroModel : HDDataModel

@property (nonatomic, assign) NSInteger Id;
@property (nonatomic, strong) NSString *introduction;
@property (nonatomic, strong) NSArray *teachers;

@end
