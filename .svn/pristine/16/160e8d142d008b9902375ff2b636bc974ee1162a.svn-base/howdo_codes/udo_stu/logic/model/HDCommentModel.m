//
//  HDCommentModel.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//
#import "NSDictionary+DataValue.h"
#import "HDCommentModel.h"

@implementation HDCommentModel

+ (instancetype)modelWithData:(id)data {
    
    HDCommentModel *model = [[HDCommentModel alloc] init];
    if ([[self class] isValidData:data])  {
        
        model.Id = [data integerForKey:@"id"];
        model.content = [data stringForKey:@"content"];
        model.sentTime = [HDDate dateWithSeconds:[data integerForKey:@"create_time"]];
        model.actionStatus = [data integerForKey:@"video_like"];
    
        model.chapter = [[HDChapterModel alloc] init];
        model.chapter.Id = [data integerForKey:@"chapter_id"];
        model.chapter.name = [data stringForKey:@"chapter_name"];
        model.chapter.seq = [data integerForKey:@"chapter_seq"];
        
        model.section = [[HDSectionModel alloc] init];
        model.section.Id = [data integerForKey:@"section_id"];
        model.section.name = [data stringForKey:@"section_name"];
        model.section.seq = [data integerForKey:@"section_seq"];
        
        model.sender = [HDUserModel modelWithAuthorData:data];
        
        model.isReply = [data integerToBoolForKey:@"comment_id"];
        model.replyUser = [HDUserModel modelWithAuthorData:[data objectForKey:@"parent_comment"]];
        
        model.practise_seq = [[data objectForKey:@"practise_seq"] integerValue];
    }
    
    return model;
}

@end
