//
//  HDUpgrade.m
//  udo_stu
//
//  Created by nobody on 6/21/15.
//  All rights reserved.
//

#import "HDUpgrade.h"

#define TAG_UPDATE_ALERT_VIEW        101
#define TAG_UPDATE_ALERT_VIEW_FORCE  102

@interface HDUpgrade () <UIAlertViewDelegate> {
    NSString *_newAppDownloadUrl;
}
@end

@implementation HDUpgrade

+ (instancetype)sharedInstance
{
    static HDUpgrade *sharedInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        sharedInstance = [[HDUpgrade alloc] init];
    });
    
    return sharedInstance;
}

- (NSString *)getAppVersion
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    return app_Version;
}

- (BOOL)hasNewVersion:(HDVersionModel *)serverVersion
{
    BOOL bRet = NO;
    
    if (serverVersion) {
        NSString *lastVersion = serverVersion.version;
        NSString *currVersion = [self getAppVersion];
        
        if ([lastVersion compareToIgnoreCase:currVersion] > 0) {
            bRet = YES;
        }
    }
    
    return bRet;
}

- (void)checkNewVersion:(BOOL)isAutomatic
{
    BOOL ignoreAlert = NO;
    
    if (!isAutomatic) {
        [HDLoading startAnimating:@"正在检测更新..."];
    }
    
    NSString *appid = APP_ID;
    
    [[HDManager sharedInstance].appService getLastVersion:appid resultBack:^(HDServiceResult *result, id object) {
        if (!isAutomatic) {
            [HDLoading stopAnimating];
        }
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            HDVersionModel *versionModel = (HDVersionModel *)object;
            if ([self hasNewVersion:versionModel]) {
                self.hasNewVersion = YES;
                _newAppDownloadUrl = versionModel.downloadUrl;
                if (!ignoreAlert) {
                    dispatch_async(dispatch_get_main_queue(), ^{

                        if (versionModel.forceUpdate){
                            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"升级提醒" message:@"新版本已发布，请更新" delegate:self cancelButtonTitle:nil otherButtonTitles:@"去更新", nil];
                            [alertView setTag:TAG_UPDATE_ALERT_VIEW_FORCE];
                            [alertView show];
                        }
                        else {
                            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"升级提醒" message:@"新版本已发布，请更新" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"去更新", nil];
                            [alertView setTag:TAG_UPDATE_ALERT_VIEW];
                            [alertView show];
                        }
                    });
                }
            }
            else if (!isAutomatic) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"已经是最新版本" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                    [alertView show];
                });
            }
        }
        else if (!isAutomatic) {
            dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"没有检测到新版本" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alertView show];
            });
        }
    }];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ((TAG_UPDATE_ALERT_VIEW == alertView.tag && 1 == buttonIndex) || (TAG_UPDATE_ALERT_VIEW_FORCE == alertView.tag && 0 == buttonIndex)) {
        if (_newAppDownloadUrl) {
            // TODO 测试
            NSURL *url1 = [NSURL URLWithString:_newAppDownloadUrl]; //优先打开，
            NSURL *url2 = [NSURL URLWithString:@"http://www.howdo.cc"]; //备用url
            UIApplication *app = [UIApplication sharedApplication];
            if ([app canOpenURL:url1]) {
                [app openURL:url1];
                return;
            }
            if ([app canOpenURL:url2]) {
                [app openURL:url2];
            }
//            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:_newAppDownloadUrl]];
//            exit(0);
        }
    }
}

@end
