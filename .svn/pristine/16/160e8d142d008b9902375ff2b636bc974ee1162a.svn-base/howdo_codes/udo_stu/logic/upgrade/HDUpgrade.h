//
//  HDUpgrade.h
//  udo_stu
//
//  Created by nobody on 6/21/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@interface HDUpgrade : NSObject

@property (nonatomic, assign) BOOL hasNewVersion;

+ (instancetype)sharedInstance;

- (void)checkNewVersion:(BOOL)isAutomatic;

@end
