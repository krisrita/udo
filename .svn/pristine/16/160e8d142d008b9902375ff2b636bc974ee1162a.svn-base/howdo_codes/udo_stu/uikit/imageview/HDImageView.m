//
//  HDImageView.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDImageView.h"
#import "UIImage+RoundedCorner.h"
#import "UIImageView+WebCache.h"
#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)
@interface HDImageView ()
@property (nonatomic,weak)id delegate;
@property (nonatomic,assign)SEL action;
@end

@implementation HDImageView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        self.userInteractionEnabled = YES;
    }
    return self;
}
- (instancetype)init
{
    if (self = [super init]) {
        self.userInteractionEnabled = YES;
    }
    return self;
}



- (void)addTarget:(id)target action:(SEL)action
{
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onClick:)];
    [self addGestureRecognizer:singleTap];
    NSParameterAssert(target);
    NSParameterAssert(action);
    _delegate = target;
    _action = action;
}

#pragma mark - UIView's methods

- (void)onClick:(UITapGestureRecognizer *)tap
{
    if (_delegate && [_delegate respondsToSelector:_action]) {
        SuppressPerformSelectorLeakWarning([_delegate performSelector:_action withObject:self]);
    }
}

- (void)setHDImageURL:(NSURL *)imageURL placeholderImage:(UIImage *)placeholderImage imageType:(HDImageType)imageType
{
      __weak __typeof(self) weakSelf = self;
    
    [self sd_setImageWithURL:imageURL placeholderImage:placeholderImage completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (!image) {
            return ;
        }
        switch (imageType) {
            case HD_IMAGE_SQUARE:
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakSelf.image = image;
                });
            }
                
                break;
            case HD_IMAGE_CIRCLE:
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                   
                        CGFloat scaleImg = image.size.width/image.size.height;
                        CGRect rect = CGRectMake(0, 0, image.size.width*image.scale, image.size.width*image.scale);
                        if (scaleImg > 1) {
                            CGFloat originX = (image.size.width*image.scale - image.size.height * image.scale)/2;
                            rect = CGRectMake(originX, 0, image.size.height * image.scale, image.size.height * image.scale);
                        }else
                        {
                            rect = CGRectMake(0, 0, image.size.width*image.scale, image.size.width*image.scale);
                        }
                        CGImageRef cgimg = CGImageCreateWithImageInRect([image CGImage], rect);
                        UIImage *clipImage =[[UIImage imageWithCGImage:cgimg] clipImage:weakSelf.bounds];
                        CGImageRelease(cgimg);
                        
                        weakSelf.image = clipImage;

                });
                
                
            }
                break;
                
            default:
                break;
        }

    }];
}

@end
