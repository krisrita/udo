//
//  HDImageView.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_OPTIONS(NSUInteger, HDImageType) {
    HD_IMAGE_SQUARE = 0,
    HD_IMAGE_CIRCLE
};

@interface HDImageView : UIImageView

- (void)setHDImageURL:(NSURL *)imageURL placeholderImage:(UIImage *)placeholderImage imageType:(HDImageType)imageType;
- (void)addTarget:(id)target action:(SEL)action;

@end
