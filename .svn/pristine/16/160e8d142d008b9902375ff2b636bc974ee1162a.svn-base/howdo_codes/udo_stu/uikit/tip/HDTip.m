//
//  HDTip.m
//
//  Created by nobody on 14-2-18.
//  All rights reserved.
//

#import "HDTip.h"
#import "BSNotify.h"

#define HD_TIP_DURATION 2.0f

@implementation HDTip

+ (void)showMessage:(NSString *)message
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *view = [[UIApplication sharedApplication] keyWindow];
        [[self class] showMessage:message inView:view duration:HD_TIP_DURATION];
    });
}

+ (void)showMessage:(NSString *)message complete:(BSDismissBlcok)block
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *view = [[UIApplication sharedApplication] keyWindow];
        [BSNotify showMessage:message inView:view duration:HD_TIP_DURATION complete:block];

    });
}


+ (void)showMessage:(NSString *)message inView:(UIView *)view
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[self class] showMessage:message inView:view duration:HD_TIP_DURATION];
    });
}

+ (void)showMessage:(NSString *)message duration:(CGFloat)duration
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *view = [[UIApplication sharedApplication] keyWindow];
        [[self class] showMessage:message inView:view duration:duration];
    });
}

+ (void)showMessage:(NSString *)message inView:(UIView *)view duration:(CGFloat)duration
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [BSNotify showMessage:message inView:view duration:duration];
    });
}

+ (void)showSystemAlartTitle:(NSString *)title message:(NSString *)message
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView * alart = [[UIAlertView alloc]initWithTitle:title message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alart show];
    });
   
}

@end
