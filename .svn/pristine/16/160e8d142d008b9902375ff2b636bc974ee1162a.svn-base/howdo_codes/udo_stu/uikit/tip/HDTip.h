//
//  HDTip.h
//
//  Created by nobody on 14-2-18.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^BSDismissBlcok)(void);

@interface HDTip : NSObject

+ (void)showMessage:(NSString *)message;
+ (void)showMessage:(NSString *)message inView:(UIView *)view;
+ (void)showMessage:(NSString *)message duration:(CGFloat)duration;
+ (void)showMessage:(NSString *)message inView:(UIView *)view duration:(CGFloat)duration;
+ (void)showSystemAlartTitle:(NSString *)title message:(NSString *)message;
+ (void)showMessage:(NSString *)message complete:(BSDismissBlcok)block;

@end
