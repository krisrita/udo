//
//  BSNotify.h
//  
//
//  Created by nobody on 13-8-14.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^BSDismissBlcok)(void);

@interface BSNotify : UIView

+ (void)showMessage:(NSString *)message inView:(UIView *)view duration:(CGFloat)duration;
+ (void)showMessage:(NSString *)message inView:(UIView *)view duration:(CGFloat)duration complete:(BSDismissBlcok)block;

@end
