//
//  HDBlankPageView.m
//  udo-stu
//
//  Created by nobody on 15/5/27.
//  All rights reserved.
//

#import "HDBlankPageView.h"

@implementation HDBlankPageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.imgView = [[UIImageView alloc]initWithFrame:CGRectMake((frame.size.width - 59)/2, frame.size.height*.32, 59,59)];
        [self addSubview:self.imgView];
        
        self.Label = [[UILabel alloc]initWithFrame:CGRectMake(0, self.imgView.frame.origin.y + self.imgView.frame.size.height + 10, APP_SCREEN_WIDTH, 30 )];
        self.Label.textColor = [UIColor blackColor];
        self.Label.textAlignment = NSTextAlignmentCenter;
        self.Label.backgroundColor = [UIColor clearColor];
        self.Label.text = @"";
        [self addSubview:self.Label];
        
        self.detailLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, self.Label.frame.origin.y + self.Label.frame.size.height, APP_SCREEN_WIDTH, 30 )];
        self.detailLabel.textColor = [UIColor blackColor];
        self.detailLabel.textAlignment = NSTextAlignmentCenter;
        self.detailLabel.backgroundColor = [UIColor clearColor];
        self.detailLabel.textColor = [UIColor blackColor];
        self.detailLabel.font = [UIFont systemFontOfSize:15];
        [self addSubview:self.detailLabel];
        self.backgroundColor = [UIColor clearColor];
        
        
    }
    return self;
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    
    self.imgView.frame =CGRectMake((self.frame.size.width - 59)/2, self.frame.size.height*.32, 59,59);
    self.Label.frame = CGRectMake(0, self.imgView.frame.origin.y + self.imgView.frame.size.height + 10, APP_SCREEN_WIDTH, 30 );
    
    self.detailLabel.frame =CGRectMake(0, self.Label.frame.origin.y + self.Label.frame.size.height, APP_SCREEN_WIDTH, 30 );
}
- (id)initWithFrameIfNetworkFailure:(CGRect)frame
{
    return [self initWithFrame:frame];;
}


@end
