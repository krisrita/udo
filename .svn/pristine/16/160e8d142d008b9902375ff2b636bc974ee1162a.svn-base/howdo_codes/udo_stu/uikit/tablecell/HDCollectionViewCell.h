//
//  HDCollectionViewCell.h
//  udo-stu
//
//  Created by nobody on 15/5/27.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HDTableViewCellDelegate.h"

@interface HDCollectionViewCell : UICollectionViewCell

@property (nonatomic,weak) id delegate;
@property (nonatomic,strong) id cellData;

@end
