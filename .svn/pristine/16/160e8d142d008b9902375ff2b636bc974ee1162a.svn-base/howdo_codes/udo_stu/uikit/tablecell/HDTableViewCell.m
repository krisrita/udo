//
//  HDTableViewCell.m
//  udo-stu
//
//  Created by nobody on 15/5/27.
//  All rights reserved.
//

#import "HDTableViewCell.h"

@implementation HDTableViewCell

@synthesize cellData = _cellData;

- (void)awakeFromNib {
    // Initialization code
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
    }
    return self;
}


-(void)setCellData:(id)cellData
{
    if (cellData != _cellData)
    {
        _cellData = cellData;
    }
}

+(float)dynamicHeight:(id)data
{
    return 0;
}

+(float)fixedHeight
{
    return 43;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
