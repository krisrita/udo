//
//  HDBlankPageView.h
//  udo-stu
//
//  Created by nobody on 15/5/27.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDBlankPageView : UIView

@property (nonatomic,strong) UILabel * Label;
@property (nonatomic,strong) UILabel * detailLabel;
@property (nonatomic,strong) UIImageView * imgView;

- (id)initWithFrameIfNetworkFailure:(CGRect)frame;

@end
