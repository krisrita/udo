//
//  HDTableViewCellDelegate.h
//  udo_stu
//
//  Created by nobody on 15/6/13.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol HDTableViewCellDelegate <NSObject>

@optional
- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag;
- (void)HDTableviewRefresh;

@end
