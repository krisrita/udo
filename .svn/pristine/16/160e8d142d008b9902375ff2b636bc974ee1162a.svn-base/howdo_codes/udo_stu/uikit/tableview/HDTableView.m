//
//  HDTableView.m
//  udo-stu
//
//  Created by nobody on 15/5/27.
//  All rights reserved.
//

#import "HDTableView.h"
#import "RFQuiltLayout.h"

@interface HDTableView ()< RFQuiltLayoutDelegate>
{
    NSString * cellStyle;
    id table;
    Class cellClass;
    HDCellHeightType rowHeightType;
    HDBlankPageView * blankView;
    HDBlankPageView * networkFailureView;
    Class blankViewClass;
    BOOL deleteStyle;
    UIEdgeInsets sectionInset;
    HDScrollDirection scrollDirection;
    
}

/**
 *  tableview数据源
 */
@property (nonatomic, strong) NSMutableArray *tableAry;

//@property (nonatomic, assign) BOOL isNetworkFailure;

@end

@implementation HDTableView

-(void)dealloc
{
    ((UITableView *)table).delegate = nil;
    ((UITableView *)table).dataSource = nil;
    table = nil;
}


-(id)initWithFrame:(CGRect)frame
     cellClassName:(__unsafe_unretained Class)className
          itemSize:(CGSize)size
      sectionInset:(UIEdgeInsets)edgeInsets
    blankViewClass:(__unsafe_unretained Class)blankClass
       refreshType:(HDTableRefreshType)type
{
    self = [super initWithFrame:frame];
    if (self)
    {
        deleteStyle = NO;
        cellClass = className;
        blankViewClass = blankClass;
        scrollDirection = HD_SCROLL_DIRECTION_NONE;
        
        RFQuiltLayout *flowLayout = [[RFQuiltLayout alloc] init];
        flowLayout.blockPixels = size;
        flowLayout.direction = UICollectionViewScrollDirectionVertical;
        flowLayout.delegate = self;
        sectionInset = edgeInsets;
        
        
        //创建一屏的视图大小
        table = (PullCollectionView *)[[PullCollectionView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) collectionViewLayout:flowLayout andWithRefreshType:type];
        [table registerClass:[cellClass class] forCellWithReuseIdentifier:NSStringFromClass(cellClass)];
        [table setBackgroundColor:[UIColor clearColor]];
        [table setUserInteractionEnabled:YES];
        [(PullCollectionView *)table setDelegate:self];
        [table setDataSource:self];
        [table setPullDelegate:self];
        [self addSubview:table];
        
    }
    return self;
}

- (id)initDeleteStyleTableWithFrame:(CGRect)frame
                      rowHeightType:(HDCellHeightType)type
                      cellClassName:(__unsafe_unretained Class)className
                     blankViewClass:(__unsafe_unretained Class)blankClass
                        refreshType:(HDTableRefreshType)refreshType
{
    self = [super initWithFrame:frame];
    if (self)
    {
        deleteStyle = YES;
        cellClass = className;
        blankViewClass = blankClass;
        scrollDirection = HD_SCROLL_DIRECTION_NONE;
        
        rowHeightType = type;
        cellStyle = NSStringFromClass(cellClass);
        table =(PullTableView *) [[PullTableView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(frame), CGRectGetHeight(frame)) refeshType:refreshType];
        [(PullTableView *)table setDelegate:self];
        [table setDataSource:self];
        [table setPullDelegate:self];
        [table setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        ((PullTableView*)table).backgroundColor = [UIColor clearColor];
        [self addSubview:table];
        
    }
    return self;
    
}

- (id)initWithFrame:(CGRect)frame
      rowHeightType:(HDCellHeightType)type
      cellClassName:(__unsafe_unretained Class)className
     blankViewClass:(__unsafe_unretained Class)blankClass
        refreshType:(HDTableRefreshType)refreshType

{
    self = [super initWithFrame:frame];
    if (self)
    {
        cellClass = className;
        blankViewClass = blankClass;
        scrollDirection = HD_SCROLL_DIRECTION_NONE;
        rowHeightType = type;
        cellStyle = NSStringFromClass(cellClass);
        table =(PullTableView *) [[PullTableView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(frame), CGRectGetHeight(frame)) refeshType:refreshType];
        
        [(PullTableView *)table setDelegate:self];
        [table setDataSource:self];
        [table setPullDelegate:self];
        [table setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        ((PullTableView*)table).backgroundColor = [UIColor clearColor];
        [self addSubview:table];
        
    }
    return self;
}
- (void)layoutSubviews
{
    ((PullTableView *)table).frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
    
    blankView.frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
}

- (void)setTableViewEdgeinsets:(UIEdgeInsets)tableViewEdgeinsets
{
    if ([table isKindOfClass:[PullTableView class]]) {
        ((PullTableView *)table).frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
        UIEdgeInsets insets = ((PullTableView *)table).contentInset;
        insets.top = tableViewEdgeinsets.top;
        ((PullTableView *)table).contentInsetCustom = insets;
        ((PullTableView *)table).scrollIndicatorInsets = insets;
    }
    else if ([table isKindOfClass:[PullCollectionView class]]) {
        ((PullCollectionView *)table).frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
        UIEdgeInsets insets = ((PullCollectionView *)table).contentInset;
        insets.top = tableViewEdgeinsets.top;
        ((PullCollectionView *)table).contentInset = insets;
        
        ((PullCollectionView *)table).scrollIndicatorInsets = insets;
       
    }

    
}
-(void)setHDTableIsLoadingMore:(BOOL)HDTableIsLoadingMore
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (HDTableIsLoadingMore != ((PullTableView *)table).pullTableIsLoadingMore)
        {
            ((PullTableView *)table).pullTableIsLoadingMore = HDTableIsLoadingMore;
        }
    });
}

-(void)setHDTableIsRefreshing:(BOOL)HDTableIsRefreshing
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (HDTableIsRefreshing != ((PullTableView *)table).pullTableIsRefreshing)
        {
            ((PullTableView *)table).pullTableIsRefreshing = HDTableIsRefreshing;
        }
    });
}

-(void)setHDloadMoreViewHide:(BOOL)HDloadMoreViewHide
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (HDloadMoreViewHide != ((PullTableView *)table).loadMoreViewHide)
        {
            ((PullTableView *)table).loadMoreViewHide = HDloadMoreViewHide;
        }
    });
    
}

- (void)setScrollEnabled:(BOOL)scrollEnabled
{
    if ([table isKindOfClass:[PullTableView class]]) {
        PullTableView *tableView = (PullTableView *)table;
        tableView.scrollEnabled = scrollEnabled;
    }
    else if ([table isKindOfClass:[PullCollectionView class]]) {
        PullCollectionView *tableView = (PullCollectionView *)table;
        tableView.scrollEnabled = scrollEnabled;
    }
}

- (void)setHeadView:(UIView *)headView
{
    if ([table isKindOfClass:[PullTableView class]]) {
        PullTableView *tableView = (PullTableView *)table;
        tableView.tableHeaderView = headView;
        tableView.tableFooterView.userInteractionEnabled = YES;
    }else if ([table isKindOfClass:[PullCollectionView class]]){
        [table addSubview:headView];
    }
}
#pragma - mark tableView代理

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (rowHeightType == HD_CELL_HEIGHT_TYPE_DYNAMIC)
    {
        if (indexPath.row < self.tableAry.count)
        {
            id data = [self.tableAry objectAtIndex:indexPath.row];
            return [cellClass dynamicHeight:data];
        }
        return 0;
    }else{
        if (indexPath.row<self.tableAry.count-1) {
            return [cellClass fixedHeight];
        }else{
            return [cellClass fixedHeight]+10;
        }
    }
    return [cellClass fixedHeight];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.tableAry.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HDTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellStyle];
    if (cell == nil)
    {
        cell = [[[cellClass class] alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellStyle];
        
    }
    cell.delegate = self.hdTableViewDelegate;//为了标注同一个对象，不需要多个传递
    if (indexPath.row < self.tableAry.count)
    {
        cell.cellData = [self.tableAry objectAtIndex:indexPath.row];
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row < self.tableAry.count)
    {
        if (self.hdTableViewDelegate && [self.hdTableViewDelegate respondsToSelector:@selector(HDTableViewDidSelected:didSelectRowAtIndexPath:)])
        {
            id data = [self.tableAry objectAtIndex:indexPath.row];
            [self.hdTableViewDelegate HDTableViewDidSelected:data didSelectRowAtIndexPath:indexPath];
        }
    }
}

- (void)refresh
{
    [self reloadTableData];
}

-(void)setTableDataWithAry:(NSArray *)dataAry
{
    if (self.tableAry) {
        [self.tableAry removeAllObjects];
    }
    if ([dataAry isKindOfClass:[NSMutableArray class]]){
        self.tableAry = [NSMutableArray arrayWithArray:dataAry];
    }else{
        self.tableAry = [NSMutableArray arrayWithArray:dataAry];
    }
    ((PullTableView *)table).loadMoreViewHide = NO;
    [self reloadTableData];
}

-(void)setTableDataWithAryNoRemoveBefore:(NSArray *)dataAry
{
    if ([dataAry isKindOfClass:[NSMutableArray class]]){
        self.tableAry = (NSMutableArray *)dataAry;
    }else{
        self.tableAry = [NSMutableArray arrayWithArray:dataAry];
    }
    [self reloadTableData];
    
}

-(void)setTableNetworkFailure
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.tableAry || self.tableAry.count == 0)
        {
            if (blankView != nil)
            {
                [blankView removeFromSuperview ];
                blankView = nil;
            }
            if (blankView == nil)
            {
                blankView = [[[blankViewClass class] alloc] initWithFrameIfNetworkFailure:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
                [table addSubview:blankView];
                ((PullTableView *) table).loadMoreViewHide = YES;
            }
        }
        else
        {
            if (blankView != nil)
            {
                [blankView removeFromSuperview];
                blankView = nil;
            }
        }
        [table reloadData];
        
    });
}

-(void)tableAppendDataWithAry:(NSArray *)appendDataAry
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (appendDataAry && [appendDataAry count] > 0)
        {
            if (self.tableAry)
            {
                @synchronized(self.tableAry)
                {
                    [self.tableAry addObjectsFromArray:appendDataAry];
                    
                    if ([table isKindOfClass:[UITableView class]])
                    {
                        NSMutableArray *insertIndexPaths = [[NSMutableArray alloc]init];
                        for (id node in appendDataAry)
                        {
                            NSIndexPath *newPath = [NSIndexPath indexPathForRow:[self.tableAry indexOfObject:node] inSection:0];
                            [insertIndexPaths addObject:newPath];
                        }
                        [table insertRowsAtIndexPaths:insertIndexPaths withRowAnimation:UITableViewRowAnimationFade];
                    }
                    else
                    {
                        [self reloadTableData];
                    }
                    
                }
            }
        }
        else
        {
            ((PullTableView *)table).loadMoreViewHide = YES;
        }
    });
}

-(void)tableInsertDataWithObject:(id)object
{
    if(object)
    {
        if (self.tableAry)
        {
            [self.tableAry insertObject:object atIndex:0];
            [self reloadTableData];
            dispatch_async(dispatch_get_main_queue(), ^{
                if ([table isKindOfClass:[UITableView class]])
                {
                    [table setContentOffset:CGPointMake(0,0) animated:NO];
                }
            });
        }
    }
}


-(NSMutableArray *)getTableDataAry
{
    return self.tableAry;
}

-(UITableView *)getTable
{
    if ([table isKindOfClass:[UITableView class]])
    {
        return table;
    }
    return nil;
}


-(void)reloadTableData
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.tableAry || self.tableAry.count == 0)
        {
            if (blankView != nil)
            {
                [blankView removeFromSuperview ];
                blankView = nil;
            }
            
            if (blankView == nil)
            {
                blankView = [[[blankViewClass class] alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
                [table addSubview:blankView];
                ((PullTableView *) table).loadMoreViewHide = YES;
            }
        }
        else
        {
            if (blankView != nil)
            {
                [blankView removeFromSuperview];
                blankView = nil;
            }
        }
        [table reloadData];
    });
}

-(void)reloadRowsWithRow:(int)row
{
    if ([table isKindOfClass:[UITableView class]])
    {
        NSIndexPath *indexPath=[NSIndexPath indexPathForRow:row inSection:0];
        [table reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    }
}

- (NSIndexPath *)indexPathForCell:(id)cell
{
    return [table indexPathForCell:cell];
}

#pragma - mark collectview代理

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.tableAry count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)acollectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HDCollectionViewCell *  cell = [acollectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass(cellClass) forIndexPath:indexPath];
    cell.cellData = [self.tableAry objectAtIndex:indexPath.row];
    cell.delegate = self.hdTableViewDelegate;
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row < self.tableAry.count)
    {
        if (self.hdTableViewDelegate && [self.hdTableViewDelegate respondsToSelector:@selector(HDTableViewDidSelected:didSelectRowAtIndexPath:)])
        {
            id data = [self.tableAry objectAtIndex:indexPath.row];
            [self.hdTableViewDelegate HDTableViewDidSelected:data didSelectRowAtIndexPath:indexPath];
        }
    }
}


#pragma mark - pullTableView代理
- (void)pullTableViewDidTriggerRefresh:(PullTableView*)pullTableView;
{
    double delayInSeconds = .3;
    dispatch_time_t delayInNanoSeconds =dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_queue_t concurrentQueue =dispatch_get_main_queue();
    dispatch_after(delayInNanoSeconds, concurrentQueue, ^(void) {
        if (self.hdTableViewDelegate && [self.hdTableViewDelegate respondsToSelector:@selector(HDTableViewDidTriggerRefresh:)])
        {
            [self.hdTableViewDelegate HDTableViewDidTriggerRefresh:self];
        }
    });
}

- (void)pullTableViewDidTriggerLoadMore:(PullTableView *)pullTableView
{
    //    double delayInSeconds = .3;
    //    dispatch_time_t delayInNanoSeconds =dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    //    dispatch_queue_t concurrentQueue =dispatch_get_main_queue();
    //    dispatch_after(delayInNanoSeconds, concurrentQueue, ^(void) {
    if (self.hdTableViewDelegate && [self.hdTableViewDelegate respondsToSelector:@selector(HDTableViewDidTriggerLoadMore:)])
    {
        [self.hdTableViewDelegate HDTableViewDidTriggerLoadMore:self];
    }
    //    });
}


#pragma mark pullCollectionView代理
- (void)pullCollectionViewDidTriggerRefresh:(PullCollectionView*)pullTableView
{
    double delayInSeconds = .3;
    dispatch_time_t delayInNanoSeconds =dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_queue_t concurrentQueue =dispatch_get_main_queue();
    dispatch_after(delayInNanoSeconds, concurrentQueue, ^(void) {
        if (self.hdTableViewDelegate && [self.hdTableViewDelegate respondsToSelector:@selector(HDTableViewDidTriggerRefresh:)])
        {
            [self.hdTableViewDelegate HDTableViewDidTriggerRefresh:self];
        }
    });
}

- (void)pullCollectionViewDidTriggerLoadMore:(PullCollectionView*)pullTableView
{
    if (self.hdTableViewDelegate && [self.hdTableViewDelegate respondsToSelector:@selector(HDTableViewDidTriggerLoadMore:)])
    {
        [self.hdTableViewDelegate HDTableViewDidTriggerLoadMore:self];
    }
}


-(void)HDTableViewDeleteRowsAtIndex:(int)index
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (index<self.tableAry.count)
        {
            [self.tableAry removeObjectAtIndex:index];
            [table deleteRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:index inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
        }
        if (self.tableAry.count == 0) {
            [self reloadTableData];
        }
    });
}

#pragma mark – RFQuiltLayoutDelegate

- (CGSize) blockSizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    return CGSizeMake(1, 1);
}

- (UIEdgeInsets) insetsForItemAtIndexPath:(NSIndexPath *)indexPath {
    //    return sectionInset;
    return UIEdgeInsetsMake(1, 1,1, 1);
}
#pragma mark - scrollview代理

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
   
    if (self.hdTableViewDelegate && [self.hdTableViewDelegate respondsToSelector:@selector(scrollViewDidScroll:)]) {
        [self.hdTableViewDelegate scrollViewDidScroll:scrollView];
    }
}
@end
