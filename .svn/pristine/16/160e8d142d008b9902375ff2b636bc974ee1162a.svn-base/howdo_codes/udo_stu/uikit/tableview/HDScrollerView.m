//
//  HDScrollerView.m
//
//  Created by Jay on 14-7-15.
//  All rights reserved.
//

#import "HDScrollerView.h"
@interface HDScrollerView()
{
    __weak UITableView *_tableView;
    __weak UIImageView *_scrollBar;
    CGSize _savedTableViewSize;
}
- (void)updateDisplayWithCell:(UITableViewCell *)cell;
@end

@implementation HDScrollerView
#pragma mark - init
- (id)initWithDelegate:(id <HDScrollerViewDelegate>)delegate
            dataSource:(id<HDScrollerViewDataSource>)datasource{
    self = [super initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 31)];
    if (self) {
        self.delegate = delegate;
        self.dataSource = datasource;
        [self initialize];
    }
    return self;
}

- (void)initialize
{
        self.backgroundView = [[UIImageView alloc] init];
        _backgroundView.frame = CGRectMake(CGRectGetWidth(self.frame) - 80.0f, 0.0f, 80.0f, CGRectGetHeight(self.frame));
        _backgroundView.backgroundColor = [UIColor blackColor];
        [self addSubview:_backgroundView];
}

- (void)captureTableViewAndScrollBar
{
    _tableView = [self.dataSource tableViewForScroller:self];
    
    self.frame = CGRectMake(CGRectGetWidth(self.frame) - 10.0f, 0.0f, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
    
    for (id subview in [_tableView subviews])
    {
        if ([subview isKindOfClass:[UIImageView class]])
        {
            UIImageView *imageView = (UIImageView *)subview;
            
            if (imageView.frame.size.width == 7.0f || imageView.frame.size.width == 5.0f || imageView.frame.size.width == 3.5f)
            {
                if (imageView.frame.size.height != 3.5f) {
                    imageView.clipsToBounds = NO;
                    [imageView addSubview:self];
                    _scrollBar = imageView;
                    _savedTableViewSize = _tableView.frame.size;
                }
                
            }
        }
    }
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (!_tableView || !_scrollBar)
    {
        [self captureTableViewAndScrollBar];
    }
    
    [self checkChanges];
    
    if (!_scrollBar)
    {
        return;
    }
    
    CGRect selfFrame = self.frame;
    CGRect scrollBarFrame = _scrollBar.frame;
    
    self.frame = CGRectMake(CGRectGetWidth(selfFrame) * -1.0f,
                            (CGRectGetHeight(scrollBarFrame) / 2.0f) - (CGRectGetHeight(selfFrame) / 2.0f),
                            CGRectGetWidth(selfFrame),
                            CGRectGetHeight(_backgroundView.frame));
    
    CGPoint point = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMidY(self.frame));
    point = [_scrollBar convertPoint:point toView:_tableView];
    
    UITableViewCell* cell=[_tableView cellForRowAtIndexPath:[_tableView indexPathForRowAtPoint:point]];
    if (cell) {
        [self updateDisplayWithCell:cell];
        if (![self alpha])
        {
            [UIView animateWithDuration:0.2f delay:0.0f options:UIViewAnimationOptionCurveEaseOut animations:^{
                [self setAlpha:1.0f];
            } completion:nil];
        }
    }
    else
    {
        if ([self alpha])
        {
            [UIView animateWithDuration:0.2f delay:0.0f options:UIViewAnimationOptionCurveEaseOut animations:^{
                [self setAlpha:0.0f];
            } completion:nil];
        }
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (!_scrollBar)
    {
        return;
    }
    
    CGRect newFrame = [_scrollBar convertRect:self.frame toView:_tableView.superview];
    self.frame = newFrame;
    [_tableView.superview addSubview:self];
    
    [UIView animateWithDuration:0.3f delay:1.0f options:UIViewAnimationOptionBeginFromCurrentState  animations:^{
        
        self.alpha = 0.0f;
        self.transform = CGAffineTransformMakeTranslation(10.0f, 0.0f);
        
    } completion:nil];
}


- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if (!_tableView || !_scrollBar)
    {
        [self captureTableViewAndScrollBar];
    }
    
    if (!_scrollBar)
    {
        return;
    }
    
    CGRect selfFrame = self.frame;
    CGRect scrollBarFrame = _scrollBar.frame;
    
    
    self.frame = CGRectIntegral(CGRectMake(CGRectGetWidth(selfFrame) * -1.0f,
                                           (CGRectGetHeight(scrollBarFrame) / 2.0f) - (CGRectGetHeight(selfFrame) / 2.0f),
                                           CGRectGetWidth(selfFrame),
                                           CGRectGetHeight(selfFrame)));
    
    [_scrollBar addSubview:self];
    
    [UIView animateWithDuration:0.2f delay:0.0f options:UIViewAnimationOptionBeginFromCurrentState  animations:^{
        
        self.alpha = 1.0f;
        self.transform = CGAffineTransformIdentity;
        
    } completion:nil];
    
}

- (void)invalidate
{
    _tableView = nil;
    _scrollBar = nil;
    [self removeFromSuperview];
}


- (void)checkChanges
{
    if (!_tableView ||
        _savedTableViewSize.height != _tableView.frame.size.height ||
        _savedTableViewSize.width != _tableView.frame.size.width)
    {
        [self invalidate];
    }
}
- (void)updateDisplayWithData:(id)data{
    
}
//- (void)setScrollerViewData:(id)scrollerViewData{
//    
//}
#pragma mark - private
- (void)updateDisplayWithCell:(UITableViewCell *)cell{
    self.scrollerViewData = [self.dataSource scroller:self dataForCell:cell];
    [self updateDisplayWithData:self.scrollerViewData];
}
@end
