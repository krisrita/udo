//
//  HDTableView.h
//
//  Created by nobody on 14-1-14.
//  All rights reserved.
//

typedef NS_ENUM(NSInteger, HDCellHeightType) {
    HD_CELL_HEIGHT_TYPE_FIXED = 0,
    HD_CELL_HEIGHT_TYPE_DYNAMIC,
};

typedef NS_ENUM(NSInteger, HDScrollDirection) {
    HD_SCROLL_DIRECTION_NONE = 0,
    HD_SCROLL_DIRECTION_UP,
    HD_SCROLL_DIRECTION_DOWN
};


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PullTableView.h"
#import "HDTableViewCell.h"
#import "HDCollectionViewCell.h"
#import "HDTableView.h"
#import "PullCollectionView.h"
#import "HDBlankPageView.h"

@class HDTableView;

@protocol HDTableViewDelegate <NSObject>

@optional
- (void)HDTableViewDidTriggerRefresh:(HDTableView*)pullTableView;
- (void)HDTableViewDidTriggerLoadMore:(HDTableView*)pullTableView;
- (void)HDTableViewDidSelected:(id)data didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)HDTableViewDidScrollDirectionChanged:(HDScrollDirection)direction;

- (void)scrollViewDidScroll:(UIScrollView *)scrollView;

@optional
#pragma - mark 下列滑动删除样式列表代理方法 只有当列表为滑动删除样式的时候才有必要实现
-(void)HDTableViewDeleteStyleClickBtnIndex:(int)index data:(id)data tableViewCellIndexPath:(NSIndexPath *)indexPath;

@end

@interface HDTableView : UIView<UITableViewDelegate,UITableViewDataSource,PullTableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,PullCollectionViewDelegate>


@property (nonatomic, assign) BOOL HDTableIsRefreshing;
@property (nonatomic, assign) BOOL HDTableIsLoadingMore;
@property (nonatomic, assign)  BOOL HDloadMoreViewHide;
@property (nonatomic, assign) CGFloat cellRowHeight;
@property (nonatomic, weak)  id<HDTableViewDelegate> hdTableViewDelegate;
@property(nonatomic,getter=isScrollEnabled) BOOL  scrollEnabled;
@property (nonatomic, strong)UIView *headView;
@property (nonatomic,assign)UIEdgeInsets tableViewEdgeinsets;

- (NSMutableArray *)getTableDataAry;
- (void)setTableDataWithAry:(NSArray *)dataAry;
- (void)setTableDataWithAryNoRemoveBefore:(NSArray *)dataAry;
- (void)setTableNetworkFailure;
- (void)tableAppendDataWithAry:(NSArray *)appendDataAry;
- (void)tableInsertDataWithObject:(id)object;
- (void)reloadRowsWithRow:(int)row;
- (NSIndexPath *)indexPathForCell:(id)cell;
- (void)refresh;

- (id)initWithFrame:(CGRect)frame
      rowHeightType:(HDCellHeightType)type
      cellClassName:(__unsafe_unretained Class)className
     blankViewClass:(__unsafe_unretained Class)blankViewClass
        refreshType:(HDTableRefreshType)refreshType;

- (id)initDeleteStyleTableWithFrame:(CGRect)frame
                      rowHeightType:(HDCellHeightType)type
                      cellClassName:(__unsafe_unretained Class)className
                     blankViewClass:(__unsafe_unretained Class)blankViewClass
                        refreshType:(HDTableRefreshType)refreshType;

- (id)initWithFrame:(CGRect)frame
     cellClassName:(__unsafe_unretained Class)cellClass
          itemSize:(CGSize)size
      sectionInset:(UIEdgeInsets)edgeInsets
    blankViewClass:(__unsafe_unretained Class)blackViewClass
       refreshType:(HDTableRefreshType)type;

- (void)setScrollerViewClassName:(__unsafe_unretained Class)scrollerClass;
- (void)HDTableViewDeleteRowsAtIndex:(int)index;

@end