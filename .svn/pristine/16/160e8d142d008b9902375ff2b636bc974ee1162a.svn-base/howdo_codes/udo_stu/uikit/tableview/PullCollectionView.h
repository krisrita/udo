//
//  PullCollectionView.h
//
//  Created by nobody on 14-1-14.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "PullTableView.h"

@class PullCollectionView;

@protocol PullCollectionViewDelegate <NSObject>

- (void)pullCollectionViewDidTriggerRefresh:(PullCollectionView*)pullTableView;
- (void)pullCollectionViewDidTriggerLoadMore:(PullCollectionView*)pullTableView;

@end

@interface PullCollectionView :UICollectionView

@property (nonatomic, strong) UIImage *pullArrowImage;
@property (nonatomic, strong) UIColor *pullBackgroundColor;
@property (nonatomic, strong) UIColor *pullTextColor;
@property (nonatomic, strong) NSDate *pullLastRefreshDate;
@property (nonatomic, assign) BOOL pullTableIsRefreshing;
@property (nonatomic, assign) BOOL pullTableIsLoadingMore;
@property (nonatomic, assign) BOOL loadMoreViewHide;
@property (nonatomic, assign)  id<PullCollectionViewDelegate> pullDelegate;

-(id)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout andWithRefreshType:(HDTableRefreshType)type;

@end