//
//  HDScrollerView.h
//
//  Created by Jay on 14-7-15.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDScrollerView;

@protocol HDScrollerViewDataSource <NSObject>

@required
- (UITableView *)tableViewForScroller:(HDScrollerView *)scroller;
- (id)scroller:(HDScrollerView *)scroller dataForCell:(UITableViewCell *)cell;

@end

@protocol HDScrollerViewDelegate <NSObject>

@end

@interface HDScrollerView : UIImageView

@property (nonatomic, strong) UIImageView *backgroundView;
@property (nonatomic,strong) id scrollerViewData;
@property (nonatomic, weak) id <HDScrollerViewDataSource> dataSource;
@property (nonatomic, weak) id <HDScrollerViewDelegate> delegate;

- (id)initWithDelegate:(id <HDScrollerViewDelegate>)delegate
            dataSource:(id<HDScrollerViewDataSource>)datasource;
- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView;
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView;
- (void)updateDisplayWithData:(id)data;

@end
