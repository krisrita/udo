//
//  EGORefreshTableHeaderView.m
//  Demo
//
//  Created by Devin Doty on 10/14/09October14.
//  Copyright 2009 enormego. All rights reserved.
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

#import "MyLoadMoreTableFooterView.h"


@interface MyLoadMoreTableFooterView (Private)
- (void)setState:(EGOPullState)aState;
- (CGFloat)scrollViewOffsetFromBottom:(UIScrollView *) scrollView;
- (CGFloat)visibleTableHeightDiffWithBoundsHeight:(UIScrollView *) scrollView;
@end

@implementation MyLoadMoreTableFooterView

@synthesize delegate=_delegate;


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
		
        isLoading = NO;
        
        CGFloat midY = PULL_AREA_HEIGTH/2;
        
        /* Config Status Updated Label */
		UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0.0f + 15.0f, midY - 10, self.frame.size.width, 20.0f)];
		label.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		label.font = [UIFont boldSystemFontOfSize:13.0f];
		label.shadowOffset = CGSizeMake(0.0f, 1.0f);
		label.backgroundColor = [UIColor clearColor];
		label.textAlignment = NSTextAlignmentCenter;
		[self addSubview:label];
		_statusLabel=label;
        _statusLabel.tag = 20000;
		
        /* Config Arrow Image */
//		CALayer *layer = [[CALayer alloc] init];
//		layer.frame = CGRectMake(25.0f,midY - 10, 30.0f, 55.0f);
//		layer.contentsGravity = kCAGravityResizeAspect;
//#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 40000
//		if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]) {
//			layer.contentsScale = [[UIScreen mainScreen] scale];
//		}
//#endif
//		[[self layer] addSublayer:layer];
//		_arrowImage=layer;
		
        /* Config activity indicator */
		UIActivityIndicatorView *view = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:DEFAULT_ACTIVITY_INDICATOR_STYLE];
		view.frame = CGRectMake(25.0f + 60.0f, midY - 10, 20.0f, 20.0f);
        view.hidesWhenStopped = YES;
		[self addSubview:view];
		_activityView = view;		
		
		[self setState:EGOOPullNormal]; // Also transform the image
        
        /* Configure the default colors and arrow image */
//        [self setBackgroundColor:[UIColor colorWithRed:251.0/255.0 green:251.0/255.0 blue:251.0/255.0 alpha:1.0 ] textColor:[UIColor colorWithRed:91.0/255.0 green:91.0/255.0 blue:91.0/255.0 alpha:1.0 ] arrowImage:nil];
        
        [self setBackgroundColor:[UIColor clearColor] textColor:[UIColor colorWithRed:91.0/255.0 green:91.0/255.0 blue:91.0/255.0 alpha:1.0 ] arrowImage:nil];
        
        self.loadViewHide = NO;
		
    }
	
    return self;
	
}

-(void)setHidden:(BOOL)hidden
{
    [super setHidden:hidden];
    if (hidden == YES)
    {
        [_activityView stopAnimating];
    }
    else
    {
        [_activityView startAnimating];
    }
}

#pragma mark - Util
- (CGFloat)scrollViewOffsetFromBottom:(UIScrollView *) scrollView
{
    CGFloat scrollAreaContenHeight = scrollView.contentSize.height;
    
    CGFloat visibleTableHeight = MIN(scrollView.bounds.size.height, scrollAreaContenHeight);
    CGFloat scrolledDistance = scrollView.contentOffset.y + visibleTableHeight; // If scrolled all the way down this should add upp to the content heigh.
    
    CGFloat normalizedOffset = scrollAreaContenHeight -scrolledDistance;
    
    return normalizedOffset;
    
}

- (CGFloat)visibleTableHeightDiffWithBoundsHeight:(UIScrollView *) scrollView
{
    return (scrollView.bounds.size.height - MIN(scrollView.bounds.size.height, scrollView.contentSize.height));
}


#pragma mark -
#pragma mark Setters


- (void)setState:(EGOPullState)aState
{

    switch (aState) {
		case EGOOPullPulling:
            _statusLabel.text = NSLocalizedStringFromTable(@"正在加载更多...", @"PullTableViewLan",@"Loading Status");
			
			break;
		case EGOOPullNormal:
    
			_statusLabel.text = NSLocalizedStringFromTable(@"正在加载更多...", @"PullTableViewLan",@"Loading Status");
//			[_activityView stopAnimating];
    
			break;
		case EGOOPullLoading:
			
			_statusLabel.text = NSLocalizedStringFromTable(@"正在加载更多...", @"PullTableViewLan",@"Loading Status");
//			[_activityView startAnimating];
			
			break;
		default:
			break;
	}

	_state = aState;
}

- (void)setBackgroundColor:(UIColor *)backgroundColor textColor:(UIColor *) textColor arrowImage:(UIImage *) arrowImage
{
    self.backgroundColor = backgroundColor? backgroundColor : DEFAULT_BACKGROUND_COLOR;
    _statusLabel.textColor = textColor? textColor: DEFAULT_TEXT_COLOR;
    _statusLabel.shadowColor = [_statusLabel.textColor colorWithAlphaComponent:0.1f];
}


#pragma mark -
#pragma mark ScrollView Methods


- (void)egoRefreshScrollViewDidScroll:(UIScrollView *)scrollView
{
    if (!self.loadViewHide)
    {
        if ([self scrollViewOffsetFromBottom:scrollView] < -0.000001 && !isLoading)
        {
            if ([_delegate respondsToSelector:@selector(loadMoreTableFooterDidTriggerLoadMore:)])
            {
                [_delegate loadMoreTableFooterDidTriggerLoadMore:self];
            }
            [self startAnimatingWithScrollView:scrollView];
        }
	}

    

}

- (void)startAnimatingWithScrollView:(UIScrollView *) scrollView {
    isLoading = YES;
    [self setState:EGOOPullLoading];
}

- (void)egoRefreshScrollViewDidEndDragging:(UIScrollView *)scrollView
{
    if (!self.loadViewHide)
    {
        if ([self scrollViewOffsetFromBottom:scrollView] < -0.000001 && !isLoading)
        {
            if ([_delegate respondsToSelector:@selector(loadMoreTableFooterDidTriggerLoadMore:)])
            {
                [_delegate loadMoreTableFooterDidTriggerLoadMore:self];
            }
            [self startAnimatingWithScrollView:scrollView];
        }
	}
}

- (void)egoRefreshScrollViewDataSourceDidFinishedLoading:(UIScrollView *)scrollView {	
    isLoading = NO;
	[self setState:EGOOPullNormal];
}


#pragma mark -
#pragma mark Dealloc

- (void)dealloc {
	
	_delegate=nil;
	[_activityView release];
	[_statusLabel release];
    [super dealloc];
}


@end
