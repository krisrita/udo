//
//  PullTableView.h
//
//  Created by nobody on 14-1-13.
//  All rights reserved.
//


#import <UIKit/UIKit.h>
#import "HDTableViewCell.h"

typedef NS_ENUM(NSInteger, HDTableRefreshType){
    HD_TABLE_REFRESH_NONE = 0,
	HD_TABLE_REFRESH_DOWN,
    HD_TABLE_REFRESH_UP,
    HD_TABLE_REFRESH_UPDOWN,
};

@class PullTableView;

@protocol PullTableViewDelegate <NSObject>

- (void)pullTableViewDidTriggerRefresh:(PullTableView*)pullTableView;
- (void)pullTableViewDidTriggerLoadMore:(PullTableView*)pullTableView;

@end

@interface PullTableView : UITableView

@property (nonatomic, strong) UIImage *pullArrowImage;
@property (nonatomic, strong) UIColor *pullBackgroundColor;
@property (nonatomic, strong) UIColor *pullTextColor;
@property (nonatomic, strong) NSDate *pullLastRefreshDate;

@property (nonatomic, assign) UIEdgeInsets contentInsetCustom;
/**
 *  进入刷新状态
 */
@property (nonatomic, assign) BOOL pullTableIsRefreshing;
/**
 *  进入加载更多状态
 */
@property (nonatomic, assign) BOOL pullTableIsLoadingMore;
/**
 *  隐藏加载更多
 */
@property (nonatomic, assign) BOOL loadMoreViewHide;
@property (nonatomic, assign) id<PullTableViewDelegate> pullDelegate;

-(id)initWithFrame:(CGRect)frame refeshType:(HDTableRefreshType)type;

@end
