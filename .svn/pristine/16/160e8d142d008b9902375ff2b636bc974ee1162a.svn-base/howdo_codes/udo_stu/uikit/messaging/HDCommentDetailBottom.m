//
//  NTCCommentDetailBottom.m
//  NeteaseCoffee
//
//  Created by nobody on 15/4/15.
//  All rights reserved.
//


#import "HDCommentDetailBottom.h"
#import "HDCommentTextInput.h"

@interface HDCommentDetailBottom()<UITextFieldDelegate,CommentTextInputDelegate>

@property (nonatomic,strong) UIView *borderTop;


@end

@implementation HDCommentDetailBottom

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self buildUI];
    }
    return self;
}

-(void)buildUI{
    self.backgroundColor = UIColorFromRGB(34, 177, 139);
    _input = [[HDCommentTextInput alloc] init];
    _input.textInitialHeight = 15;
    _input.textMaxHeight = 85;
    _input.delegate = self;
    
    _borderTop = [[UIView alloc] init];
    _borderTop.backgroundColor = UIColorFromRGB(191, 0, 0);
    
    
    [self addSubview:_input];
//    [self addSubview:_borderTop];
    
    [self setLayout];
    
    [_input setupInitialData];
}

-(void)setLayout{
    WS(ws);
    UIEdgeInsets padding = UIEdgeInsetsMake(6, 15, 6, 15);
    [_input mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(ws).with.insets(padding);
    }];
    
//    [_borderTop mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(ws.mas_top);
//        make.left.and.width.equalTo(ws);
//        make.height.equalTo(@(1));
//        
//    }];
}

- (void)commentTextInput:(HDCommentTextInput *)textInput sendCommen:(NSString *) comment{
    if ([self.delegate respondsToSelector:@selector(sendComment:)]) {
        [self.delegate sendComment:textInput];
    }

}
-(void)setPlaceHolderText:(NSString *)aString{
    self.input.textView.placeholderText = aString;
}
-(void)editComment:(NSString *)aString{
    [self setPlaceHolderText:aString];
    [self.input.textView becomeFirstResponder];
}
-(void)hideTextInput{
    [self.input.textView resignFirstResponder];
}
-(void)focusTextInput{
    [self.input.textView becomeFirstResponder];
}
@end
