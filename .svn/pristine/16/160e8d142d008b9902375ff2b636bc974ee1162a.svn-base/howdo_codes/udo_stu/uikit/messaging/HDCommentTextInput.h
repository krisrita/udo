//
//  NTCCommentTextField.h
//  NeteaseCoffee
//
//  Created by nobody on 15/4/20.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SOPlaceholderedTextView.h"

@class HDCommentTextInput;

@protocol CommentTextInputDelegate <NSObject>

@optional
- (void)commentTextInput:(HDCommentTextInput *)textInput sendCommen:(NSString *) comment;


@end

@interface HDCommentTextInput : UIView

@property (weak, nonatomic) id<CommentTextInputDelegate> delegate;

//@property (nonatomic,weak) UIView *container;

@property (nonatomic,strong) NSString *placeholder;
@property (nonatomic,strong) SOPlaceholderedTextView *textView;

@property (nonatomic) CGFloat textInitialHeight;
@property (nonatomic) CGFloat textMaxHeight;


-(void)setupInitialData;
-(void)adjustInputView;
-(void)adjustTextViewSize;
@end
