//
//  NTCCommentTextField.m
//  NeteaseCoffee
//
//  Created by nobody on 15/4/20.
//  All rights reserved.
//

#import "HDCommentTextInput.h"

#define IOS7  ([[[[UIDevice currentDevice]systemVersion]substringToIndex:1] doubleValue]>=7)


@interface HDCommentTextInput()<UITextViewDelegate>

@property (nonatomic) CGRect superOrginFrame;
@property (nonatomic) CGRect textViewOrignFrame;

@end

@implementation HDCommentTextInput

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self buildUI];
        
        [self adjustInputView];
    }
    return self;
}

-(void)buildUI{
    
    self.textView = [[SOPlaceholderedTextView alloc] init];
    self.textView.textColor = [UIColor blackColor];
    self.textView.delegate = self;
    self.textView.backgroundColor = [UIColor whiteColor];
    self.textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.textView.returnKeyType = UIReturnKeySend;
    self.textView.layer.borderWidth = 0.65f;
    self.textView.layer.cornerRadius = 6.0f;
    [self.textView setFont:[UIFont systemFontOfSize:15]];
    
    [self addSubview:self.textView];
    
    self.textView.placeholderText = @"";
    
    
//    [kMyNotificationCenter addObserver:self selector:@selector(keyboadWillShow:) name:UIKeyboardWillShowNotification object:nil];
//    [kMyNotificationCenter addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [kMyNotificationCenter addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
}

#pragma mark 初始位置设置
- (void)adjustInputView{
    CGRect frame = self.frame;
    frame.size.height = self.textInitialHeight;
    self.frame = frame;
    
    CGRect txtBgFrame;// = self.textBgImageView.frame;
    txtBgFrame.origin = CGPointMake(0, 0);
    txtBgFrame.size = CGSizeMake(self.frame.size.width, self.textInitialHeight);
    
    CGFloat topPadding = 6.0f;
    CGFloat bottomPadding = 5.0f;
    CGFloat leftPadding = 6.0f;
    CGFloat rightPadding = 6.0f;
    
    CGRect txtFrame = self.textView.frame;
    txtFrame.origin.x = txtBgFrame.origin.x + leftPadding;
    txtFrame.origin.y = txtBgFrame.origin.y + topPadding;
    txtFrame.size.width = txtBgFrame.size.width - leftPadding - rightPadding;
    txtFrame.size.height = txtBgFrame.size.height - topPadding - bottomPadding;
    self.textView.frame = txtBgFrame;
    
    self.superview.frame = CGRectMake(0, APP_CONTENT_HEIGHT-self.superview.height-self.superview.superview.y, APP_CONTENT_WIDTH, self.superview.height);
    self.superOrginFrame = self.superview.frame;
}

-(void)setupInitialData{
    self.superOrginFrame = self.superview.frame;
    self.textViewOrignFrame = self.textView.frame;
}

- (void)scrollToCaretInTextView:(UITextView *)textView animated:(BOOL)animated{
    CGRect rect = [textView caretRectForPosition:textView.selectedTextRange.end];
    if (IOS7) {
        rect.size.height += textView.textContainerInset.bottom;
    }else{
        rect.size.height += 8;
    }
    [textView scrollRectToVisible:rect animated:animated];
}


- (void)sendTapped:(id)sender
{
    NSString *msg = self.textView.text;
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(commentTextInput:sendCommen:)]) {
        [self.delegate commentTextInput:self sendCommen:msg];
    }
}

#pragma mark 根据文字调整textView的superView的大小
-(void)adjustTextViewSize{
    
    CGSize contentSize = self.textView.contentSize;
//    MyLog(@"contentSize - %@", NSStringFromCGSize(contentSize));
    if (contentSize.height >= self.textMaxHeight) return;

    CGRect superViewFrame = self.superview.frame;
    CGFloat delta = contentSize.height - 34.0;
    superViewFrame.origin.y = self.superOrginFrame.origin.y - delta;
    superViewFrame.size.height = self.superOrginFrame.size.height + delta;
    self.superview.frame = superViewFrame;
    
    
//    CGRect usedFrame;
//    if (IOS7) {
//        usedFrame = [self.textView.layoutManager usedRectForTextContainer:self.textView.textContainer];
//    } else {
//        CGSize size = [self.textView.text sizeWithFont:self.textView.font constrainedToSize:CGSizeMake(CGRectGetWidth(self.textView.frame), 1000) lineBreakMode:NSLineBreakByWordWrapping];
//        usedFrame = CGRectMake(0, 0, size.width+10, size.height);
//    }
//    
//    CGRect frame = self.textView.frame;
//    
//    CGFloat delta = ceilf(usedFrame.size.height) - frame.size.height; // 变化的高度
//    
//    CGFloat lineHeight = self.textView.font.lineHeight; // 行高
//    
//    int numberOfActualLines = (int)ceilf(usedFrame.size.height / lineHeight);
//    
//    CGFloat actualHeight = numberOfActualLines * lineHeight; //
//    
//    delta = actualHeight - self.textView.frame.size.height; //self.textView.font.lineHeight - 5;
//    
//    CGRect frm = self.frame;
//    CGRect superFrame = self.superview.frame;
//    frm.size.height = actualHeight+20;
//
//    if (frm.size.height < self.textMaxHeight) {
//        if (frm.size.height < self.textInitialHeight) {
//            frm.size.height = self.textInitialHeight;
//        }else{
//            superFrame.origin.y = ceilf(self.superOrginFrame.origin.y - (frm.size.height-self.textInitialHeight-23));
//            superFrame.size.height = ceilf(frm.size.height+12);
//        }
//
//        [UIView animateWithDuration:0.3 animations:^{
//            self.superview.frame = superFrame;
//        } completion:^(BOOL finished) {
//            [self scrollToCaretInTextView:self.textView animated:NO];
//        }];
//    } else {
//        [self scrollToCaretInTextView:self.textView animated:NO];
//    }
}

#pragma mark - textview delegate
- (void)textViewDidChange:(UITextView *)textView{
    [self adjustTextViewSize];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text; {
    if (textView.text.length > 200 && ![text isEqualToString:@""]) return NO;
    
    if ([@"\n" isEqualToString:text] == YES) {
        //你的响应方法
        [self sendTapped:nil];
        return NO;
    }
    return YES;
}

#pragma mark - 键盘通知

- (void)keyboardWillChangeFrame:(NSNotification *)note {
    NSDictionary *info = [note userInfo];
    CGRect keyboardFrame = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    double duration = [[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    CGRect superViewFrame = self.superview.frame;
    superViewFrame.origin.y = keyboardFrame.origin.y - superViewFrame.size.height;
    
    [UIView animateWithDuration:duration animations:^{
        self.superview.frame = superViewFrame;
    } completion:^(BOOL finished) {
        self.superOrginFrame = self.superview.frame;
    }];
}

- (void)keyboadWillShow:(NSNotification *)note {
//    NSDictionary *info = [note userInfo];
//    CGSize keyboardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
//    CGFloat offY = keyboardSize.height;
//   
//    UIViewAnimationCurve curve = [[note.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] integerValue];
//    double duration = [[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
//   
//    [UIView animateWithDuration:duration animations:^{
//        [UIView setAnimationCurve:curve];
//        self.superview.frame = CGRectMake(0, APP_CONTENT_HEIGHT-self.superview.height-offY-self.superview.superview.y, APP_CONTENT_WIDTH, self.superview.height);
//    } completion:^(BOOL finished) {
//        self.superOrginFrame = self.superview.frame;
//    }];
}

- (void)keyboardWillHide:(NSNotification *)note {
//    UIViewAnimationCurve curve = [[note.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] integerValue];
//    double duration = [[note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
//    [UIView animateWithDuration:duration animations:^{
//        [UIView setAnimationCurve:curve];
//        self.superview.frame = CGRectMake(0, APP_CONTENT_HEIGHT-self.superview.height, APP_CONTENT_WIDTH, self.superview.height);
//    } completion:^(BOOL finished) {
//        self.superOrginFrame = self.superview.frame;
//    }];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
