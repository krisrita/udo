//
//  NTCCommentDetailBottom.h
//  NeteaseCoffee
//
//  Created by nobody on 15/4/15.
// All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HDCommentTextInput.h"

@class HDCommentDetailBottom;

@protocol CommentBottomDelegate <NSObject>

@optional
- (void)keyboadWillShow:(NSNotification *)note;
- (void)keyboardWillHide:(NSNotification *)note;
- (void)sendComment:(HDCommentTextInput *)textInput;


@end

@interface HDCommentDetailBottom : UIView

@property (nonatomic, assign) id <CommentBottomDelegate> delegate;
@property (nonatomic,strong) HDCommentTextInput *input;

-(void)setPlaceHolderText:(NSString *)aString;
-(void)editComment:(NSString *)name;

-(void)hideTextInput;
-(void)focusTextInput;

@end
