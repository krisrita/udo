//
//  HDBase.h
//  udo_stu
//
//  Created by nobody on 5/30/15.
//  All rights reserved.
//

#ifndef udo_stu_HDBase_h
#define udo_stu_HDBase_h

#import "NSString+Encrypt.h"
#import "NSDictionary+DataValue.h"
#import "HDBaseDefine.h"
#import "HDLog.h"
#import "HDDataModel.h"
#import "HDNetwork.h"
#import "HDMonitorNetWork.h"
#import "HDCommonResult.h"
#import "HDDate.h"
#import "HDTime.h"

#import "HDHeadImageUrl.h"
#import "HDCourseImageUrl.h"
#import "HDVideoImageUrl.h"
#import "HDNoteImageUrl.h"
#import "HDSchoolImageUrl.h"

#endif

// 通知
#define kMyNotificationCenter [NSNotificationCenter defaultCenter]
