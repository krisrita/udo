//
//  HDBaseDefine.h
//  udo_stu
//
//  Created by nobody on 5/29/15.
//  All rights reserved.
//

#ifndef udo_stu_HDBaseDefine_h
#define udo_stu_HDBaseDefine_h

typedef NS_ENUM(NSInteger, HDGender) {
    HD_GENDER_UNKNOWN = 0,
    HD_GENDER_MALE    = 1,
    HD_GENDER_FEMALE  = 2
};

#endif

typedef NS_ENUM(NSInteger, HDRequestType) {
    HDRequestTypeRefresh = 0, //下拉刷新
    HDRequestTypeLoadMore //上拉加载更多
};

//#define WatchedNumIncrementNotification @"WatchedNumIncrementNotification"
