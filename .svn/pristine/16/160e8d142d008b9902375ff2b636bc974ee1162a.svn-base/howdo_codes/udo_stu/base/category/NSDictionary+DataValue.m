//
//  NSDictionary+DataValue.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "NSDictionary+DataValue.h"
#import "HDDate.h"
#import "HDDataUtil.h"
@implementation NSDictionary (DataValue)


- (NSInteger)integerForKey:(NSString *)key
{
    id value = [self valueForKey:key];
    return [value isKindOfClass:[NSValue class]] ? [HDDataUtil integerForObject:value] : 0;
}

- (long)longForKey:(NSString *)key
{
    id value = [self valueForKey:key];
    return [value isKindOfClass:[NSValue class]] ? [HDDataUtil longForObject:value] : 0;
}

- (long long)longLongForKey:(NSString *)key
{
    id value = [self valueForKey:key];
    return [value isKindOfClass:[NSValue class]] ? [HDDataUtil longLongForObject:value] : 0;
}


- (float)floatForKey:(NSString *)key
{
    id value = [self valueForKey:key];
    return [value isKindOfClass:[NSValue class]] ? [HDDataUtil floatForObject:value] : 0.0f;
}

- (double)doubleForKey:(NSString *)key
{
    id value = [self valueForKey:key];
    return [value isKindOfClass:[NSValue class]] ? [HDDataUtil doubleForObject:value] : 0.0f;
}

- (BOOL)boolForKey:(NSString *)key
{
    id value = [self valueForKey:key];
    return [value isKindOfClass:[NSValue class]] ? [HDDataUtil boolForObject:value] : NO;
}

- (NSString *)stringForKey:(NSString *)key
{
    NSString *str = @"";
    id value = [self valueForKey:key];
    if ([value isKindOfClass:[NSString class]]) {
        str = [HDDataUtil stringForObject:value];
    }
    else if ([value isKindOfClass:[NSValue class]]) {
        str = ([NSNull null] == value || nil == value) ? @"" : [value stringValue];
    }
    return str;
}

- (BOOL)integerToBoolForKey:(NSString *)key
{
    id value = [self valueForKey:key];
    return ([value isKindOfClass:[NSValue class]] ? [HDDataUtil integerForObject:value] : 0) == 0 ? NO : YES;
}

@end
