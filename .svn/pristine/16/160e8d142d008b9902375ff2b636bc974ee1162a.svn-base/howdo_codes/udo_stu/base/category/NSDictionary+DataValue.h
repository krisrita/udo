//
//  NSDictionary+DataValue.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDDate.h"
@interface NSDictionary (DataValue)

- (NSInteger)integerForKey:(NSString *)key;
- (long)longForKey:(NSString *)key;
- (long long)longLongForKey:(NSString *)key;
- (float)floatForKey:(NSString *)key;
- (double)doubleForKey:(NSString *)key;
- (BOOL)boolForKey:(NSString *)key;
- (NSString *)stringForKey:(NSString *)key;
- (HDDate *)dateForKey:(NSString *)key;
- (BOOL)integerToBoolForKey:(NSString *)key;


@end
