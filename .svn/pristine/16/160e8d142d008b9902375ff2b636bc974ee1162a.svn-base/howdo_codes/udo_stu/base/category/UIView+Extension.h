//
//  UIView+Extension.h
//  SWH-Coffee
//
//  Created by sun wanhua on 14-12-9.
//  Copyright (c) 2014年 Sun Wanhua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Extension)

- (void)setX:(CGFloat)x;
- (CGFloat)x;

- (void)setY:(CGFloat)y;
- (CGFloat)y;

- (void)setWidth:(CGFloat)width;
- (CGFloat)width;

- (void)setHeight:(CGFloat)height;
- (CGFloat)height;

- (void)setSize:(CGSize)size;
- (CGSize)size;

@end
