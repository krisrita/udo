//
//  NSString+Wrapper.m
//  blueseaCore
//
//  Created by zzuguojiajia on 13-3-19.
//  Copyright (c) 2013年 bluesea. All rights reserved.
//

#import "NSString+Wrapper.h"

@implementation NSString (Wrapper)

#define JavaNotFound -1

/**  Java-like method. Returns the char value at the specified index. */
- (unichar) charAt:(NSInteger)index {
    return [self characterAtIndex:index];
}

/**
 * Java-like method. Compares two strings lexicographically.
 * the value 0 if the argument string is equal to this string;
 * a value less than 0 if this string is lexicographically less than the string argument;
 * and a value greater than 0 if this string is lexicographically greater than the string argument.
 */
- (NSInteger) compareTo:(NSString*) anotherString {
    return [self compare:anotherString];
}

/** Java-like method. Compares two strings lexicographically, ignoring case differences. */
- (NSInteger) compareToIgnoreCase:(NSString*) str {
    return [self compare:str options:NSCaseInsensitiveSearch];
}

/** Java-like method. Returns true if and only if this string contains the specified sequence of char values. */
- (BOOL) contains:(NSString*) str {
    NSRange range = [self rangeOfString:str];
    return (range.location != NSNotFound);
}

- (BOOL) startsWith:(NSString*)prefix {
    return [self hasPrefix:prefix];
}

- (BOOL) endsWith:(NSString*)suffix {
    return [self hasSuffix:suffix];
}

- (BOOL) equals:(NSString*) anotherString {
    return [self isEqualToString:anotherString];
}

- (BOOL) equalsIgnoreCase:(NSString*) anotherString {
    return [[self toLowerCase] equals:[anotherString toLowerCase]];
}

- (NSInteger) indexOfChar:(unichar)ch{
    return [self indexOfChar:ch fromIndex:0];
}

- (NSInteger) indexOfChar:(unichar)ch fromIndex:(NSInteger)index{
    NSInteger len = self.length;
    for (NSInteger i = index; i < len; ++i) {
        if (ch == [self charAt:i]) {
            return i;
        }
    }
    return JavaNotFound;
}

- (NSInteger) indexOfString:(NSString*)str {
    NSRange range = [self rangeOfString:str];
    if (range.location == NSNotFound) {
        return JavaNotFound;
    }
    return range.location;
}

- (NSInteger) indexOfString:(NSString*)str fromIndex:(NSInteger)index {
    NSRange fromRange = NSMakeRange(index, self.length - index);
    NSRange range = [self rangeOfString:str options:NSLiteralSearch range:fromRange];
    if (range.location == NSNotFound) {
        return JavaNotFound;
    }
    return range.location;
}

- (NSInteger) lastIndexOfChar:(unichar)ch {
    NSInteger len = self.length;
    for (NSInteger i = len-1; i >=0; --i) {
        if ([self charAt:i] == ch) {
            return i;
        }
    }
    return JavaNotFound;
}

- (NSInteger) lastIndexOfChar:(unichar)ch fromIndex:(NSInteger)index {
    NSInteger len = self.length;
    if (index >= len) {
        index = len - 1;
    }
    for (NSInteger i = index; i >= 0; --i) {
        if ([self charAt:i] == ch) {
            return index;
        }
    }
    return JavaNotFound;
}

- (NSInteger) lastIndexOfString:(NSString*)str {
    NSRange range = [self rangeOfString:str options:NSBackwardsSearch];
    if (range.location == NSNotFound) {
        return JavaNotFound;
    }
    return range.location;
}

- (NSInteger) lastIndexOfString:(NSString*)str fromIndex:(NSInteger)index {
    NSRange fromRange = NSMakeRange(0, index);
    NSRange range = [self rangeOfString:str options:NSBackwardsSearch range:fromRange];
    if (range.location == NSNotFound) {
        return JavaNotFound;
    }
    return range.location;
}

- (NSString *) substringFromIndex:(NSInteger)beginIndex toIndex:(NSInteger)endIndex {
    if (endIndex <= beginIndex) {
        return @"";
    }
    NSRange range = NSMakeRange(beginIndex, endIndex - beginIndex);
    return [self substringWithRange:range];
}

- (NSString *) toLowerCase {
    return [self lowercaseString];
}

- (NSString *) toUpperCase {
    return [self uppercaseString];
}

- (NSString *) trim {
    return [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *) replaceAll:(NSString*)origin with:(NSString*)replacement {
    return [self stringByReplacingOccurrencesOfString:origin withString:replacement];
}

- (NSArray *) split:(NSString*) separator {
    return [self componentsSeparatedByString:separator];
}

- (NSString *)replacingCharactersInRange:(NSRange)range replaceString:(NSString *)replaceString
{
    if (self&&self!=nil)
    {
        return [self stringByReplacingCharactersInRange:range withString:replaceString];
    }
    return nil;
}


- (CGSize)fitSize:(UIFont *)font contentWidth:(CGFloat)contentWidth maxHeight:(CGFloat )maxHeight
{
    
    CGSize size = NTC_MULTILINE_TEXTSIZE(self, font, CGSizeMake(contentWidth, maxHeight), NSLineBreakByTruncatingTail);;
    return size;
}

@end
