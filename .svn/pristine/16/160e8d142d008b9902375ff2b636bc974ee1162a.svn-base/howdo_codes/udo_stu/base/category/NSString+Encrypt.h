//
//  NSString+Encrypt.h
//  MuKeIphone
//
//  Created by nobody on 13-9-25.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>

@interface NSString (Encrypt)

- (NSString *)md5;
- (NSString *)md5_32;
+ (NSString *)md5StringForString:(NSString *)string;
@end
