//
//  HDHttpClient.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//
#define RESULT_OBJECT(XXXX) (XXXX.responseObject)
#import "HDHttpClient.h"
#import "HDHTTPRequestOperationManager.h"
#import "HDCommonResult.h"
@interface HDHttpClient ()

@property (nonatomic,strong,readwrite)NSURL *baseURL;
@property (nonatomic,assign)NSTimeInterval defaultSeconds;
@property (nonatomic,strong)NSMutableDictionary *HTTPHeaderFieldDictionary;
@end


@implementation HDHttpClient
- (instancetype)initWithBaseURL:(NSURL *)baseURL
{
    
    if (self = [super init]) {
        self.baseURL = baseURL;
        _defaultSeconds = 20;
        _HTTPHeaderFieldDictionary = [[NSMutableDictionary alloc]initWithCapacity:2];
    }
    return self;
}


- (void)setTimeoutInterval:(NSTimeInterval)seconds
{
    _defaultSeconds = seconds;
}

- (void)addValue:(NSString *)value forHTTPHeaderField:(NSString *)field;
{
    NSParameterAssert(value);
    NSParameterAssert(field);
    [_HTTPHeaderFieldDictionary setValue:value forKey:field];
    
}
#pragma private
- (HDHTTPRequestOperationManager *)baseHttpRequestOperation
{
    HDHTTPRequestOperationManager *operationManager = [[HDHTTPRequestOperationManager alloc]initWithBaseURL:self.baseURL];
    [operationManager setTimeoutInterval:_defaultSeconds];
    [operationManager setHTTPHeaderFieldDictionary:_HTTPHeaderFieldDictionary];
    return operationManager;
}

- (void )post:(NSString *)URLString parameters:(NSDictionary *)parameters
   resultBack:(NetworkBackBlock)resultBack;
{
    HDHTTPRequestOperationManager *operationManager = [self baseHttpRequestOperation];
    NSMutableSet *contentTypes = [[NSMutableSet alloc] initWithSet:operationManager.responseSerializer.acceptableContentTypes];
    if (contentTypes) {
        [contentTypes addObject:@"text/html"];
        [contentTypes addObject:@"application/json"];
    }
    //NSLog(@"parametersparametersparametersparameters:::%@",parameters);
    operationManager.responseSerializer.acceptableContentTypes = contentTypes;
    [operationManager POST:URLString parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_SUCCESS resultDesc:nil];
                NSLog(@"MCCommonResult:::;%@",operation.responseString);
        //        [MCLog info:@"MCCommonResult:::;%@",operation.responseString];
        resultBack(result, RESULT_OBJECT(operation));
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_FAILURE resultDesc:[error description]];
        resultBack(result, nil);
    }];
}
- (void )get:(NSString *)URLString parameters:(NSDictionary *)parameters
  resultBack:(NetworkBackBlock)resultBack
{
    HDHTTPRequestOperationManager *operationManager = [self baseHttpRequestOperation];
    [operationManager GET:URLString parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_SUCCESS resultDesc:nil];
//        NSLog(@"operation:::%@",operation.responseString);
        MyLog(@"\nurl:%@\n参数:\n%@\n结果:\n%@", URLString, parameters, responseObject);
        resultBack(result, RESULT_OBJECT(operation));
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_FAILURE resultDesc:[error description]];
        resultBack(result, nil);
    }];
}

- (void)post:(NSString *)URLString parameters:(NSDictionary *)parameters
        data:(NSData *)data  name:(NSString *)name fileName:(NSString *)fileName
    mimeType:(NSString *)mimeType
  resultBack:(NetworkBackBlock)resultBack;
{
    HDHTTPRequestOperationManager *operationManager = [self baseHttpRequestOperation];
    
    NSMutableSet *contentTypes = [[NSMutableSet alloc] initWithSet:operationManager.responseSerializer.acceptableContentTypes];
    if (contentTypes) {
        [contentTypes addObject:@"text/html"];
        [contentTypes addObject:@"application/json"];
    }
    operationManager.responseSerializer.acceptableContentTypes = contentTypes;
    [operationManager POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:data name:name fileName:fileName mimeType:mimeType];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_SUCCESS resultDesc:nil];
        resultBack(result, RESULT_OBJECT(operation));
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_FAILURE resultDesc:[error description]];
        resultBack(result, nil);
    }];
    
}

@end
