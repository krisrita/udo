//
//  HDMonitorNetWork.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDNetworkDefine.h"
extern NSString * const MCNetworkingReachabilityDidChangeNotification;
@interface HDMonitorNetWork : NSObject

+ (instancetype)managerForDomain;

- (void)startMonitoring;
- (HDNetworkStatus)getNetworkStatus;
- (NSString *)getNetworkStatusDescription;
- (NSString *)getNetworkStatusDescriptionForExceptionCache;

@end
