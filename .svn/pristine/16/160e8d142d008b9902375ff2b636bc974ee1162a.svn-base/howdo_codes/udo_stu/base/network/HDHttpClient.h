//
//  HDHttpClient.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDNetworkDefine.h"

@interface HDHttpClient : NSObject

@property (readonly, nonatomic, strong) NSURL *baseURL;

- (instancetype)initWithBaseURL:(NSURL *)baseUrl;
- (void)setTimeoutInterval:(NSTimeInterval)seconds;
- (void)addValue:(NSString *)value forHTTPHeaderField:(NSString *)field;

- (void)post:(NSString *)URLString parameters:(NSDictionary *)parameters resultBack:(NetworkBackBlock)resultBack;
- (void)get:(NSString *)URLString parameters:(NSDictionary *)parameters resultBack:(NetworkBackBlock)resultBack;
- (void)post:(NSString *)URLString parameters:(NSDictionary *)parameters
        data:(NSData *)data name:(NSString *)name
    fileName:(NSString *)fileName
    mimeType:(NSString *)mimeType
  resultBack:(NetworkBackBlock)resultBack;

@end
