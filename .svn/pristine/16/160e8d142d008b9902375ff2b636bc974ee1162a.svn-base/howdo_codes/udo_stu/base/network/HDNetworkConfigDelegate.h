//
//  HDNetworkConfigDelegate.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol HDNetworkConfigDelegate <NSObject>

@required
- (NSString *)getHttpServiceBaseUrl;

@optional
- (int)getHttpConnectTimeOut;
- (NSString *)getToken:(NSString *)url;

@end
