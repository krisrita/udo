//
//  HDHTTPRequestOperationManager.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "AFHTTPRequestOperationManager.h"

@interface HDHTTPRequestOperationManager : AFHTTPRequestOperationManager

- (instancetype)initWithBaseURL:(NSURL *)baseUrl;
- (void)setTimeoutInterval:(NSTimeInterval)seconds;
- (void)setHTTPHeaderFieldDictionary:(NSDictionary *)HTTPHeaderFieldDictionary;

@end
