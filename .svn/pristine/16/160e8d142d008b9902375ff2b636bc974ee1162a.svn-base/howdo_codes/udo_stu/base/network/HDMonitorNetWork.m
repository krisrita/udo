//
//  HDMonitorNetWork.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDMonitorNetWork.h"
NSString * const MCNetworkingReachabilityDidChangeNotification = @"MCNetworkingReachabilityDidChangeNotification";
@interface HDMonitorNetWork ()
@property (readwrite, nonatomic, strong) AFNetworkReachabilityManager *reachabilityManager;
@end

@implementation HDMonitorNetWork

+ (instancetype)managerForDomain
{
    
    static HDMonitorNetWork *sharedNetWork = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedNetWork = [[HDMonitorNetWork alloc] init];
    });
    
    return sharedNetWork;
    
}

- (instancetype)init
{
    if (self = [super init]) {
        self.reachabilityManager = [AFNetworkReachabilityManager managerForDomain:@"www.baidu.com"];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(reachabilityChanged:)
                                                     name:AFNetworkingReachabilityDidChangeNotification
                                                   object:nil];
        
    }
    return self;
}

- (void)startMonitoring
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self.reachabilityManager startMonitoring];
    });
}

- (void)reachabilityChanged:(NSNotification *)note
{
    
    NSDictionary *statusDictionary = note.userInfo;
    AFNetworkReachabilityStatus status = [[statusDictionary objectForKey:AFNetworkingReachabilityNotificationStatusItem] integerValue];
    HDNetworkStatus networkStatus;
    NSString *statusString  = nil;
    switch (status) {
        case AFNetworkReachabilityStatusNotReachable:
        {
            networkStatus = HD_NETWORK_STATUS_NONE;
            statusString = @"网络已经断开";
        }
            
            break;
        case AFNetworkReachabilityStatusReachableViaWWAN:
        {
            networkStatus = HD_NETWORK_STATUS_WWAN;
            statusString = @"正在使用2G/3G";
        }
            
            break;
        case AFNetworkReachabilityStatusReachableViaWiFi:
        {
            networkStatus = HD_NETWORK_STATUS_WiFi;
            statusString = @"正在使用wifi";
        }
            
            break;
        default:
        {
            networkStatus = HD_NETWORK_STATUS_UNKNOWN;
            statusString = @"暂时不能网络的类型";
        }
            
            break;
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:MCNetworkingReachabilityDidChangeNotification object:[NSNumber numberWithInteger:networkStatus]];
    
    //    [self showTextOnly:statusString];
}


- (HDNetworkStatus)getNetworkStatus
{
    HDNetworkStatus networkStatus;
    
    switch (self.reachabilityManager.networkReachabilityStatus) {
        case AFNetworkReachabilityStatusNotReachable:
            networkStatus = HD_NETWORK_STATUS_NONE;
            break;
        case AFNetworkReachabilityStatusReachableViaWWAN:
            networkStatus = HD_NETWORK_STATUS_WWAN;
            break;
        case AFNetworkReachabilityStatusReachableViaWiFi:
            networkStatus = HD_NETWORK_STATUS_WiFi;
            break;
        default:
            networkStatus = HD_NETWORK_STATUS_UNKNOWN;
            break;
    }
    return networkStatus;
}

- (NSString *)getNetworkStatusDescription{
    NSString *des = @"";
    switch (self.reachabilityManager.networkReachabilityStatus) {
        case AFNetworkReachabilityStatusNotReachable:
            des = @"网络未连接";
            break;
        case AFNetworkReachabilityStatusReachableViaWWAN:
            des = @"2/3G";
            break;
        case AFNetworkReachabilityStatusReachableViaWiFi:
            des = @"WiFi";
            break;
        default:
            des = @"未知";
            break;
    }
    return des;
}
- (NSString *)getNetworkStatusDescriptionForExceptionCache{
    NSString *des = @"1";
    switch (self.reachabilityManager.networkReachabilityStatus) {
        case AFNetworkReachabilityStatusNotReachable:
            des = @"1";
            break;
        case AFNetworkReachabilityStatusReachableViaWWAN:
            des = @"2";
            break;
        case AFNetworkReachabilityStatusReachableViaWiFi:
            des = @"1";
            break;
        default:
            des = @"1";
            break;
    }
    return des;
}

@end
