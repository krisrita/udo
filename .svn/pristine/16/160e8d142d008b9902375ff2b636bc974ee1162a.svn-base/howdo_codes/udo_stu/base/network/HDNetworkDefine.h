//
//  HDNetworkDefine.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#ifndef HowDo_HDNetworkDefine_h
#define HowDo_HDNetworkDefine_h

@class HDCommonResult;

#define HD_NOTIFICATION_NETWORK_STATUS_CHANGED @"HDNetworkStatusChangedNotification"

typedef NS_OPTIONS(NSUInteger, HDNetworkStatus) {
    HD_NETWORK_STATUS_UNKNOWN = -1,
    HD_NETWORK_STATUS_NONE = 0,
    HD_NETWORK_STATUS_WiFi = 1,
    HD_NETWORK_STATUS_WWAN = 2
};

typedef void(^NetworkBackBlock)(HDCommonResult *result, id responseObject);


#endif
