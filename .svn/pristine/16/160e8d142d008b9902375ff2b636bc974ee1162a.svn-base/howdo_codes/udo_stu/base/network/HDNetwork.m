//
//  HDNetwork.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDNetwork.h"
#import "HDMonitorNetWork.h"
#import "HDHttpClient.h"
#import "HDCommonResult.h"

@interface HDNetwork ()
@property (nonatomic,strong)NSURL *baseURL;
@end

@implementation HDNetwork


+ (instancetype)sharedInstance
{
    static HDNetwork *sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedClient = [[self alloc] init];
    });
    return sharedClient;
}

- (instancetype)init
{
    
    if ((self = [super init]))
    {
        self.baseURL = [NSURL URLWithString:@""];
    }
    return self;
}


- (instancetype)initWithBaseURL:(NSURL *)baseUrl
{
    if ((self = [super init]))
    {
        self.baseURL = baseUrl;
    }
    return self;
}

- (HDNetworkStatus)getNetworkStatus
{
    return [[HDMonitorNetWork managerForDomain]getNetworkStatus];
}

- (NSString *)getNetworkStatusName
{
    NSString *networkStatusName = nil;
    switch ([self getNetworkStatus]) {
        case HD_NETWORK_STATUS_NONE:
            networkStatusName = @"没有网络";
            break;
        case HD_NETWORK_STATUS_WiFi:
            networkStatusName = @"WIFI网络";
            break;
        case HD_NETWORK_STATUS_WWAN:
            networkStatusName = @"3G网络";
            break;
        default:
            networkStatusName = @"";
            break;
    }
    return networkStatusName;
}
- (void)setConfig:(id<HDNetworkConfigDelegate>)networkConfig
{
    _config = networkConfig;
    
}

- (HDHttpClient *)baseHttpRequest
{
    if (_config &&[_config respondsToSelector:@selector(getHttpServiceBaseUrl)]) {
        self.baseURL = [NSURL URLWithString:[_config getHttpServiceBaseUrl]];
    }
    
    HDHttpClient *httpClient = [[HDHttpClient alloc]initWithBaseURL:self.baseURL];
    
    if (_config &&[_config respondsToSelector:@selector(getHttpConnectTimeOut)]) {
        [httpClient setTimeoutInterval:[_config getHttpConnectTimeOut]];
    }
    return httpClient;
}
- (void)get:(NSString *)urlString parameters:(NSMutableDictionary *)parameters
 resultBack:(NetworkBackBlock)resultBack
{
    if (HD_NETWORK_STATUS_NONE == [self getNetworkStatus]||HD_NETWORK_STATUS_UNKNOWN == HD_NETWORK_STATUS_NONE == [self getNetworkStatus]) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_NETWORK_FAILURE resultDesc:nil];
        resultBack(result, nil);
        return;
    }
    
    HDHttpClient *httpClient = [self baseHttpRequest];
    if (_config &&[_config respondsToSelector:@selector(getToken:)]) {
        [parameters setObject:[_config getToken:urlString] forKey:@"token"];
    }
    [httpClient get:urlString parameters:parameters resultBack:resultBack];
}

- (void)post:(NSString *)urlString parameters:(NSMutableDictionary *)parameters
  resultBack:(NetworkBackBlock)resultBack
{
    
    if (HD_NETWORK_STATUS_NONE == [self getNetworkStatus]) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_NETWORK_FAILURE resultDesc:nil];
        resultBack(result, nil);
        return;
    }
    HDHttpClient *httpClient = [self baseHttpRequest];
    if (_config &&[_config respondsToSelector:@selector(getToken:)]) {
        [parameters setObject:[_config getToken:urlString] forKey:@"token"];
    }
    [httpClient post:urlString parameters:parameters resultBack:resultBack];
}

- (void)upload:(NSString *)urlString parameters:(NSMutableDictionary *)parameters
          data:(NSData *)data  name:(NSString *)name fileName:(NSString *)fileName
      mimeType:(NSString *)mimeType
    resultBack:(NetworkBackBlock)resultBack
{
    if (HD_NETWORK_STATUS_NONE == [self getNetworkStatus]) {
        HDCommonResult *result = [HDCommonResult resultWithData:HD_RESULT_CODE_NETWORK_FAILURE resultDesc:nil];
        resultBack(result, nil);
        return;
    }
    HDHttpClient *httpClient = [self baseHttpRequest];
    if (_config &&[_config respondsToSelector:@selector(getToken:)]) {
        [parameters setObject:[_config getToken:urlString] forKey:@"token"];
    }
    
    [httpClient post:urlString parameters:parameters data:data name:name fileName:fileName mimeType:mimeType resultBack:resultBack];
}

@end
