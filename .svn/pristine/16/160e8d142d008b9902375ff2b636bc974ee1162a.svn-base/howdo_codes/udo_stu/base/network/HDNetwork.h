//
//  HDNetwork.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDNetworkDefine.h"
#import "HDNetworkConfigDelegate.h"

@interface HDNetwork : NSObject
{
     __strong id<HDNetworkConfigDelegate> _config;
}

+ (instancetype)sharedInstance;

- (instancetype)initWithBaseURL:(NSURL *)baseUrl;
- (void)setConfig:(id<HDNetworkConfigDelegate>) networkConfig;

- (HDNetworkStatus)getNetworkStatus;
- (NSString *)getNetworkStatusName;

- (void)post:(NSString *)urlString parameters:(NSMutableDictionary *)parameters
  resultBack:(NetworkBackBlock)resultBack;

- (void)get:(NSString *)urlString parameters:(NSMutableDictionary *)parameters
 resultBack:(NetworkBackBlock)resultBack;

- (void)upload:(NSString *)urlString parameters:(NSMutableDictionary *)parameters
          data:(NSData *)data  name:(NSString *)name fileName:(NSString *)fileName
      mimeType:(NSString *)mimeType
    resultBack:(NetworkBackBlock)resultBack;


@end
