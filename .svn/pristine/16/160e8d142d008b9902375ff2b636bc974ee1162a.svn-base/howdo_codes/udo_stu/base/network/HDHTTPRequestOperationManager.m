//
//  HDHTTPRequestOperationManager.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDHTTPRequestOperationManager.h"

@interface HDHTTPRequestOperationManager ()

@property (nonatomic,assign)NSTimeInterval seconds;
@property (nonatomic,strong)NSDictionary *HTTPHeaderFieldDictionary;
@end

@implementation HDHTTPRequestOperationManager
#pragma mark - NSObject


- (instancetype)initWithBaseURL:(NSURL *)baseUrl
{
    
    
    if ((self = [super initWithBaseURL:baseUrl]))
    {
        [self.reachabilityManager stopMonitoring];
    }
    return self;
}

- (void)setTimeoutInterval:(NSTimeInterval)seconds
{
    _seconds = seconds;
}

- (void)setHTTPHeaderFieldDictionary:(NSDictionary *)HTTPHeaderFieldDictionary
{
    _HTTPHeaderFieldDictionary = HTTPHeaderFieldDictionary;
}

- (AFHTTPRequestOperation *)HTTPRequestOperationWithRequest:(NSURLRequest *)request
                                                    success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                                                    failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    
    __block NSMutableURLRequest *mutablerequest = (NSMutableURLRequest *)request;
    [mutablerequest setTimeoutInterval:_seconds];
    
    if (_HTTPHeaderFieldDictionary) {
        [_HTTPHeaderFieldDictionary enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop)
         {
             [mutablerequest addValue:obj forHTTPHeaderField:key];
         }];
    }
    
    return  [super HTTPRequestOperationWithRequest:mutablerequest success:success failure:failure];
}

@end
