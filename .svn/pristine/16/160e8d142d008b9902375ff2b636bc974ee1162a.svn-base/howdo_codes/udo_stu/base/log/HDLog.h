//
//  HDLog.h
//
//  Created by nobody on 14-1-3.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

// mytodo 测试，提交前置为0
#define HDTest 0

#define HDLOG_FLAG_DEBUG    (1 << 0)  // 0...00001
#define HDLOG_FLAG_INFO     (1 << 1)  // 0...00010
#define HDLOG_FLAG_WARN     (1 << 2)  // 0...00100
#define HDLOG_FLAG_ERROR    (1 << 3)  // 0...01000
#define HDLOG_FLAG_FATAL    (1 << 4)  // 0...10000

/**
 *  日志级别宏
 */
#define HDLOG_LEVEL_OFF     0
#define HDLOG_LEVEL_DEBUG   (HDLOG_FLAG_DEBUG | HDLOG_FLAG_INFO | HDLOG_FLAG_WARN | HDLOG_FLAG_ERROR | HDLOG_FLAG_FATAL)
#define HDLOG_LEVEL_INFO    (HDLOG_FLAG_INFO | HDLOG_FLAG_WARN | HDLOG_FLAG_ERROR | HDLOG_FLAG_FATAL)
#define HDLOG_LEVEL_WARN    (HDLOG_FLAG_WARN | HDLOG_FLAG_ERROR | HDLOG_FLAG_FATAL)
#define HDLOG_LEVEL_ERROR   (HDLOG_FLAG_ERROR | HDLOG_FLAG_FATAL)
#define HDLOG_LEVEL_FATAL   (HDLOG_FLAG_FATAL)

/**
 *  日志输出宏
 */
#define HDLogDebug(fmt, ...) do {[HDLog debug:fmt, ##__VA_ARGS__];} while (0)
#define HDLogInfo(fmt, ...) do {[HDLog info:fmt, ##__VA_ARGS__];} while (0)
#define HDLogWarn(fmt, ...) do {[HDLog warn:fmt, ##__VA_ARGS__];} while (0)
#define HDLogError(fmt, ...) do {[HDLog error:fmt, ##__VA_ARGS__];} while (0)
#define HDLogFatal(fmt, ...) do {[HDLog fatal:fmt, ##__VA_ARGS__];} while (0)

/**
 *  日志类
 */
@interface HDLog : NSObject

/**
 *  调试信息
 *
 *  @param format
 *  @param ...
 */
+ (void)debug:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);

/**
 *  运行状态、监测信息
 *
 *  @param format
 *  @param ...
 */
+ (void)info:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);

/**
 *  警告信息、隐患信息
 *
 *  @param format
 *  @param ...
 */
+ (void)warn:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);

/**
 *  错误信息，系统继续运行
 *
 *  @param format
 *  @param ...
 */
+ (void)error:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);

/**
 *  严重错误，导致系统崩溃
 *
 *  @param format
 *  @param ...
 */
+ (void)fatal:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);

/**
 *  设置日志级别
 *
 *  @param logLevel 日志级别
 */
+ (void)setLogLevel:(int)logLevel;

@end
