//
//  HDLog.m
//
//  Created by nobody on 14-1-3.
//  All rights reserved.
//

#import "HDLog.h"

#import <DDASLLogger.h>
#import <DDTTYLogger.h>

@implementation HDLog

static NSInteger s_HDLogLevel = HDLOG_LEVEL_DEBUG;
static DDLogLevel ddLogLevel = DDLogLevelDebug;
static bool s_LoggerInited = NO;

+ (void)debug:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2)
{
    if ((s_HDLogLevel & HDLOG_FLAG_DEBUG) > 0)
    {
        if (!format) {
            return;
        }
        
        if (!s_LoggerInited) {
            [HDLog initLogger];
        }
        
        do {
            va_list args;
            va_start(args, format);
            NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
            va_end(args);
            DDLogDebug(@"%@", msg);
        } while (0);
    }
}

+ (void)info:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2)
{
    if ((s_HDLogLevel & HDLOG_FLAG_INFO) > 0)
    {
        if (!format) {
            return;
        }
        
        if (!s_LoggerInited) {
            [HDLog initLogger];
        }
        
        do {
            va_list args;
            va_start(args, format);
            NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
            va_end(args);
            DDLogInfo(@"%@", msg);
        } while (0);
    }
}

+ (void)warn:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2)
{
    if ((s_HDLogLevel & HDLOG_FLAG_WARN) > 0)
    {
        if (!format) {
            return;
        }
        
        if (!s_LoggerInited) {
            [HDLog initLogger];
        }
        
        do {
            va_list args;
            va_start(args, format);
            NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
            va_end(args);
            DDLogWarn(@"%@", msg);
        } while (0);
    }
}

+ (void)error:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2)
{
    if ((s_HDLogLevel & HDLOG_FLAG_ERROR) > 0)
    {
        if (!format) {
            return;
        }
        
        if (!s_LoggerInited) {
            [HDLog initLogger];
        }
        
        do {
            va_list args;
            va_start(args, format);
            NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
            va_end(args);
            DDLogError(@"%@", msg);
        } while (0);
    }
}

+ (void)fatal:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2)
{
    if ((s_HDLogLevel & HDLOG_FLAG_FATAL) > 0)
    {
        if (!format) {
            return;
        }
        
        if (!s_LoggerInited) {
            [HDLog initLogger];
        }
        
        do {
            va_list args;
            va_start(args, format);
            NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
            va_end(args);
            DDLogError(@"%@", msg);
        } while (0);
    }
}

+ (void)setLogLevel:(int)logLevel
{
    s_HDLogLevel = logLevel;
    [[self class] setDDLogLevel];
}

+ (void)initLogger
{
    if (!s_LoggerInited)
    {
        do {
            [DDLog addLogger:[DDASLLogger sharedInstance]];
            [DDLog addLogger:[DDTTYLogger sharedInstance]];
            [[self class] setDDLogLevel];
            s_LoggerInited = YES;
        } while (0);
    }
}

+ (void)setDDLogLevel
{
    ddLogLevel = DDLogLevelOff;
    if ((s_HDLogLevel & HDLOG_FLAG_DEBUG) > 0) {
        ddLogLevel |= DDLogLevelDebug;
    }
    if ((s_HDLogLevel & HDLOG_FLAG_INFO) > 0) {
        ddLogLevel |= DDLogLevelInfo;
    }
    if ((s_HDLogLevel & HDLOG_FLAG_WARN) > 0) {
        ddLogLevel |= DDLogLevelWarning;
    }
    if ((s_HDLogLevel & HDLOG_FLAG_ERROR) > 0) {
        ddLogLevel |= DDLogLevelError;
    }
    if ((s_HDLogLevel & HDLOG_FLAG_FATAL) > 0) {
        ddLogLevel |= DDLogLevelError;
    }
}

@end
