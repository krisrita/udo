//
//  HDDataUtil.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDDataUtil.h"

@implementation HDDataUtil

+ (id)nilIfNull:(id)object
{
    return ([NSNull null] == object) ? nil : object;
}


+ (NSInteger)integerForObject:(id)object
{
    return ([NSNull null] == object || nil == object) ? 0 : [object integerValue];
}

+ (long)longForObject:(id)object
{
    return ([NSNull null] == object || nil == object) ? 0 : [object longValue];
}

+ (long long)longLongForObject:(id)object
{
    return ([NSNull null] == object || nil == object) ? 0 : [object longLongValue];
}


+ (float)floatForObject:(id)object
{
    return ([NSNull null] == object || nil == object) ? 0.0f : [object floatValue];
}

+ (double)doubleForObject:(id)object
{
    return ([NSNull null] == object || nil == object) ? 0.0f : [object doubleValue];
}

+ (BOOL)boolForObject:(id)object
{
    return ([NSNull null] == object || nil == object) ? NO : [object boolValue];
}

+ (NSString *)stringForObject:(id)object
{
    return ([NSNull null] == object || nil == object) ? nil : object;
}


@end
