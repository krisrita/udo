//
//  HDImageUrl.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDImageUrl.h"

@interface HDImageUrl ()

@property (nonatomic,copy)NSString *originalImageUrl;

@end

@implementation HDImageUrl

+ (instancetype)imageUrlWithName:(NSString *)imageName {
    
    HDImageUrl *imageUrl = [[self alloc] init];
    imageUrl.imageName = imageName ? imageName : @"";

    return imageUrl;
}

- (NSString *)small {
    return ConvertImageUrl(1, 200, 200);
}

- (NSString *)medium {
    return ConvertImageUrl(1, 200, 200);
}

- (NSString *)large {
    return ConvertImageUrl(1, 200, 200);
}

@end
