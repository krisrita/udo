//
//  HDDate.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDDate.h"

@interface HDDate() {
    __strong NSDate *_date;
}
@end

@implementation HDDate

+ (instancetype)now
{
    return [[[self class] alloc] initWithDate:[NSDate date]];
}

+ (instancetype)dateWithSeconds:(NSTimeInterval)seconds
{
    return [[[self class] alloc] initWithDate:[NSDate dateWithTimeIntervalSince1970:seconds]];
}

- (NSString *)INTERVALAGO
{
    HDDate *now = [HDDate now];
    NSTimeInterval interval = [[now date] timeIntervalSinceDate:_date];
    long distance = interval < 0.0f ? 0 : (long)interval;
    
    NSString *sdate = nil;
    
    if (distance < 60) {
        sdate = @"刚刚";
    }
    else if (distance < 60 * 60) {
        sdate = [NSString stringWithFormat:@"%ld%@", distance / 60, @"分钟前"];
    }
    else if ((distance < 24 * 60 * 60)) {
        sdate = [NSString stringWithFormat:@"%ld%@", distance / (60 * 60), @"小时前"];
    }
    else if ((distance < 30 * 24 * 60 * 60)) {
        sdate = [NSString stringWithFormat:@"%ld%@", distance / (24 * 60 * 60), @"天前"];
    }
    else if ((distance < 12 * 30 * 24 * 60 * 60)) {
        sdate = [NSString stringWithFormat:@"%ld%@", distance / (30 * 24 * 60 * 60), @"个月前"];
    }
    else {
        sdate = [self ENYYYYMMDD];
    }
    
    return sdate;
}

- (NSString *)ENYYYYMMDD
{
    return [self formatDate:@"yyyy-MM-dd"];
}

#pragma mark - private method

- (instancetype)initWithDate:(NSDate *)date
{
    if (self = [super init]) {
        if (date) {
            _date = date;
        }
        else {
            _date = [NSDate dateWithTimeIntervalSince1970:0.0f];
        }
    }
    
    return self;
}

- (void)dealloc
{
    _date = nil;
}

- (NSString *)formatDate:(NSString *)format
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setTimeStyle:NSDateFormatterFullStyle];
    [formatter setDateFormat:format];
    NSTimeZone *timeZone = [NSTimeZone defaultTimeZone];
    [formatter setTimeZone:timeZone];
    NSString *dateString = [formatter stringFromDate:_date];
    return dateString;
}

- (NSDate *)date
{
    return _date;
}

@end
