//
//  HDVideoImageUrl.m
//  udo_stu
//
//  Created by nobody on 6/2/15.
//  All rights reserved.
//

#import "HDVideoImageUrl.h"

@implementation HDVideoImageUrl

- (NSString *)small {
    return ConvertImageUrl(1, 373, 191);
}

- (NSString *)medium {
    return ConvertImageUrl(1, 373, 191);
}

- (NSString *)large {
    return ConvertImageUrl(1, 373, 191);
}

@end
