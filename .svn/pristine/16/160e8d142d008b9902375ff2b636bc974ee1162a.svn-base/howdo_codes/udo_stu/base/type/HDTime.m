
//
//  MCTime.m
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDTime.h"

typedef struct {
    NSInteger hour;
    NSInteger minute;
    NSInteger second;
} TimeStruct;

@interface HDTime() {
    NSInteger _seconds;
}

@end

@implementation HDTime

- (instancetype)initWithSeconds:(NSInteger)seconds
{
    if (self = [super init]) {
        _seconds = seconds;
    }
    return self;
}

+ (instancetype)timeWithSeconds:(NSInteger)seconds
{
    return [[HDTime alloc] initWithSeconds:seconds];
}

- (NSInteger)seconds
{
    return _seconds;
}

- (NSInteger)minutes {
    return (NSInteger)(_seconds / 60);
}

- (NSInteger)maxdays {
    NSInteger days = _seconds / (24 * 60 * 60);
    days = (_seconds % (24 * 60 * 60)) > 0 ? days++ : days;
    return days;
}

- (NSString *)ENAUTOHHMMSS
{
    NSString *time = nil;
    TimeStruct stime = [self parseTime];
    if (stime.hour > 0) {
        time = [NSString stringWithFormat:@"%ld:%02ld:%02ld", (long)stime.hour, (long)stime.minute, (long)stime.second];
    } else {
        time = [NSString stringWithFormat:@"%ld:%02ld", (long)stime.minute, (long)stime.second];
    }
    return time;
}

#pragma mark - private methods

- (TimeStruct)parseTime
{
    TimeStruct stime = {0, 0, 0};
    if (_seconds >= 0) {
        NSInteger seconds = _seconds;
        stime.hour = seconds / 3600;
        seconds = seconds % 3600;
        stime.minute = seconds / 60;
        stime.second = seconds % 60;
    }
    return stime;
}

@end
