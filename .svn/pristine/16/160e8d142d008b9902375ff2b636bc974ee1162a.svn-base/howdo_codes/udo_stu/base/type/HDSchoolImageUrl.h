//
//  HDSchoolImageUrl.h
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDImageUrl.h"

@interface HDSchoolImageUrl : HDImageUrl

@end
