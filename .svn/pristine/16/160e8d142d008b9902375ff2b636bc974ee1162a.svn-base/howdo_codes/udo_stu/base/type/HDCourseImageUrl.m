//
//  HDCourseImageUrl.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDCourseImageUrl.h"

@implementation HDCourseImageUrl

- (NSString *)small {
    return ConvertImageUrl(1, 200, 200);
}

- (NSString *)medium {
    return ConvertImageUrl(1, 300, 300);
}

- (NSString *)large {
    return ConvertImageUrl(1, 400, 400);
}

@end
