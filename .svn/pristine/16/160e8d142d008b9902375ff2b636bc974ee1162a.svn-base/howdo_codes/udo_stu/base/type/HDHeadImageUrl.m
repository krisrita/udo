//
//  HDHeadImageUrl.m
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDHeadImageUrl.h"

@implementation HDHeadImageUrl

- (NSString *)small {
    return ConvertImageUrl(1, 100, 100);
}

- (NSString *)medium {
    return ConvertImageUrl(1, 200, 200);
}

- (NSString *)large {
    return ConvertImageUrl(1, 200, 200);
}

@end
