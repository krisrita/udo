//
//  HDNoteImageUrl.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDImageUrl.h"
#import "HDImageUrl.h"

@interface HDNoteImageUrl : HDImageUrl

@end
