//
//  HDCourseImageUrl.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import "HDImageUrl.h"

@interface HDCourseImageUrl : HDImageUrl

@end
