//
//  HDSchoolImageUrl.m
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDSchoolImageUrl.h"

@implementation HDSchoolImageUrl

- (NSString *)small {
    return ConvertImageUrl(1, 200, 200);
}

- (NSString *)medium {
    return ConvertImageUrl(1, 300, 300);
}

- (NSString *)large {
    return self.imageName;
}

@end
