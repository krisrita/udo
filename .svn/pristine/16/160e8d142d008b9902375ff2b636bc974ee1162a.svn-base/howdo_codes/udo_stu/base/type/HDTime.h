
//
//  HDTime.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  自定义时间
 */
@interface HDTime : NSObject

+ (instancetype)timeWithSeconds:(NSInteger)seconds;

- (NSInteger)seconds;
- (NSInteger)minutes;
- (NSInteger)maxdays;

- (NSString *)ENAUTOHHMMSS;

@end

