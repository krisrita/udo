//
//  HDVideoImageUrl.h
//  udo_stu
//
//  Created by nobody on 6/2/15.
//  All rights reserved.
//

#import "HDImageUrl.h"

@interface HDVideoImageUrl : HDImageUrl

@end
