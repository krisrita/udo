//
//  HDImageUrl.h
//  udo_stu
//
//  Created by nobody on 5/31/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

#define ConvertImageUrl(mode, w, h) [NSString stringWithFormat:@"%@?imageView2/%d/w/%d/h/%d", self.imageName, (mode), (w), (h)]; 

@interface HDImageUrl : NSObject

@property (nonatomic, strong) NSString *imageName;

+ (instancetype)imageUrlWithName:(NSString *)imageName;

- (NSString *)small;
- (NSString *)medium;
- (NSString *)large;

@end
