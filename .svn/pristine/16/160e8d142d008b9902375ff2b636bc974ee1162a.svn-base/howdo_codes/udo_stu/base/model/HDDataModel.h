//
//  HDDataModel.h
//  udo_stu
//
//  Created by nobody on 5/30/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDDataModel : MTLModel

+ (instancetype)modelWithData:(id)data;
+ (BOOL)isValidData:(id)data;

@end
