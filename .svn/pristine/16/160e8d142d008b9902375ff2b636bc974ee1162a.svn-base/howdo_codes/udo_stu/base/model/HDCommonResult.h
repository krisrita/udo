//
//  HDCommonResult.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_OPTIONS(NSUInteger, HDResultCode) {
    HD_RESULT_CODE_SUCCESS,
    HD_RESULT_CODE_EMPTY,
    HD_RESULT_CODE_FAILURE,
    HD_RESULT_CODE_NETWORK_FAILURE
};

@interface HDCommonResult : NSObject

@property (nonatomic, assign) HDResultCode resultCode;
@property (nonatomic, strong) NSString *resultDesc;


+ (instancetype)resultWithData:(int)resultCode resultDesc:(NSString *)resultDesc;
- (instancetype)initWithData:(int)resultCode resultDesc:(NSString *)resultDesc;

+ (instancetype)resultWithData:(id)responseObject;

+ (instancetype)resultWithError:(NSError *)error;
- (instancetype)initWithError:(NSError *)error;

- (BOOL)isExposedToUser;
+ (BOOL)isExposedToUser:(int)resultCode;

@end
