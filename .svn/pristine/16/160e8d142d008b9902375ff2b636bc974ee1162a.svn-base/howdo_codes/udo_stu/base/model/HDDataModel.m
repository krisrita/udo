//
//  HDDataModel.m
//  udo_stu
//
//  Created by nobody on 5/30/15.
//  All rights reserved.
//

#import "HDDataModel.h"

@implementation HDDataModel

+ (instancetype) modelWithData:(id)data {
    HDDataModel *model = [[self alloc] init];
    if ([[self class] isValidData:data]) {
    }
    return model;
}

+ (BOOL)isValidData:(id)data
{
    BOOL result = NO;
    if (nil != data && [NSNull null] != data && [data isKindOfClass:[NSDictionary class]]) {
        result = YES;
    }
    return result;
}

@end
