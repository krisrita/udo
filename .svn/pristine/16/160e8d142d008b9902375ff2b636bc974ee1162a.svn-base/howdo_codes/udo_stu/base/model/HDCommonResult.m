//
//  HDCommonResult.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDCommonResult.h"

@implementation HDCommonResult
- (instancetype)init
{
    if (self = [super init])
    {
        self.resultCode = HD_RESULT_CODE_SUCCESS;
        self.resultDesc = @"";
    }
    
    return self;
}

- (instancetype)initWithData:(int)resultCode resultDesc:(NSString *)resultDesc
{
    if (self = [self init])
    {
        NSInteger code = resultCode;
        switch (code) {
            case 0:
                self.resultCode = HD_RESULT_CODE_SUCCESS;
                break;
            case 1:
                self.resultCode = HD_RESULT_CODE_EMPTY;
                break;
            case 2:
                self.resultCode = HD_RESULT_CODE_FAILURE;
                break;
            default:
                self.resultCode = HD_RESULT_CODE_NETWORK_FAILURE;
                
                break;
        }

        self.resultDesc = resultDesc;
    }
    return self;
}

- (instancetype)initWithError:(NSError *)error
{
    if (self = [self init])
    {
      
    }
    
    return self;
}

#pragma mark - class method

+ (instancetype)resultWithData:(int)resultCode resultDesc:(NSString *)resultDesc
{
    return [[self alloc] initWithData:resultCode resultDesc:resultDesc];
}

+ (instancetype)resultWithData:(id)responseObject
{
    HDCommonResult *commonResult = [[self alloc] init];
    
    if (responseObject != nil && responseObject != [NSNull null] && [responseObject isKindOfClass:[NSDictionary class]]) {
    }
    
    return commonResult;
}


+ (instancetype)resultWithError:(NSError *)error
{
    return [[self alloc] initWithError:error];
}

+ (BOOL)isExposedToUser:(int)resultCode
{
    BOOL bExposedToUser = NO;
    
    return bExposedToUser;
}

#pragma mark - instance method

- (BOOL)isExposedToUser
{
    return [[self class] isExposedToUser:self.resultCode];
}

@end
