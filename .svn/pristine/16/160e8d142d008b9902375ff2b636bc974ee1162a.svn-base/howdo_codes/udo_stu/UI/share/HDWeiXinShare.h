//
//  HDWeiXinShare.h
//
//
//  Created by nobody on 14-5-15.
//  All rights reserved.
//

typedef void (^MCShareBackBlock)(HDCommonResult *result);


#import <Foundation/Foundation.h>
#import "HDSNSDefine.h"

@interface HDWeiXinShare : NSObject
+ (instancetype)sharedInstance;

-(BOOL)snsWeiXinHandleOpenUrl:(NSURL *)url;

-(void)weiXinShareToWXSessionTitle:(NSString *)title
                       imageUrlStr:(NSString *)imgUrlStr
                       shareUrlStr:(NSString *)shareUrlStr
                          Complete:(MCShareBackBlock)complete;


-(void)weiXinShareToWXTimeLineTitle:(NSString *)title
                        imageUrlStr:(NSString *)imgUrlStr
                        shareUrlStr:(NSString *)shareUrlStr
                           Complete:(MCShareBackBlock)complete;

-(BOOL)canShareToWX;

@end
