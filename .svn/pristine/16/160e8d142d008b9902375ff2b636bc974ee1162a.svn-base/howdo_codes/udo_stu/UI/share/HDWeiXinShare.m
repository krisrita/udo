//
//  HDWeiXinShare.m
//
//
//  Created by nobody on 14-5-15.
//  All rights reserved.
//

#import "HDWeiXinShare.h"
#import "WXApi.h"
#import "HDSNSDefine.h"
@interface HDWeiXinShare()<WXApiDelegate>
{
    MCShareBackBlock backBlock;
}
@property (nonatomic,strong) NSString * shareTitle;
@property (nonatomic,strong) NSString * shareUrl;
@property (nonatomic,strong) NSString * shareImgUr;
@property (nonatomic,assign) int shareTag;
@property (nonatomic,strong) UIImage * shareImg;

@end

@implementation HDWeiXinShare


+ (instancetype)sharedInstance
{
    static HDWeiXinShare * shareInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        shareInstance = [[self alloc] init];
        [WXApi registerApp:WEIXINAppID];
    });
    return shareInstance;
}

-(BOOL)snsWeiXinHandleOpenUrl:(NSURL *)url
{
    BOOL isSuc = [WXApi handleOpenURL:url delegate:self];
    return  isSuc;
}

-(BOOL)canShareToWX
{
    return [WXApi isWXAppInstalled]&& [WXApi isWXAppSupportApi];
}
-(void)weiXinShareToWXSessionTitle:(NSString *)title
                       imageUrlStr:(NSString *)imgUrlStr
                       shareUrlStr:(NSString *)shareUrlStr
                          Complete:(MCShareBackBlock)complete
{
    backBlock = complete;
    
    /* 0:表示session  1:表示timeline */
    [self shareTag:0 title:title  imgUrlStr:imgUrlStr shareUrlStr:shareUrlStr];
}

-(void)weiXinShareToWXTimeLineTitle:(NSString *)title
                        imageUrlStr:(NSString *)imgUrlStr
                        shareUrlStr:(NSString *)shareUrlStr
                           Complete:(MCShareBackBlock)complete
{
    backBlock  = complete;
    
    /* 0:表示session  1:表示timeline */
    [self shareTag:1 title:title  imgUrlStr:imgUrlStr shareUrlStr:shareUrlStr];
}

-(void)shareTag:(int)tempTag
          title:(NSString *)title
      imgUrlStr:(NSString *)imgUrlStr
    shareUrlStr:(NSString *)shareUrl
{
    
    self.shareTitle = title;
    self.shareImgUr = imgUrlStr;
    self.shareUrl = shareUrl;
    self.shareTag = tempTag;

    NSData * data = nil;//bhl
    if (data == nil)
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage * img = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imgUrlStr]]];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.shareImg = img;
            [self BegingShare];
            
        });
    });
    }
    else
    {
        self.shareImg = [UIImage imageWithData:data];
        [self BegingShare];
    }
}


-(void)BegingShare
{
//    +(BOOL) isWXAppInstalled;
//    
//    /*! @brief 判断当前微信的版本是否支持OpenApi
//     *
//     * @return 支持返回YES，不支持返回NO。
//     */
//    +(BOOL) isWXAppSupportApi;
    if ([WXApi isWXAppInstalled] && [WXApi isWXAppSupportApi])
    {
            NSString * str = [NSString stringWithFormat:@"%@",self.shareTitle];
            WXMediaMessage *message = [WXMediaMessage message];
            message.title = self.shareTitle;
            message.description = str;
            
            [message setThumbImage:self.shareImg];
            
            WXWebpageObject *ext = [WXWebpageObject object];
            ext.webpageUrl = self.shareUrl;
            message.mediaObject = ext;
            
            SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
            req.bText = NO;
            req.message = message;
            req.scene = self.shareTag;
            [WXApi sendReq:req];
    }
    else
    {
        UIAlertView * alart =[[UIAlertView alloc]initWithTitle:@"提示" message:@"未安装微信" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alart show];
    }

}



/*! @brief 收到一个来自微信的请求，第三方应用程序处理完后调用sendResp向微信发送结果
 *
 * 收到一个来自微信的请求，异步处理完成后必须调用sendResp发送处理结果给微信。
 * 可能收到的请求有GetMessageFromWXReq、ShowMessageFromWXReq等。
 * @param req 具体请求内容，是自动释放的
 */
-(void) onReq:(BaseReq*)req
{
    if([req isKindOfClass:[GetMessageFromWXReq class]])
    {
        // 微信请求App提供内容， 需要app提供内容后使用sendRsp返回
        NSString *strTitle = [NSString stringWithFormat:@"微信请求App提供内容"];
        NSString *strMsg = @"微信请求App提供内容，App要调用sendResp:GetMessageFromWXResp返回给微信";
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        alert.tag = 1000;
        [alert show];
    }
    else if([req isKindOfClass:[ShowMessageFromWXReq class]])
    {
        ShowMessageFromWXReq* temp = (ShowMessageFromWXReq*)req;
        WXMediaMessage *msg = temp.message;
        
        //显示微信传过来的内容
        WXAppExtendObject *obj = msg.mediaObject;
        
        NSString *strTitle = [NSString stringWithFormat:@"微信请求App显示内容"];
        NSString *strMsg = [NSString stringWithFormat:@"标题：%@ \n内容：%@ \n附带信息：%@ \n缩略图:%u bytes\n\n", msg.title, msg.description, obj.extInfo, msg.thumbData.length];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([req isKindOfClass:[LaunchFromWXReq class]])
    {
        //从微信启动App
        NSString *strTitle = [NSString stringWithFormat:@"从微信启动"];
        NSString *strMsg = @"这是从微信启动的消息";
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }

}

/*! @brief 发送一个sendReq后，收到微信的回应
 *
 * 收到一个来自微信的处理结果。调用一次sendReq后会收到onResp。
 * 可能收到的处理结果有SendMessageToWXResp、SendAuthResp等。
 * @param resp具体的回应内容，是自动释放的
 */
-(void) onResp:(BaseResp*)resp
{
    if([resp isKindOfClass:[SendMessageToWXResp class]])
    {
        NSString *strTitle = [NSString stringWithFormat:@"发送媒体消息结果"];
        NSString *strMsg = [NSString stringWithFormat:@"errcode:%d", resp.errCode];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }

}


@end
