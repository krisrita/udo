//
//  BSbottomModel.m
//
//
//  Created by nobody on 13-7-19.
//  All rights reserved.
//

#import "BSbottomModel.h"
#import <QuartzCore/QuartzCore.h>



CGFloat const KGBottomFadeInAnimationDuration = 0.3;
CGFloat const KGBottomTransformPart1AnimationDuration = 0.5;
CGFloat const KGBottomTransformPart2AnimationDuration = 0.3;
NSString *const KGBottomModalGradientViewTapped = @"BSbottomModelGradientViewTapped";

@interface  BSbottomGradientView : UIView
@end

@interface  BSbottomContainerView : UIView
@end

@interface  BSbottomCloseButton : UIButton
@end

@interface BSbottomViewController : UIViewController
@property (strong, nonatomic)  BSbottomGradientView *styleView;
@end

@interface BSbottomModel()
@property (strong, nonatomic) BSbottomViewController *viewController;
@property (strong, nonatomic) BSbottomContainerView *containerView;
@property (strong, nonatomic) BSbottomCloseButton *closeButton;
@property (strong, nonatomic) UIView *contentView;
//@property (strong, nonatomic) FXBlurView *blre;
@property (nonatomic,assign,readwrite) BOOL isPop_up;
@property (strong, nonatomic) MCShareViewPoped popedShowBlock;
@property (strong ,nonatomic) MCShareViewDismissed dismissShowBlock;
@end

@implementation BSbottomModel

//单例的创建
+ (id)sharedInstance{
    static id sharedInstance;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sharedInstance = [[[self class] alloc] init];
    });
    return sharedInstance;
}

- (id)init{
    if(!(self = [super init])){
        return nil;
    }
    
    //    默认的都显示
    self.tapOutsideToDismiss = YES;
    self.animateWhenDismissed = YES;
    self.showCloseButton = YES;
    
    return self;
    

}

- (void)setShowCloseButton:(BOOL)showCloseButton
{
    if(_showCloseButton != showCloseButton)
    {
        _showCloseButton = showCloseButton;
        [self.closeButton setHidden:!self.showCloseButton];
    }
}

- (void)showWithContentView:(UIView *)contentView{
    [self showWithContentView:contentView andAnimated:YES showBlock:NULL dismissBlock:NULL];
}

- (void)showWithContentView:(UIView *)contentView andAnimated:(BOOL)animated showBlock:(MCShareViewPoped)popBlock dismissBlock:(MCShareViewDismissed)dismissBlock
{
    self.popedShowBlock = popBlock;
    self.dismissShowBlock = dismissBlock;
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    self.window.opaque = NO;
    

    BSbottomViewController *viewController = self.viewController = [[BSbottomViewController alloc] init];
    self.window.rootViewController = viewController;
    
    CGFloat padding = 0;
    CGRect containerViewRect = CGRectInset(contentView.bounds, -padding, -padding);
    containerViewRect.origin.x = containerViewRect.origin.y = 0;
//    containerViewRect.origin.x = round(CGRectGetMidX(self.window.bounds)-CGRectGetMidX(containerViewRect));
//    containerViewRect.origin.y = round(CGRectGetMidY(self.window.bounds)-CGRectGetMidY(containerViewRect));
     BSbottomContainerView *containerView = self.containerView = [[ BSbottomContainerView alloc] initWithFrame:containerViewRect];
//    containerView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|
//    UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleBottomMargin;
    //    ？？？？
    containerView.layer.rasterizationScale = [[UIScreen mainScreen] scale];
    contentView.frame = (CGRect){padding, padding, APP_SCREEN_WIDTH,containerViewRect.size.height};
    [containerView addSubview:contentView];
    [viewController.view addSubview:containerView];
    

     BSbottomCloseButton *closeButton = self.closeButton = [[ BSbottomCloseButton alloc] init];
    [closeButton addTarget:self action:@selector(closeAction:) forControlEvents:UIControlEventTouchUpInside];
    [closeButton setHidden:!self.showCloseButton];
    [containerView addSubview:closeButton];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tapCloseAction:)
                                                 name:KGBottomModalGradientViewTapped object:nil];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.window != nil) {
            [self.window setHidden:NO];
        }
        
//        if (self.blre == nil)
//        {
//            self.blre = [[FXBlurView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_SCREEN_HEIGHT)];
//            self.blre.blurRadius = 0;
//            self.blre.blurEnabled = YES;
//            self.blre.dynamic = NO;
//            self.blre.iterations = 150;
//            self.blre.tintColor = [UIColor clearColor];
//            [[[UIApplication sharedApplication]keyWindow] addSubview:self.blre];
//        }

        if(animated){
            viewController.styleView.alpha = 0;
            [UIView animateWithDuration:KGBottomFadeInAnimationDuration animations:^{
                viewController.styleView.alpha = 1;
            }];
            containerView.alpha = 0;
            containerView.layer.shouldRasterize = YES;
            containerView.transform =CGAffineTransformTranslate(CGAffineTransformIdentity, containerView.frame.origin.x, APP_CONTENT_HEIGHT);
            [UIView animateWithDuration:KGBottomTransformPart1AnimationDuration animations:^{
                containerView.alpha = 1;
                containerView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, containerView.frame.origin.x, APP_CONTENT_HEIGHT-CGRectGetHeight(containerView.frame));
            } completion:^(BOOL finished) {
            
                [UIView animateWithDuration:KGBottomTransformPart2AnimationDuration delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                    containerView.alpha = 1;
                    
                } completion:^(BOOL finished2) {
                    containerView.layer.shouldRasterize = NO;
                }];
                self.isPop_up = YES;
                if (self.popedShowBlock != nil) {
                    self.popedShowBlock();
                    self.popedShowBlock = nil;
                }
            }];
        }
    });
}

- (void)closeAction:(id)sender
{
    [self hideAnimated:self.animateWhenDismissed dismissBlock:NULL];
}

- (void)tapCloseAction:(id)sender{
    if(self.tapOutsideToDismiss){
        [self hideAnimated:self.animateWhenDismissed dismissBlock:NULL];
    }
}

- (void)hide{
    if (self.isPop_up) {
        [self hideAnimated:YES dismissBlock:NULL];
    }
    
}

- (void)showNewViewAndhideAnimated:(BOOL)animated dismissBlock:(MCShareViewDismissed)dismissBlock
{
//    if (self.blre != nil)
//    {
//        [self.blre removeFromSuperview];
//        self.blre = nil;
//    }
    
    if(!animated)
    {
        [self cleanup];
        if (dismissBlock)
        {
            dismissBlock();
        }
        
        return;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:KGBottomTransformPart1AnimationDuration animations:^{
            self.viewController.styleView.alpha = 0;
        }];
        
        self.containerView.layer.shouldRasterize = YES;
        [UIView animateWithDuration:KGBottomTransformPart1AnimationDuration animations:^{
            self.containerView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, self.containerView.frame.origin.x, APP_CONTENT_HEIGHT);
        } completion:^(BOOL finished){
            [self cleanup];
            self.isPop_up = NO;
            
            
            if (dismissBlock)
            {
                dismissBlock();
            }
        }];
    });

}


- (void)hideAnimated:(BOOL)animated dismissBlock:(MCShareViewDismissed)dismissBlock;
{
//    if (self.blre != nil)
//    {
//        [self.blre removeFromSuperview];
//        self.blre = nil;
//    }

    if(!animated)
    {
        [self cleanup];
        if (dismissBlock)
        {
            dismissBlock();
        }

        return;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:KGBottomTransformPart1AnimationDuration animations:^{
            self.viewController.styleView.alpha = 0;
        }];
        
        self.containerView.layer.shouldRasterize = YES;
        [UIView animateWithDuration:KGBottomTransformPart1AnimationDuration animations:^{
            self.containerView.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, self.containerView.frame.origin.x, APP_CONTENT_HEIGHT);
        } completion:^(BOOL finished){
            [self cleanup];
            self.isPop_up = NO;
            
            if (self.dismissShowBlock)
            {
                self.dismissShowBlock();
                self.dismissShowBlock = nil;
                self.popedShowBlock = nil;
            }
            
            if (dismissBlock)
            {
                dismissBlock();
            }
        }];
    });
}

- (void)cleanup{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self.containerView removeFromSuperview];
    self.viewController = nil;
    self.containerView = nil;
    self.closeButton = nil;
    [self.window removeFromSuperview];
    self.window = nil;
}

@end

@implementation BSbottomViewController

- (void)loadView{
    self.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    //    这是在后面加的灰色view
     BSbottomGradientView *styleView = self.styleView = [[ BSbottomGradientView alloc] initWithFrame:self.view.bounds];
    styleView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    styleView.opaque = NO;
    [self.view addSubview:styleView];
}
- (BOOL)shouldAutorotate
{
    return self.presentedViewController.shouldAutorotate;
}

- (NSUInteger)supportedInterfaceOrientations
{
    return self.presentedViewController.supportedInterfaceOrientations;
}

@end

@implementation  BSbottomContainerView

- (id)initWithFrame:(CGRect)frame{
    if(!(self = [super initWithFrame:frame])){
        return nil;
    }
    
    CALayer *styleLayer = [[CALayer alloc] init];
    styleLayer.cornerRadius = 4;
    styleLayer.shadowColor= [[UIColor blackColor] CGColor];
    styleLayer.shadowOffset = CGSizeMake(0, 0);
    styleLayer.shadowOpacity = 0.5;
    styleLayer.borderWidth = 1;
    styleLayer.borderColor = [[UIColor whiteColor] CGColor];
    styleLayer.backgroundColor = [[UIColor clearColor] CGColor];
    styleLayer.frame = CGRectInset(self.bounds, 0, 0);
    [self.layer addSublayer:styleLayer];
    
    return self;
}

@end

@implementation  BSbottomGradientView

//点击弹出视图以为，调用这个函数，思路和不错
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [[NSNotificationCenter defaultCenter] postNotificationName:KGBottomModalGradientViewTapped object:nil];
}

- (void)drawRect:(CGRect)rect{
    CGContextRef context = UIGraphicsGetCurrentContext();
    if([[BSbottomModel sharedInstance] backgroundDisplayStyle] == BSModalBackgroundDisplayStyleSolid){
        [[UIColor clearColor] set];
        CGContextFillRect(context, self.bounds);
    }else{
        //        CGContextSaveGState、CGContextRestoreGState只在这次话的有效果，在出现得到UIGraphicsGetCurrentContext，不会出现这样的效果
        CGContextSaveGState(context);
        size_t gradLocationsNum = 2;
        //        gradLocations[2]控制渐变速度的程度
        CGFloat gradLocations[2] = {0.0f, 1.0f};
        CGFloat gradColors[8] = {0, 0, 0, 0.3, 0, 0, 0, 0.8};
        //CGColorGetComponents(<#CGColorRef color#>)可以得到rgb alpah的的四个值
        //        CGColorGetComponents(<#CGColorRef color#>)
        
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGGradientRef gradient = CGGradientCreateWithColorComponents(colorSpace, gradColors, gradLocations, gradLocationsNum);
        CGColorSpaceRelease(colorSpace), colorSpace = NULL;
        CGPoint gradCenter= CGPointMake(round(CGRectGetMidX(self.bounds)), round(CGRectGetMidY(self.bounds)));
        CGFloat gradRadius = MAX(CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds));
        CGContextDrawRadialGradient(context, gradient, gradCenter, 0, gradCenter, gradRadius, kCGGradientDrawsAfterEndLocation);
        CGGradientRelease(gradient), gradient = NULL;
        CGContextRestoreGState(context);
    }
}

@end

@implementation BSbottomCloseButton

- (id)init{
    if(!(self = [super initWithFrame:(CGRect){0, 0, 32, 32}]))
    {
        return nil;
    }
    static UIImage *closeButtonImage;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        closeButtonImage = [self closeButtonImage];
    });
    [self setBackgroundImage:closeButtonImage forState:UIControlStateNormal];
    return self;
}

//出的uiimage，不错啊

- (UIImage *)closeButtonImage{
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0);
    
    //// General Declarations
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    //// Color Declarations
    UIColor *topGradient = [UIColor colorWithRed:0.21 green:0.21 blue:0.21 alpha:0.9];
    UIColor *bottomGradient = [UIColor colorWithRed:0.03 green:0.03 blue:0.03 alpha:0.9];
    
    //// Gradient Declarations
    NSArray *gradientColors = @[(id)topGradient.CGColor,
                                (id)bottomGradient.CGColor];
    CGFloat gradientLocations[] = {0, 1};
    CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)gradientColors, gradientLocations);
    
    //// Shadow Declarations
    CGColorRef shadow = [UIColor blackColor].CGColor;
    CGSize shadowOffset = CGSizeMake(0, 1);
    CGFloat shadowBlurRadius = 3;
    CGColorRef shadow2 = [UIColor blackColor].CGColor;
    CGSize shadow2Offset = CGSizeMake(0, 1);
    CGFloat shadow2BlurRadius = 0;
    
    
    //// Oval Drawing
    UIBezierPath *ovalPath = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(4, 3, 24, 24)];
    CGContextSaveGState(context);
    [ovalPath addClip];
    CGContextDrawLinearGradient(context, gradient, CGPointMake(16, 3), CGPointMake(16, 27), 0);
    CGContextRestoreGState(context);
    
    CGContextSaveGState(context);
    CGContextSetShadowWithColor(context, shadowOffset, shadowBlurRadius, shadow);
    [[UIColor whiteColor] setStroke];
    ovalPath.lineWidth = 2;
    [ovalPath stroke];
    CGContextRestoreGState(context);
    
    
    //// Bezier Drawing
    UIBezierPath *bezierPath = [UIBezierPath bezierPath];
    [bezierPath moveToPoint:CGPointMake(22.36, 11.46)];
    [bezierPath addLineToPoint:CGPointMake(18.83, 15)];
    [bezierPath addLineToPoint:CGPointMake(22.36, 18.54)];
    [bezierPath addLineToPoint:CGPointMake(19.54, 21.36)];
    [bezierPath addLineToPoint:CGPointMake(16, 17.83)];
    [bezierPath addLineToPoint:CGPointMake(12.46, 21.36)];
    [bezierPath addLineToPoint:CGPointMake(9.64, 18.54)];
    [bezierPath addLineToPoint:CGPointMake(13.17, 15)];
    [bezierPath addLineToPoint:CGPointMake(9.64, 11.46)];
    [bezierPath addLineToPoint:CGPointMake(12.46, 8.64)];
    [bezierPath addLineToPoint:CGPointMake(16, 12.17)];
    [bezierPath addLineToPoint:CGPointMake(19.54, 8.64)];
    [bezierPath addLineToPoint:CGPointMake(22.36, 11.46)];
    [bezierPath closePath];
    CGContextSaveGState(context);
    CGContextSetShadowWithColor(context, shadow2Offset, shadow2BlurRadius, shadow2);
    [[UIColor whiteColor] setFill];
    [bezierPath fill];
    CGContextRestoreGState(context);
    
    
    //// Cleanup
    CGGradientRelease(gradient);
    CGColorSpaceRelease(colorSpace);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}
@end