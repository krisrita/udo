//
//  HDShareView.h
//
//
//  Created by nobody on 14-2-21.
//  All rights reserved.
//
@protocol ShareViewBtnClickDelegate <NSObject>

-(void)shareViewBtnClick:(UIButton *)btn;

@end
#import "BSbottomModel.h"
#import <UIKit/UIKit.h>

@interface HDShareView : UIView

@property (nonatomic,assign)id<ShareViewBtnClickDelegate>delegate;

@end
