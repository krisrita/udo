
//  HDShareView.m
//
//
//  Created by nobody on 14-2-21.
//  All rights reserved.
//
#import "HDShareData.h"

@interface HDShareTypeItemModle : NSObject

@property (nonatomic,copy)NSString * shareTypeImgStr;
@property (nonatomic,copy)NSString * shareTypeItemName;
@property (nonatomic,assign)HDShareType shareType;

@end

@implementation HDShareTypeItemModle

-(id)initWithShareImg:(NSString *)shareTypeImgStr
    shareTypeItemName:(NSString *)nameStr
            shareType:(HDShareType)type
{
    self = [super init];
    if (self) {
        self.shareType = type;
        self.shareTypeImgStr = shareTypeImgStr;
        self.shareTypeItemName = nameStr;
    }
    return self;
}

@end

#import "HDShareView.h"
#import "HDWeiXinShare.h"
@implementation HDShareView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        [self initializa];
    }
    return self;
}

- (void)initializa
{
    UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, 40)];
    bgView.backgroundColor = [UIColor colorWithRed:0 green:195.0/255.0 blue:160.0/255.0 alpha:1.0];
    [self addSubview:bgView];
    
    UIButton *shareCancel = [UIButton buttonWithType:UIButtonTypeCustom];
    shareCancel.frame = CGRectMake(15, 0, 40, 40);
    shareCancel.backgroundColor = [UIColor clearColor];
    [shareCancel setImage:[UIImage imageNamed:@"btn_close"] forState:UIControlStateNormal];
    [shareCancel addTarget:self action:@selector(shareCancelClicked:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:shareCancel];

    self.backgroundColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    HDShareTypeItemModle * wxSession = [[HDShareTypeItemModle alloc]initWithShareImg:@"btn_shareWXsession" shareTypeItemName:@"发送给好友" shareType:HD_SHARE_TYPE_WXSESSION];
    
    HDShareTypeItemModle * wxTimeLine = [[HDShareTypeItemModle alloc]initWithShareImg:@"btn_hareWXtimeline" shareTypeItemName:@"分享到朋友圈" shareType:HD_SHARE_TYPE_WXTIMELINE];
    
    HDShareTypeItemModle * wxQQfriend = [[HDShareTypeItemModle alloc]initWithShareImg:@"btn_shareQQFriend" shareTypeItemName:@"分享到手机QQ" shareType:HD_SHARE_TYPE_QQ_FRIEND];

    HDShareTypeItemModle * wxQQzone = [[HDShareTypeItemModle alloc]initWithShareImg:@"btn_shareQQzone" shareTypeItemName:@"分享到QQ空间" shareType:HD_SHARE_TYPE_QZONE];

    NSArray * sharetypeItms = [NSArray arrayWithObjects:wxSession,wxTimeLine,wxQQfriend,wxQQzone, nil];
    
    
    for (int i = 0; i < sharetypeItms.count; i++)
    {
        HDShareTypeItemModle * model = [sharetypeItms objectAtIndex:i];
        
        UIButton *hotPotButton = [UIButton buttonWithType:UIButtonTypeCustom];
        float jiange =( APP_CONTENT_WIDTH - 140/2 * 4)/5;
        hotPotButton.frame = CGRectMake(jiange + (140/2 + jiange)*i , 7 + CGRectGetMaxY(bgView.frame), 140/2, 100/2);
        hotPotButton.tag = model.shareType;
        [hotPotButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [hotPotButton setImage:[UIImage imageNamed:model.shareTypeImgStr] forState:UIControlStateNormal];
        hotPotButton.showsTouchWhenHighlighted = YES;
        [hotPotButton addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:hotPotButton];
    }
    
}

- (void)buttonClicked:(UIButton *)button
{
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(shareViewBtnClick:)])
    {
        [self.delegate shareViewBtnClick:button];
    }
}


- (void)shareCancelClicked:(UIButton*)button
{
    [[BSbottomModel sharedInstance]hideAnimated:YES dismissBlock:NULL];
}


@end
