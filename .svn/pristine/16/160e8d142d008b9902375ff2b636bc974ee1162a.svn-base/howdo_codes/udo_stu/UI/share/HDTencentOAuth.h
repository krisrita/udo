//
//  HDTencentOAuth.h
//
//
//  Created by nobody on 14-6-6.
//  All rights reserved.
//

#import <TencentOpenAPI/TencentOAuth.h>

@interface HDTencentOAuth : TencentOAuth
+ (BOOL)MCTencentOAuthByWeb;

@end
