//
//  HDTencentOAuth.m
//
//
//  Created by nobody on 14-6-6.
//  All rights reserved.
//

#import "HDTencentOAuth.h"
#import "TencentOpenAPI/QQApi.h"
#import <TencentOpenAPI/TencentOAuthObject.h>
#import "TencentOpenAPI/QQApiInterface.h"

#define DISMISS_ANIMATION NO
@interface MCQQLoginController : UIViewController

- (void)authorize;
- (void)authorizeCompletion:(void (^)(NSString *openid,NSString *access_token))completion;
- (void)authorizeCompletion:(void (^)(NSString *openid,NSString *access_token))completion
                   canceled:(void (^)(void))cancel
                    failure:(void (^)(void))failure;
@end
typedef void (^completionBlock)(NSString *openid,NSString *access_token);
typedef void (^canceled)(void);
typedef void (^failure)(void);
@interface MCQQLoginController ()<UIWebViewDelegate>
@property (nonatomic ,strong) NSString *QQopenid,*QQaccess_token;
@property (nonatomic ,strong) completionBlock comBlock;
@property (nonatomic ,strong) canceled cancel;

@property (nonatomic ,strong) failure failure;

@end

@implementation MCQQLoginController
- (void)authorize{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    UIViewController *controller = window.rootViewController;
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:self];
//    NSLog(@"%@ \n %@",controller,controller.presentedViewController);
//    NSLog(@"%@",controller.presentedViewController.navigationController);
    [controller.presentedViewController presentViewController:nav animated:YES completion:^{}];
}
- (void)authorizeCompletion:(void (^)(NSString *openid,NSString *access_token))completion{
    [self authorize];
    self.comBlock = completion;
}
- (void)authorizeCompletion:(void (^)(NSString *openid,NSString *access_token))completion
                   canceled:(void (^)(void))cancel
                    failure:(void (^)(void))failure{
    [self authorize];
    self.comBlock = completion;
    self.cancel = cancel;
    self.failure = failure;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"QQ登录";
    // Do any additional setup after loading the view.
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    UIWebView *web = [[UIWebView alloc] initWithFrame:window.bounds];
    web.delegate = self;
    [self.view addSubview:web];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(canceled)];
    self.navigationItem.rightBarButtonItem = rightBarItem;
    
//    NSURL *url = [NSURL URLWithString:@"http://openmobile.qq.com/oauth2.0/m_show?which=Login&ucheck=1&fall_to_wv=1&response_type=token&switch=1&state=test&client_id=100490398&redirect_uri=auth%3A%2F%2Fwww.qq.com&display=mobile&scope=get_user_info&sdkp=i"];
    NSURL *url1 = [NSURL URLWithString:@"http://openmobile.qq.com/oauth2.0/m_show?which=Login&ucheck=1&fall_to_wv=1&response_type=token&switch=1&state=test&client_id=100490398&redirect_uri=auth%3A%2F%2Fwww.qq.com&display=mobile&scope=all&sdkp=i"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url1];
    [web loadRequest:request];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)canceled{
    if (self.cancel) {
        self.cancel();
    }
    self.comBlock = nil;
    self.cancel = nil;
    self.failure = nil;
    [self.navigationController dismissViewControllerAnimated:DISMISS_ANIMATION
                                                  completion:^{
                                                      //
                                                  }];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate
{
    return NO;
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSString *requestString = request.URL.absoluteString;
    NSArray *array = [requestString componentsSeparatedByString:@"&"];
    for (NSString *str in array) {
        NSRange foundObj=[str rangeOfString:@"openid"
                                    options:NSCaseInsensitiveSearch];
        if(foundObj.length>0) {
            NSArray *array1 = [str componentsSeparatedByString:@"="];
            NSString *openid = array1.lastObject;
            if (openid.length == 32) {
                self.QQopenid = [NSString stringWithString:openid];
            }
        }
        
        NSRange foundObj1=[str rangeOfString:@"access_token"
                                     options:NSCaseInsensitiveSearch];
        if(foundObj1.length>0) {
            NSArray *array1 = [str componentsSeparatedByString:@"="];
            NSString *openid = array1.lastObject;
            if (openid.length == 32) {
                self.QQaccess_token = [NSString stringWithString:openid];
            }
        }
    }
    if(self.QQopenid.length == 32 && self.QQaccess_token.length == 32){
        if (self.comBlock) {
            self.comBlock(self.QQopenid,self.QQaccess_token);
            self.comBlock = nil;
            self.cancel = nil;
            self.failure = nil;
            [self.navigationController dismissViewControllerAnimated:DISMISS_ANIMATION
                                                          completion:^{
                                                              //
                                                          }];
        }
        return NO;
    }
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    if(self.QQopenid.length == 32 && self.QQaccess_token.length == 32){
        
    }else{
        if (self.failure) {
            self.failure();
        }
        self.comBlock = nil;
        self.cancel = nil;
        self.failure = nil;
        [self.navigationController dismissViewControllerAnimated:DISMISS_ANIMATION
                                                      completion:^{
                                                          //
                                                      }];
    }
}
@end


@implementation HDTencentOAuth
- (id)initWithAppId:(NSString *)appId
        andDelegate:(id<TencentSessionDelegate>)delegate{
    self = [super initWithAppId:appId andDelegate:delegate];
    if (self) {
        return self;
    }
    return nil;
}
- (BOOL)authorize:(NSArray *)permissions
		 inSafari:(BOOL)bInSafari{
    if ([HDTencentOAuth MCTencentOAuthByWeb]) {
        return [super authorize:permissions inSafari:bInSafari];
    }
    MCQQLoginController *controller = [[MCQQLoginController alloc] init];
    [controller authorizeCompletion:^(NSString *openid, NSString *access_token) {
        //
        self.accessToken = access_token;
        self.openId = openid;
        if ([self.sessionDelegate respondsToSelector:@selector(tencentDidLogin)]) {
            [self.sessionDelegate tencentDidLogin];
        }
    } canceled:^{
        if ([self.sessionDelegate respondsToSelector:@selector(tencentDidNotLogin:)]) {
            [self.sessionDelegate tencentDidNotLogin:YES];
        }
    } failure:^{
        if ([self.sessionDelegate respondsToSelector:@selector(tencentDidNotLogin:)]) {
            [self.sessionDelegate tencentDidNotLogin:NO];
        }
    }];
    return YES;
}
+ (BOOL)MCTencentOAuthByWeb{
    if ([HDTencentOAuth iphoneQQInstalled]) {
        //
        if ([HDTencentOAuth iphoneQQSupportSSOLogin]) {
            return YES;
            
        }
    }
    if ([HDTencentOAuth iphoneQZoneInstalled]) {
        //
        if ([HDTencentOAuth iphoneQZoneSupportSSOLogin]) {
            return YES;
            
        }
    }
    return NO;
}
@end
