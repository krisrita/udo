//
//  HDShareData.h
//
//
//  Created by nobody on 14-1-6.
//  All rights reserved.
//

/**
 *  分享平台类型
 */
typedef enum {
    /** 微信朋友圈分享 */
    HD_SHARE_TYPE_WXTIMELINE,
    /** 微信好友分享 */
    HD_SHARE_TYPE_WXSESSION,
    /** QQ空间分享 */
    HD_SHARE_TYPE_QZONE,
    /** QQ好友 */
    HD_SHARE_TYPE_QQ_FRIEND,
} HDShareType;

typedef void (^HDShareBackBlock)(HDCommonResult *result);

#import <Foundation/Foundation.h>

#import "HDSNSDefine.h"


/**
 *  第三方平台分享类
 */
@interface HDShareData : NSObject

/**
 *  分享单例
 *
 *  @return 返回单例
 */
+ (instancetype)sharedInstance;


/**
 *  直接调用此方法分享 返回结果在competion中
 *
 *  @param shareType  分享类型
 *  @param shareType  分享标题
 *  @param shareText  文字
 *  @param shareImage 图片
 *  @param shareImageUrl 图片地址
 *  @param shareUrl   链接
 *  @param viewcontroller （必须在放在navigationcontroller中）分享环境上下文
 *  @param completion 分享结果
 */
- (void)share:(HDShareType)shareType
       tittle:(NSString *)shareTittle
         test:(NSString *)shareText
        image:(UIImage *)shareImage
     imageUrl:(NSString *)shareImageUrl
  resourceUrl:(NSString *)shareUrl
parentcontroller:(UIViewController *)viewController
   completion:(HDShareBackBlock)completion;

@end
