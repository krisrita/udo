
#import <Foundation/Foundation.h>
#import <TencentOpenAPI/TencentOAuthObject.h>
#import "TencentOpenAPI/QQApi.h"
#import "TencentOpenAPI/QQApiInterface.h"
#import "HDTencentOAuth.h"
#import "HDShareData.h"

@interface HDQQAuthor : NSObject<TencentSessionDelegate, TCAPIRequestDelegate>

+ (instancetype)sharedInstance;

-(BOOL)snsQQHandleOpenUrl:(NSURL *)url;


-(void)shareToQQType:(HDShareType)type
               Title:(NSString *)title;

-(void)shareToQQType:(HDShareType)type
               Title:(NSString *)title
          shareImgUrl:(NSString *)imgUrlStr
             shareUrl:(NSString *)shareUrlStr
             Complete:(HDShareBackBlock)block;

-(BOOL)canShareToQQ;

@end
