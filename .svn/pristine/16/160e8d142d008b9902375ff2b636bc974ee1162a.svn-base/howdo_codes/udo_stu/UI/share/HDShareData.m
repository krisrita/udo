//
//  HDShareData.m
//
//
//  Created by nobody on 14-1-6.
//  All rights reserved.
//
typedef void (^MCGetImgBlock)(HDResultCode code,UIImage * img);

#import "HDShareData.h"
#import "AFNetworking/AFURLResponseSerialization.h"
#import "HDWeiXinShare.h"
#import "HDQQAuthor.h"
#import "WXApi.h"

@interface HDShareData ()

@property (nonatomic,copy) MCShareBackBlock shareBlock;

@end

@implementation HDShareData

+(instancetype)sharedInstance
{
    static HDShareData * shareInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        shareInstance = [[self alloc] init];
    });
    return shareInstance;
}


-(void)share:(HDShareType)shareType
      tittle:(NSString *)shareTittle
        test:(NSString *)shareText
       image:(UIImage *)shareImage
    imageUrl:(NSString *)shareImageUrl
 resourceUrl:(NSString *)shareUrl
parentcontroller:(UIViewController *)viewController
  completion:(MCShareBackBlock)completion
{
    self.shareBlock = completion;
    switch (shareType)
    {
            
        case HD_SHARE_TYPE_WXSESSION:
        {
            [[HDWeiXinShare sharedInstance] weiXinShareToWXSessionTitle:shareTittle imageUrlStr:shareImageUrl shareUrlStr:shareUrl Complete:^(HDCommonResult *result) {
                
            }];
        }
        break;
            
        case HD_SHARE_TYPE_WXTIMELINE:
        {
            [[HDWeiXinShare sharedInstance] weiXinShareToWXTimeLineTitle:shareTittle imageUrlStr:shareImageUrl shareUrlStr:shareUrl Complete:^(HDCommonResult *result) {
                
            }];
        }
        break;
            
        case HD_SHARE_TYPE_QZONE:
        case HD_SHARE_TYPE_QQ_FRIEND:
        {
            [[HDQQAuthor sharedInstance]shareToQQType:shareType Title:shareTittle shareImgUrl:shareImageUrl shareUrl:shareUrl Complete:^(HDCommonResult *result) {
                
            }];
        }
        break;
    
        default:
        break;
    }
}

-(void)getShareImgUrlStr:(NSString *)imgUrl complete:(MCGetImgBlock)block
{
    if (imgUrl)
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSURL * url = [NSURL URLWithString:imgUrl];
            NSData * data = [[NSData alloc]initWithContentsOfURL:url];
            UIImage *image = [[UIImage alloc]initWithData:data];
            if (data != nil)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (block) {
                        block (HD_RESULT_CODE_SUCCESS,image);
                    }
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (block) {
                        block (HD_RESULT_CODE_FAILURE,nil);
                    }
                });
            }
        });
    }
    else
    {
        if (block) {
            block (HD_RESULT_CODE_FAILURE,nil);
        }
    }
}


@end
