//
//  HDSNSDefine.h
//  udo_stu
//
//  Created by nobody on 15-5-31.
//  All rights reserved.
//

#ifndef udo_stu_HDSNSDefine_h
#define udo_stu_HDSNSDefine_h

#import "HDQQAuthor.h"
#import "HDShareData.h"

#define WEIXINAppID @"wx989637ef5296a4e8"
#define WEIXINAppSecret @"0a959dde12c6cc57a2b713a79a3496ec"

#define QQAPPID @"1104628591"
#define QQAPPKEY @"OGUEcmEJfrwg45jo"


#endif
