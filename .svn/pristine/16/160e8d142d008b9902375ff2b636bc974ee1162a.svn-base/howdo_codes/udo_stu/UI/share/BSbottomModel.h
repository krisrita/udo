//
//  BSbottomModel.h
//  
//
//  Created by nobody on 13-7-19.
//  All rights reserved.
//


typedef void (^MCShareViewPoped)(void);
typedef void (^MCShareViewDismissed)(void);

#import <Foundation/Foundation.h>
extern NSString *const KGBottomModalGradientViewTapped;

NS_ENUM(NSUInteger, BSModalBackgroundDisplayStyle)
{
    BSModalBackgroundDisplayStyleGradient,
    BSModalBackgroundDisplayStyleSolid
};

@interface BSbottomModel : NSObject

// Determines if the modal should dismiss if the user taps outside of the modal view
// Defaults to YES
@property (nonatomic) BOOL tapOutsideToDismiss;

// Determins if the close button or tapping outside the modal should animate the dismissal
// Defaults to YES
@property (nonatomic) BOOL animateWhenDismissed;

// Determins if the close button is shown
// Defaults to YES
@property (nonatomic) BOOL showCloseButton;

// The background display style, can be a transparent radial gradient or a transparent black
// Defaults to gradient, this looks better but takes a bit more time to display on the retina iPad
@property (nonatomic) enum BSModalBackgroundDisplayStyle backgroundDisplayStyle;

@property (nonatomic,readonly)BOOL isPop_up;

@property (strong, nonatomic) UIWindow *window;

// The shared instance of the modal
+ (id)sharedInstance;

// Set the content view to display in the modal and display with animations
- (void)showWithContentView:(UIView *)contentView;

// Set the content view to display in the modal and whether the modal should animate in
- (void)showWithContentView:(UIView *)contentView andAnimated:(BOOL)animated showBlock:(MCShareViewPoped)popBlock dismissBlock:(MCShareViewDismissed)dismissBlock;

// Hide the modal with animations
- (void)hide;

// Hide the modal and whether the modal should animate away
- (void)hideAnimated:(BOOL)animated dismissBlock:(MCShareViewDismissed)dismissBlock;
- (void)showNewViewAndhideAnimated:(BOOL)animated dismissBlock:(MCShareViewDismissed)dismissBlock;

@end