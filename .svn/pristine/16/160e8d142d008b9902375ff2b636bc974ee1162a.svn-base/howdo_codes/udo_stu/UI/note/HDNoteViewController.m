//
//  HDNoteViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/6.
//  All rights reserved.
//

#import "HDNoteViewController.h"
#import "RFQuiltLayout.h"
#import "HDNoteCollectinViewCell.h"
#import "HDNoteHeadView.h"
#import "MWPhotoBrowser.h"
#import "MLNavigationController.h"
#define ImageHight ((APP_CONTENT_WIDTH - 75) / (4) + 10)

@interface HDNoteViewController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,MWPhotoBrowserDelegate>


@property (nonatomic ,strong)UICollectionView *collectionView;
@property (nonatomic,strong)NSArray *noteArray;
@end

@implementation HDNoteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.leftView = [HDUICommon leftBackView:self];
    self.centerView = [HDUICommon getTitleView:@"笔记"];
   
    UICollectionViewFlowLayout  *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    flowLayout.sectionInset = UIEdgeInsetsMake(20, 20, 10, 20);
    flowLayout.minimumInteritemSpacing = 10;
    flowLayout.minimumLineSpacing = 10;
    
    _collectionView =[[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) collectionViewLayout:flowLayout];
    [_collectionView registerClass:[HDNoteCollectinViewCell class] forCellWithReuseIdentifier:NSStringFromClass([HDNoteCollectinViewCell class])];
    [self.collectionView registerClass:[HDNoteHeadView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:NSStringFromClass([HDNoteHeadView class])];

    [_collectionView setBackgroundColor:[UIColor clearColor]];
    [_collectionView setUserInteractionEnabled:YES];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [self.view addSubview:_collectionView];
    [self.view bringSubviewToFront:self.headView];

    // Do any additional setup after loading the view.
    [self requestData];
}
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    self.collectionView.contentInset = UIEdgeInsetsMake(CGRectGetMaxY(self.headView.frame), 0, 0, 0);
}
- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)requestData
{
    WS(ws);
    [[HDManager sharedInstance].courseService getNoteList:self.sectionModel.Id resultBack:^(HDServiceResult *result, NSArray *items) {
        switch (result.resultCode) {
            case HD_RESULT_CODE_SUCCESS:
            case HD_RESULT_CODE_EMPTY: {
                ws.noteArray = items;
                [ws.collectionView reloadData];
                break;
            }
            case HD_RESULT_CODE_FAILURE: {
                
                break;
            }
            case HD_RESULT_CODE_NETWORK_FAILURE: {
                
                break;
            }
            default: {
                break;
            }
        }
    }];
}
#pragma - mark collectview代理

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.noteArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)acollectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HDNoteCollectinViewCell *  cell = [acollectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([HDNoteCollectinViewCell class]) forIndexPath:indexPath];
    cell.noteModel = self.noteArray[indexPath.item];
    cell.numString = [NSString stringWithFormat:@"%@/%@",conversionstring(indexPath.item+1),conversionstring(self.noteArray.count)];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    HDLogInfo(@"didSelectItemAtIndexPathdidSelectItemAtIndexPath");
    HDNoteModel *model = self.noteArray[indexPath.item];;
    BOOL displayActionButton = NO;
    BOOL displaySelectionButtons = NO;
    BOOL displayNavArrows = NO;
    BOOL enableGrid = NO;
    BOOL startOnGrid = NO;
    NSMutableArray *photos = [[NSMutableArray alloc] init];
    for (int i=0; i<self.noteArray.count; i++) {
        [photos addObject:[MWPhoto photoWithURL:[NSURL URLWithString:model.imageUrl.medium]]];
    }
    
    MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
    browser.displayActionButton = displayActionButton;
    browser.displayNavArrows = displayNavArrows;
    browser.displaySelectionButtons = displaySelectionButtons;
    browser.alwaysShowControls = displaySelectionButtons;
    browser.zoomPhotosToFill = YES;
    browser.enableGrid = enableGrid;
    browser.startOnGrid = startOnGrid;
    browser.enableSwipeToDismiss = YES;
    [browser setCurrentPhotoIndex:indexPath.item];
    
    [self.navigationController pushViewController:browser animated:YES];
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((APP_CONTENT_WIDTH-60)/3, (APP_CONTENT_WIDTH-60)/3+30);
}
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    HDNoteHeadView *reuseView = nil;
    if (kind == UICollectionElementKindSectionHeader) {
        reuseView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:NSStringFromClass([HDNoteHeadView class]) forIndexPath:indexPath];
        switch (indexPath.section) {
            case 0:
            {
                [reuseView setOwn:YES withTitle:self.sectionModel.name num:conversionstring(self.noteArray.count)];

            }
                break;
            default:
                break;
        }
    }
    return reuseView;
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:
        {
            return CGSizeMake(APP_CONTENT_WIDTH, 40);
            
        }
            break;
        
        default:
            break;
    }
    return CGSizeMake(0, 0);
}
- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser
{
    return self.noteArray.count;
}
- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index
{
    HDNoteModel *model = self.noteArray[index];
    return [MWPhoto photoWithURL:[NSURL URLWithString:model.imageUrl.large]];
}
@end
