//
//  HDNoteViewController.h
//  udo_stu
//
//  Created by nobody on 15/6/6.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDNoteViewController : HDBaseViewController

@property (nonatomic,strong)HDSectionModel *sectionModel;

@end
