//
//  HDNoteCollectinViewCell.m
//  udo_stu
//
//  Created by nobody on 15/6/7.
//  All rights reserved.
//

#import "HDNoteCollectinViewCell.h"

@interface HDNoteCollectinViewCell ()

@property (nonatomic, strong) HDImageView *noteImageView;
@property (nonatomic,strong) UILabel *numLabel;

@end

@implementation HDNoteCollectinViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _noteImageView = [[HDImageView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height-30)];
        _noteImageView.userInteractionEnabled = YES;
        
        [self.contentView addSubview:_noteImageView];
        self.numLabel = [[UILabel alloc] init];
        self.numLabel.font = [UIFont systemFontOfSize:12];
        self.numLabel.textColor = UIColorFromRGB(34, 177, 139);
        [self.contentView addSubview:self.numLabel];
        [self setSubviewsLayout];
    }
    return self;
}

- (void)setNoteModel:(id)noteModel
{
    HDNoteModel *model = noteModel;
    [self.noteImageView setHDImageURL:[NSURL URLWithString:model.imageUrl.medium] placeholderImage:[[UIImage imageNamed:@"note_default"] resizableImageWithCapInsets:UIEdgeInsetsMake(15, 15, 15, 15)]imageType:HD_IMAGE_SQUARE];
}

-(void)setNumString:(NSString *)numString
{
   self.numLabel.text = numString;
}
-(void)setSubviewsLayout
{
    WS(ws);
    
    
    [self.numLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.noteImageView.mas_bottom).offset(10);
        make.centerX.equalTo(ws.noteImageView);
    }];
   
}
+(CGSize)dynamicSize:(id )model
{
    return CGSizeMake(100, 100);
}
@end
