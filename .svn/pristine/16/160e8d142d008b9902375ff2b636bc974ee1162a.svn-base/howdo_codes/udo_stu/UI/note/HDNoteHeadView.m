//
//  HDNoteHeadView.m
//  udo_stu
//
//  Created by nobody on 15/6/7.
//  All rights reserved.
//

#import "HDNoteHeadView.h"

@interface HDNoteHeadView ()

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *numLabel;
@property (nonatomic,strong)UIView *lineView;
@end

@implementation HDNoteHeadView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        self.backgroundColor = [UIColor clearColor];
        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.text = @"1.1数学集合";
        self.titleLabel.font = [UIFont systemFontOfSize:15];
        self.titleLabel.textColor = [UIColor blackColor];;
        [self addSubview:self.titleLabel];
        self.numLabel = [[UILabel alloc] init];

        self.numLabel.font = [UIFont systemFontOfSize:15];
        self.numLabel.textColor = UIColorFromRGB(34, 177, 139);
        [self addSubview:self.numLabel];
        self.lineView = [[UIView alloc]init];
        self.lineView.backgroundColor = UIColorFromRGB(34, 177, 139);
        [self addSubview:self.lineView];
    }
    return self;
}

- (void)setOwn:(BOOL)isOwn withTitle:(NSString *)title num:(NSString *)num
{
    WS(weakSelf);
    self.numLabel.text = num;
    self.titleLabel.text = title;
    
    [self.numLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.mas_right).offset(-30);
        make.centerY.equalTo(weakSelf);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.mas_left).offset(30);
        make.right.equalTo(weakSelf.numLabel.mas_left).offset(-20);
        make.centerY.equalTo(weakSelf);
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.with.right.equalTo(weakSelf);
        make.bottom.equalTo(weakSelf.mas_bottom).offset(-1);
        make.height.equalTo(@(3));
    }];
    [self.numLabel setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [self.numLabel setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
}

@end
