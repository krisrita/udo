//
//  HDNoteCollectinViewCell.h
//  udo_stu
//
//  Created by nobody on 15/6/7.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDNoteCollectinViewCell : UICollectionViewCell

@property (nonatomic,strong)id noteModel;
@property (nonatomic,copy)NSString *numString;
+(CGSize)dynamicSize:(id )model;

@end
