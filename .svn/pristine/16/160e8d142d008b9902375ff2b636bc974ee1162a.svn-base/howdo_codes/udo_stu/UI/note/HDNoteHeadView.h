//
//  HDNoteHeadView.h
//  udo_stu
//
//  Created by nobody on 15/6/7.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDNoteHeadView : UICollectionReusableView

- (void)setOwn:(BOOL)isOwn withTitle:(NSString *)title num:(NSString *)num;
@end
