//
//  HDLoading.h
//  udo_stu
//
//  Created by nobody on 6/15/15.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDLoading : NSObject

+ (void)startAnimating;
+ (void)startAnimating:(NSString *)info;
+ (void)stopAnimating;
+ (void)stopAnimatingWithSuccess:(NSString *)info;
+ (void)stopAnimatingWithFailure:(NSString *)info;
+ (void)stopAnimating:(NSString *)info;

+ (void)showError:(NSString *)error;

@end
