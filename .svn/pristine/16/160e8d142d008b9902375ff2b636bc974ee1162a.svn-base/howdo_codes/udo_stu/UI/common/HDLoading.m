//
//  HDLoading.m
//  udo_stu
//
//  Created by nobody on 6/15/15.
//  All rights reserved.
//

#import "HDLoading.h"

#define HD_LOADING_VIEW_TAG  100001
#define HD_LOADING_IMAGE_TAG 110001
#define HD_LOADING_LABEL_TAG 110002

@implementation HDLoading

+ (HDLoading*)sharedView {
    static dispatch_once_t once;
    static HDLoading *sharedView;
    dispatch_once(&once, ^ { sharedView = [[self alloc] init];});
    return sharedView;
}

+ (void)startAnimating
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[HDLoading sharedView] rotate];
        
    });
}

+ (void)startAnimating:(NSString *)info
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[HDLoading sharedView] rotate:info];
    });
}

- (void)rotate
{
    [self removeLoading];
    UIView *root = [[UIApplication sharedApplication] keyWindow];
    UIImageView *loadingView = [[UIImageView alloc] initWithFrame:CGRectMake(((APP_SCREEN_WIDTH)/2-20), (APP_SCREEN_HEIGHT - APP_STATUS_HEIGHT)/2-20, 40, 40)];
    [loadingView setImage:[UIImage imageNamed:@"ic_loading"]];
    [loadingView setTag:HD_LOADING_VIEW_TAG];
    [root addSubview:loadingView];
    [root bringSubviewToFront:loadingView];
    
    loadingView.hidden =NO;
    CABasicAnimation* rotationAnimation;
    rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat: M_PI * 2.0 ];///* full rotation*/ * rotations * duration ];
    rotationAnimation.duration = 1;
    rotationAnimation.cumulative = YES;
    rotationAnimation.repeatCount = CGFLOAT_MAX;
    [loadingView.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
}

- (void)rotate:(NSString *)info
{
    [self removeLoading];
    UIView *root = [[UIApplication sharedApplication] keyWindow];
    UIImageView *loadingView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 286/2, 222/2)];
    [loadingView setImage:[UIImage imageNamed:@"bg_loading"]];
    [loadingView setCenter:CGPointMake(APP_CONTENT_WIDTH/2, (APP_SCREEN_HEIGHT-APP_STATUS_HEIGHT)/2)];
    [loadingView setTag:HD_LOADING_VIEW_TAG];
    [root addSubview:loadingView];
    [root bringSubviewToFront:loadingView];
    
    UIImageView *loadingImage = [[UIImageView alloc] initWithFrame:CGRectMake((CGRectGetWidth(loadingView.frame)-(104/2))/2, (30/2), (104/2), (104/2))];
    [loadingImage setImage:[UIImage imageNamed:@"ic_loading"]];
    [loadingImage setTag:HD_LOADING_IMAGE_TAG];
    [loadingView addSubview:loadingImage];
    
    UILabel *infoLabel = [[UILabel alloc] initWithFrame:CGRectMake((5), CGRectGetMaxY(loadingImage.frame)+(30/2), CGRectGetWidth(loadingView.frame)-(10), (15))];
    [infoLabel setBackgroundColor:[UIColor clearColor]];
    [infoLabel setFont:[UIFont boldSystemFontOfSize:12]];
    [infoLabel setTextColor:UIColorFromRGB(255, 255, 255)];
    [infoLabel setTextAlignment:NSTextAlignmentCenter];
    [infoLabel setNumberOfLines:1];
    [infoLabel setText:info];
    [infoLabel setTag:HD_LOADING_LABEL_TAG];
    [loadingView addSubview:infoLabel];
    
    loadingView.hidden =NO;
    CABasicAnimation* rotationAnimation;
    rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat: M_PI * 2.0 ];///* full rotation*/ * rotations * duration ];
    rotationAnimation.duration = 1;
    rotationAnimation.cumulative = YES;
    rotationAnimation.repeatCount = CGFLOAT_MAX;
    [loadingImage.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
    
    [root setUserInteractionEnabled:NO];
}

+ (void)stopAnimating
{
    [[HDLoading sharedView] stopAnimating];
}

- (void)stopAnimating
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[HDLoading sharedView] removeLoading];
        UIView *root = [[UIApplication sharedApplication] keyWindow];
        [root setUserInteractionEnabled:YES];
    });
}
+ (void)stopAnimatingWithSuccess:(NSString *)info
{
    [[HDLoading sharedView]stopAnimating:info success:YES];
    
}

+ (void)stopAnimatingWithFailure:(NSString *)info
{
    [[HDLoading sharedView]stopAnimating:info success:NO];
}

- (void)stopAnimating:(NSString *)info success:(BOOL)success
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *root = [[UIApplication sharedApplication] keyWindow];
        UIView *loadingView = [root viewWithTag:HD_LOADING_VIEW_TAG];
        for (UIView *subView in [loadingView subviews]) {
            if (subView) {
                [subView.layer removeAllAnimations];
            }
        }
        
        UIImageView *loadingImage = (UIImageView *)[loadingView viewWithTag:HD_LOADING_IMAGE_TAG];
        if (loadingImage) {
            [loadingImage setImage:[UIImage imageNamed:success ? @"ic_success" : @"ic_failure"]];
        }
        
        UILabel *infoLabel = (UILabel *)[loadingView viewWithTag:HD_LOADING_LABEL_TAG];
        if (infoLabel) {
            [infoLabel setText:info];
        }
        
        [self performSelector:@selector(stopAnimating) withObject:nil afterDelay:0.7f];
    });
}

+ (void)stopAnimating:(NSString *)info
{
    [[HDLoading sharedView]stopAnimating:info];
}

- (void)stopAnimating:(NSString *)info
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *root = [[UIApplication sharedApplication] keyWindow];
        UIView *loadingView = [root viewWithTag:HD_LOADING_VIEW_TAG];
        for (UIView *subView in [loadingView subviews]) {
            if (subView) {
                [subView.layer removeAllAnimations];
            }
        }
        
        UIImageView *loadingImage = (UIImageView *)[loadingView viewWithTag:HD_LOADING_IMAGE_TAG];
        [loadingImage setImage:nil];
        
        UILabel *infoLabel = (UILabel *)[loadingView viewWithTag:HD_LOADING_LABEL_TAG];
        if (infoLabel) {
            [infoLabel setText:info];
        }
        
        [infoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(loadingView.mas_centerY);
            make.centerX.equalTo(loadingView.mas_centerX);
        }];
        
        [self performSelector:@selector(stopAnimating) withObject:nil afterDelay:1.0f];
    });

}

- (void)removeLoading
{
    UIView *root = [[UIApplication sharedApplication] keyWindow];
    UIImageView *loadingView = (UIImageView *)[root viewWithTag:HD_LOADING_VIEW_TAG];
    for (UIView *subView in [loadingView subviews]) {
        if (subView) {
            [subView.layer removeAllAnimations];
        }
    }
    loadingView.hidden = YES;
    [loadingView removeFromSuperview];
}

+ (void)showError:(NSString *)error {
    [self startAnimating:error];
    [self stopAnimating:error];
}

@end
