//
//  MCUICommon.m
//
//
//  Created by nobody on 14-2-21.
//  All rights reserved.
//

#import "HDUICommon.h"
#define KEY_WINDOW  [[UIApplication sharedApplication]keyWindow]

@implementation HDUICommon

+(UIView *)splitLine:(float)lineY
{
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(30, lineY, APP_CONTENT_WIDTH-30, .5)];
    return label;
}
+ (UIView *)getTitleView:(NSString *)titleString
{
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = titleString;
    titleLabel.font = [UIFont systemFontOfSize:18];
    [titleLabel sizeToFit];
    return titleLabel;
}

+ (UIView *)MenuView:(id )delegate
{
    UIButton *courseHeadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *courseHeadImage = [UIImage imageNamed:@"btn_menu_default"];
    //    UIImage *mukeBack_hight = [UIImage imageNamed:@"back_ highlight@2x"];

    courseHeadButton.frame = CGRectMake(0, 20, courseHeadImage.size.width, courseHeadImage.size.height);
    [courseHeadButton addTarget:delegate action:@selector(leftMenu:) forControlEvents:UIControlEventTouchUpInside];
    [courseHeadButton setImage:courseHeadImage forState:UIControlStateNormal];
    //    [courseHeadButton setImage:mukeBack_hight forState:UIControlStateHighlighted];
    return courseHeadButton;
}

+(UIView *)sectionSplitLine:(float)lineY
{
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, lineY, APP_CONTENT_WIDTH, .5)];
    label.backgroundColor = [UIColor colorWithRed:229/255.0f green:229/255.0f blue:229/255.0f alpha:229/255.0f];
    return label;
}

+ (UIView *)leftBackView:(id )delegate
{
    UIButton *courseHeadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *courseHeadImage = [UIImage imageNamed:@"btn_back"];

    courseHeadButton.frame = CGRectMake(0, 20,98/2,98/2);
    [courseHeadButton addTarget:delegate action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [courseHeadButton setImage:courseHeadImage forState:UIControlStateNormal];
    //    [courseHeadButton setImage:mukeBack_hight forState:UIControlStateHighlighted];
    return courseHeadButton;
}
//private method
+ (UIImage *)capture
{
    UIGraphicsBeginImageContextWithOptions(KEY_WINDOW.bounds.size, KEY_WINDOW.opaque, 0.0);
    [KEY_WINDOW.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage * img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
}
@end
