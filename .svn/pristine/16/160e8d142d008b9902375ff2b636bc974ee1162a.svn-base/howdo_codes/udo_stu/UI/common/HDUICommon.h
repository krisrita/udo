//
//  HDUICommon.h
//
//
//  Created by nobody on 14-2-21.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDUICommon : NSObject

+(UIView *)splitLine:(float)lineY;
+ (UIView *)MenuView:(id )delegate;
+(UIView *)sectionSplitLine:(float)lineY;
+(UIView *)leftBackView:(id )delegate;
+ (UIView *)getTitleView:(NSString *)titleString;

+(UIImage *)capture;
@end
