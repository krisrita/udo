//
//  HDMenuTopView.h
//  udo_stu
//
//  Created by nobody on 15/5/31.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDMenuTopView : UIView

- (void)reloadCurrentUser;
@end
