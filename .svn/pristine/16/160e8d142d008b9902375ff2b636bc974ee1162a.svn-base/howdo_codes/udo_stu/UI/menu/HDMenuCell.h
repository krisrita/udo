//
//  HDMenuCell.h
//  
//
//  Created by nobody on 14-2-21.
//  All rights reserved.
//


#import "HDMenuDataModel.h"

@interface HDMenuCell : UITableViewCell

@property (nonatomic,strong)HDMenuDataModel *cellData;

-(void)setCellData:(HDMenuDataModel *)menuData highlight:(BOOL)highlight;

@end
