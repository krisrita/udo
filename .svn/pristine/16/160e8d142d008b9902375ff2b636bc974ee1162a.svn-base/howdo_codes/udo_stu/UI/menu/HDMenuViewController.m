//
//  HDMenuViewController.m
//  udo_stu
//
//  Created by nobody on 15/5/31.
//  All rights reserved.
//

#import "HDMenuViewController.h"
#import "HDMenuTopView.h"
#import "HDMenuCell.h"
#import "HDSettingViewController.h"
#import "HDShareProxy.h"
#import "MLNavigationController.h"
#import "HDMainViewController.h"
#import "HDSchoolViewController.h"
@interface HDMenuViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSIndexPath *lastIndexPath;
}
@property (nonatomic,strong) PullTableView *tableview;
@property (nonatomic,strong)NSMutableArray *dataMutableArray;
@property (nonatomic,strong)MLNavigationController *mainViewController;
@property (nonatomic,strong)HDMenuTopView *menuTopView;

@end

@implementation HDMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self builtUI];
    [self builtData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginStatusChanged:)
                                                 name:NOTIFICATION_CURRENT_USER_INFO_CHANGE object:nil];
}

- (void)builtUI
{

    self.headView.hidden= YES;
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"menu_background_default"]];
    
    [self.view setTag:PPMenuViewTag];
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT)];
    [contentView setTag:PPScaleViewTag];
    [self.view addSubview:contentView];
    
    HDMenuTopView *menuTopView = [[HDMenuTopView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, 265)];
    self.menuTopView = menuTopView;
    [contentView addSubview:menuTopView];
    
    
    _tableview = [[PullTableView alloc]initWithFrame:CGRectMake(0, 265, APP_CONTENT_WIDTH,APP_CONTENT_HEIGHT) style:UITableViewStylePlain];
    _tableview.backgroundColor = [UIColor clearColor];
    _tableview.delegate = self;
    _tableview.dataSource = self;
    _tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableview.rowHeight = 43;
    
    [contentView addSubview:_tableview];
    
    UIButton *settingButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [settingButton setBackgroundImage:[UIImage imageNamed:@"setting_default"] forState:UIControlStateNormal];
    [settingButton addTarget:self action:@selector(settingButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:settingButton];
    
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [shareButton setBackgroundImage:[UIImage imageNamed:@"menu_share_default"] forState:UIControlStateNormal];
    [shareButton addTarget:self action:@selector(shareButtonClicked) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:shareButton];
    
    [settingButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(30);
        make.bottom.equalTo(self.view).offset(-35);
    }];
    [shareButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view).offset(-100);
        make.bottom.equalTo(self.view).offset(-35);
    }];
    
    if ([HDUpgrade sharedInstance].hasNewVersion) {
        UIImage *newIcon = [UIImage imageNamed:@"ic_new"];
        UIImageView *newIconView = [[UIImageView alloc] initWithImage:newIcon];
        [self.view addSubview:newIconView];
    
        [newIconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(settingButton.mas_right).offset(5);
            make.centerY.equalTo(settingButton.mas_centerY).offset(0);
        }];
    }
}

-(void)builtData
{
    lastIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    NSArray * imgs = [NSArray arrayWithObjects:
                      @"course_default",
                      nil];
    NSArray * highlightImgs = [NSArray arrayWithObjects:
                      @"course_highlight",
                      nil];
    NSArray * titles = [NSArray arrayWithObjects:
                        @"UDO课堂",
                        nil];
    
    _dataMutableArray = [NSMutableArray array];
    for (int i = 0; i< [imgs count]; i++)
    {
        HDMenuDataModel *model = [[HDMenuDataModel alloc]init];
        model.menuImgStr = [imgs objectAtIndex:i];
        model.menuTitle = [titles objectAtIndex:i];
        model.menuHighlightImgStr = highlightImgs[i];
        [_dataMutableArray addObject:model];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataMutableArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    HDMenuCell *cell = (HDMenuCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[HDMenuCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
    
    if (indexPath.row==lastIndexPath.row) {
        [cell setCellData:self.dataMutableArray[indexPath.row] highlight:YES];
    }else{
        [cell setCellData:self.dataMutableArray[indexPath.row] highlight:NO];

    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    HDMenuCell *lastMenuCell = (HDMenuCell *)[tableView cellForRowAtIndexPath:lastIndexPath];
    [lastMenuCell setCellData:self.dataMutableArray[lastIndexPath.row] highlight:NO];
    HDMenuCell *currentMenuCell = (HDMenuCell *)[tableView cellForRowAtIndexPath:indexPath];
    [currentMenuCell setCellData:self.dataMutableArray[indexPath.row] highlight:YES];
    lastIndexPath = indexPath;
    /**
     *  这里可以防止重复点击
     */
    self.view.userInteractionEnabled = NO;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1* NSEC_PER_SEC), dispatch_get_main_queue(), ^(void) {
        self.view.userInteractionEnabled = YES;
    });
    MLNavigationController *rootNav = (MLNavigationController *)self.revealSideViewController.rootViewController;
    if ([rootNav.topViewController isKindOfClass:[HDSchoolViewController class]]) {
        self.mainViewController = rootNav;
    }
    [self.revealSideViewController popViewControllerWithNewCenterController:self.mainViewController animated:YES completion:^{
          }];
}

-(void)settingButtonClicked
{
    NSLog(@"settingButtonClicked");
    
    HDSettingViewController * setVc = [[HDSettingViewController alloc]init];
    MLNavigationController * nav = [[MLNavigationController alloc]initWithRootViewController:setVc];
    nav.hidesBottomBarWhenPushed = YES;
    nav.navigationBarHidden = YES;
    [self presentViewController:nav animated:YES completion:NULL];    
}

-(void)shareButtonClicked
{
    HDLogInfo(@"shareButtonClicked");
    
    [[HDShareProxy sharedInstance]share:self title:SHARE_TITLE text:SHARE_CONTENT imageUrl:SHARE_IMAGE_URL image:nil resourceUrl:[HDNetworkConfig getModuleUrl:URL_TYPE_SHARE] completion:^(HDCommonResult *result) {
        [HDTip showMessage:@"分享成功"];
    } viewPoped:nil viewDissMissed:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)loginStatusChanged:(NSNotification *)notification
{
    [self.menuTopView reloadCurrentUser];
}

@end
