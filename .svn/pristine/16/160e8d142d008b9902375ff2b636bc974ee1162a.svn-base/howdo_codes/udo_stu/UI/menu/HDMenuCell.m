//
//  HDMenuCell.m
//  
//
//  Created by nobody on 14-2-21.
//  All rights reserved.
//


#define TIP_VIEW_TAG 10000
#import <QuartzCore/QuartzCore.h>
#import "HDMenuCell.h"
#import "HDUICommon.h"

@interface HDMenuCell ()

@property (nonatomic,strong)UIImageView *markedImageView;
@property (nonatomic,strong)UILabel *nameLabel;

@end

@implementation HDMenuCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor clearColor];
        _markedImageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_markedImageView];
        _nameLabel = [[UILabel alloc]init];
        _nameLabel.textColor = [UIColor whiteColor];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont boldSystemFontOfSize:14.];
        [self.contentView addSubview:_nameLabel];
//       self.selectionStyle = UITableViewCellSelectionStyleNone;
        UIView *selectedView = [[UIView alloc]init];
        selectedView.backgroundColor = UIColorFromRGB(57, 58, 118);
        self.selectedBackgroundView = selectedView;
        
        [self builtUI];
    }
    return self;
}


-(void)setCellData:(HDMenuDataModel *)menuData highlight:(BOOL)highlight
{
    
    /**
     *  下面对数据的操作
     *
     *  @param void <#void description#>
     *
     *  @return <#return value description#>
     */
    if (highlight) {
        _markedImageView.image = [UIImage imageNamed:menuData.menuHighlightImgStr];
        _nameLabel.text = menuData.menuTitle;
        _nameLabel.textColor = UIColorFromRGB(26, 188, 156);

    }else{
        _markedImageView.image = [UIImage imageNamed:menuData.menuImgStr];
        _nameLabel.text = menuData.menuTitle;
        _nameLabel.textColor = [UIColor whiteColor];

    }
   
    
        
}

- (void)builtUI
{
    [_markedImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(30);
        make.centerY.equalTo(self.contentView.mas_centerY);
    }];
    [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.markedImageView.mas_right).offset(45);
        make.centerY.equalTo(self.contentView.mas_centerY);
    }];
}

+(float)fixedHeight
{
    return 50;
}
-(void)setSelected:(BOOL)selected
{
    NSLog(@"setSelected");
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
