//
//  HDMenuViewController.h
//  udo_stu
//
//  Created by nobody on 15/5/31.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDMenuViewController : HDBaseViewController

@end
