//
//  HDMenuTopView.m
//  udo_stu
//
//  Created by nobody on 15/5/31.
//  All rights reserved.
//

#import "HDMenuTopView.h"
#import "HDPersonCenterViewController.h"
#import "MLNavigationController.h"

@interface HDMenuTopView ()

@property (nonatomic,strong)HDImageView *headImageView;
@property (nonatomic,strong)UILabel *userNameLabel;
@property (nonatomic,strong)UILabel *introLabel;
@end

@implementation HDMenuTopView


-(instancetype)init{
    if (self = [super init]) {
        self.backgroundColor = [UIColor clearColor];
        [self builtUI];
    }
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];

        [self builtUI];
    }
    return self;
}

-(void)showUserCenter
{
    HDPersonCenterViewController * user = [[HDPersonCenterViewController alloc]init];

    MLNavigationController * nav = [[MLNavigationController alloc]initWithRootViewController:user];
    nav.hidesBottomBarWhenPushed = YES;
    nav.navigationBarHidden = YES;
    for (UIView* next = [self superview]; next; next = next.superview)
    {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]])
        {
            UIViewController * controller = (UIViewController *)nextResponder;
            [controller presentViewController:nav animated:YES completion:NULL];
            break;
        }
    }
}


- (void)builtUI
{    
    HDImageView *imageView = [[HDImageView alloc]init];
    [imageView addTarget:self action:@selector(showUserCenter)];
    self.headImageView = imageView;
    [self addSubview:imageView];
    self.userInteractionEnabled = YES;
    UILabel *userNameLabel = [[UILabel alloc]init];
    userNameLabel.font = [UIFont boldSystemFontOfSize:15];
    userNameLabel.textColor = [UIColor whiteColor];
    userNameLabel.textAlignment = NSTextAlignmentLeft;
    self.userNameLabel = userNameLabel;
    [self addSubview:userNameLabel];
    
    UIView *fontLinew = [[UIView alloc]init];
    fontLinew.backgroundColor = UIColorFromRGB(26, 17, 49);
    [self addSubview:fontLinew];
    
    UIImageView *introImageView = [[UIImageView alloc]init];
    introImageView.image = [UIImage imageNamed:@"intro_default"];
    [self addSubview:introImageView];
    
    UILabel *introLabel = [[UILabel alloc]init];
    introLabel.font = [UIFont systemFontOfSize:12];
    introLabel.textColor = [UIColor whiteColor];
    introLabel.textAlignment = NSTextAlignmentLeft;
    self.introLabel = introLabel;
    [self addSubview:introLabel];
    
    UIView *bottomLinew = [[UIView alloc]init];
    bottomLinew.backgroundColor = UIColorFromRGB(26, 17, 49);
    [self addSubview:bottomLinew];
    
    [self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(66);
        make.left.equalTo(self.mas_left).offset(30);
        make.size.mas_equalTo(CGSizeMake(90, 90));
    }];
    
    [self.userNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headImageView.mas_bottom).offset(15);
        make.left.equalTo(self.mas_left).offset(32.5);
    }];
    [fontLinew mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(30);
        make.bottom.equalTo(self).offset(-20-28);
        make.size.mas_equalTo(CGSizeMake(APP_CONTENT_WIDTH, 1));
    }];
    [introImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(fontLinew.mas_bottom).offset(5);
        make.left.equalTo(self.mas_left).offset(30);
        make.size.mas_equalTo(CGSizeMake(introImageView.image.size.width, introImageView.image.size.height));
    }];
    [bottomLinew mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(30);
        make.bottom.equalTo(self).offset(-20);
        make.size.mas_equalTo(CGSizeMake(APP_CONTENT_WIDTH, 1));
    }];
    [self.introLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(fontLinew.mas_top).offset(0);
        make.bottom.equalTo(bottomLinew.mas_top).offset(0);
        make.left.equalTo(introImageView.mas_right).offset(15);
    }];
    
    [self reloadCurrentUser];
}

- (void)reloadCurrentUser
{
    if ([HDManager sharedInstance].isLogined) {
        self.userNameLabel.text = [HDManager sharedInstance].currentUser.nickname;
        NSString *signature = [HDManager sharedInstance].currentUser.signature;
        self.introLabel.text = (signature && signature.length > 0) ? signature : @"这个人很懒，什么也没有写！";;
        [self.headImageView setHDImageURL:[NSURL URLWithString:[[HDManager sharedInstance].currentUser.imageUrl medium]]placeholderImage:[UIImage imageNamed:@"headImage_placeholder"] imageType:HD_IMAGE_CIRCLE];
    }
}

@end
