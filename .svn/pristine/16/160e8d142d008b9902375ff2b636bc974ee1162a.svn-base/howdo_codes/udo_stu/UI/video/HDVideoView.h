//
//  HDVideoView.h
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
@class HDVideoView;
@protocol HDVideoViewDelegate <NSObject>

@optional

-(void)videoView:(HDVideoView *)videoView play:(UIButton *)playButton;
-(void)videoView:(HDVideoView *)videoView up:(UIImageView *)upImageview;
-(void)videoView:(HDVideoView *)videoView down:(UIImageView *)downImageview;

@end
@interface HDVideoView : UIView

@property (nonatomic ,strong)UILabel *upLabel;
@property (nonatomic ,strong)UILabel *downLabel;
@property (nonatomic ,strong)UIImageView *upImageView;
@property (nonatomic ,strong)UIImageView *downImageView;
@property (nonatomic,weak)id<HDVideoViewDelegate> delegate;
@property (nonatomic,strong)HDSectionDetailModel *detailModel;
@end
