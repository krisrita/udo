//
//  HDVideoView.m
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDVideoView.h"

@interface HDVideoView ()

@property (nonatomic,strong)HDImageView *backgroundImageView;
@property (nonatomic,strong)HDImageView *headImageView;
@property (nonatomic,strong)UIButton *playButton;
@property (nonatomic,strong)UIView *infoBackgroundView;

@property (nonatomic,strong)UILabel *nicknameLabel;
@property (nonatomic,strong)UILabel *timeLabel;
@property (nonatomic,strong)UILabel *playTimeLabel;



@property(nonatomic,strong)UILabel *commentLabel;
@property(nonatomic,strong)UIView *lineView;

@end

@implementation HDVideoView
-(instancetype)init
{
    if (self =[super init]) {
        [self bulitUI];
    }
    
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self bulitUI];
    }
    return self;
}
- (void)bulitUI
{
    _backgroundImageView = [[HDImageView alloc]init];
    
    [self addSubview:_backgroundImageView];
    _headImageView = [[HDImageView alloc]init];
    [self addSubview:_headImageView];
    
    
    UIView *infoBackgroundView = [[UIView alloc]init];
    self.infoBackgroundView = infoBackgroundView;
    infoBackgroundView.backgroundColor = UIColorFromRGB(34, 177, 139);
    [self addSubview:infoBackgroundView];
    
    _nicknameLabel = [[UILabel alloc]init];
    _nicknameLabel.font = [UIFont systemFontOfSize:15];;
    _nicknameLabel.backgroundColor = [UIColor clearColor];
    _nicknameLabel.textColor = [UIColor whiteColor];
    [infoBackgroundView addSubview:_nicknameLabel];
    
    _timeLabel = [[UILabel alloc]init];
    _timeLabel.font = [UIFont systemFontOfSize:15];;
    _timeLabel.backgroundColor = [UIColor clearColor];
    _timeLabel.textColor = [UIColor whiteColor];

    [infoBackgroundView addSubview:_timeLabel];
    
    _playTimeLabel = [[UILabel alloc]init];
    _playTimeLabel.font = [UIFont systemFontOfSize:15];;
    _playTimeLabel.backgroundColor = [UIColor clearColor];
    _playTimeLabel.textColor = [UIColor whiteColor];

    [infoBackgroundView addSubview:_playTimeLabel];

    
    UIImage *upImage = [UIImage imageNamed:@"comment_up"];
    UIImageView *upImageView = [[UIImageView alloc]initWithImage:upImage];
    upImageView.userInteractionEnabled = YES;
    self.upImageView =upImageView;
    [infoBackgroundView addSubview:upImageView];
    WS(ws);
    [self.upImageView bk_whenTapped:^{
        if ([ws.delegate respondsToSelector:@selector(videoView:up:)]) {
            [ws.delegate videoView:ws up:ws.upImageView];
        }
    }];
    
    _upLabel = [[UILabel alloc]init];
    _upLabel.font = [UIFont systemFontOfSize:15];;
    _upLabel.backgroundColor = [UIColor clearColor];
    _upLabel.textColor = [UIColor whiteColor];

    [infoBackgroundView addSubview:_upLabel];
    
    UIImage *downImage = [UIImage imageNamed:@"comment_down"];
    UIImageView *downImageView = [[UIImageView alloc]initWithImage:downImage];
    self.downImageView = downImageView;
    self.downImageView.userInteractionEnabled = YES;
    [infoBackgroundView addSubview:downImageView];
    
    [self.downImageView bk_whenTapped:^{
        if ([ws.delegate respondsToSelector:@selector(videoView:down:)]) {
            [ws.delegate videoView:ws down:ws.downImageView];
        }
    }];
    
    _downLabel = [[UILabel alloc]init];
    _downLabel.font = [UIFont systemFontOfSize:15];;
    _downLabel.backgroundColor = [UIColor clearColor];
    _downLabel.textColor = [UIColor whiteColor];

    [infoBackgroundView addSubview:_downLabel];
    
    
    
    UIButton *playButton =[UIButton buttonWithType:UIButtonTypeCustom];
    [playButton setImage:[UIImage imageNamed:@"play_default"] forState:UIControlStateNormal];
    [playButton addTarget:self action:@selector(playButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.playButton = playButton;
    [self addSubview:playButton];
    
    _commentLabel = [[UILabel alloc]init];
    _commentLabel.font = [UIFont systemFontOfSize:15];;
    _commentLabel.backgroundColor = [UIColor clearColor];
    _commentLabel.text = @"评论";
    [self addSubview:_commentLabel];
    
    _lineView = [[UIView alloc]init];
    _lineView.backgroundColor =UIColorFromRGB(34, 177, 139);
    [self addSubview:_lineView];
    
    [self setSubviewsLayout];
}
- (void)setDetailModel:(HDSectionDetailModel *)detailModel
{
     _detailModel = detailModel;
    
    [self.backgroundImageView setHDImageURL:[NSURL URLWithString:[_detailModel.imageUrl medium]] placeholderImage:[[UIImage imageNamed:@"video_placeholder"] resizableImageWithCapInsets:UIEdgeInsetsMake(15, 15, 15, 15)] imageType:HD_IMAGE_SQUARE];
//    NSString *urlStr = @"http://7sbqhl.com2.z0.glb.qiniucdn.com/avatar/6cbe1cb2e1fd082fa6041c0be1fe6df8.png";
    NSString *urlStr = [_detailModel.teacher.imageUrl small];
    [self.headImageView setHDImageURL:[NSURL URLWithString:urlStr] placeholderImage:[UIImage imageNamed:@"headImage_placeholder"] imageType:HD_IMAGE_CIRCLE];
    self.nicknameLabel.text = _detailModel.teacher.name;
    self.timeLabel.text = [_detailModel.duration ENAUTOHHMMSS];
    self.playTimeLabel.text = [NSString stringWithFormat:@"播放：%@",conversionstring(_detailModel.watchedNum)];
    self.upLabel.text = conversionstring(_detailModel.likedNum);
    self.downLabel.text = conversionstring(_detailModel.dislikedNum);
    
    [self setSubviewsLayout];
}
-(void)setSubviewsLayout
{
    WS(ws);
    [self.backgroundImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.with.right.with.top.equalTo(ws);
        make.height.equalTo(@(195));
    }];
    [self.infoBackgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.backgroundImageView);
        make.left.with.right.equalTo(ws.backgroundImageView);
        make.height.equalTo(@(30));
    }];
    [self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws).offset(15);
        make.bottom.equalTo(ws).offset(-70);
        make.height.equalTo(@(50));
        make.width.equalTo(@(50));
    }];
    [self.nicknameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.infoBackgroundView);
        make.left.equalTo(ws.infoBackgroundView).offset(15);
    }];
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.infoBackgroundView);
        make.left.equalTo(ws.nicknameLabel.mas_right).offset(20);
    }];
    [self.playTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.infoBackgroundView);
        make.left.equalTo(ws.timeLabel.mas_right).offset(20);
    }];
    [self.upImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.upLabel.mas_left).offset(-10);
        make.centerY.equalTo(ws.infoBackgroundView);
        
    }];
    [self.upLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.downImageView.mas_left).offset(-(APP_CONTENT_WIDTH>320?30:15));
        make.centerY.equalTo(ws.infoBackgroundView);
        
    }];
    [self.downImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.downLabel.mas_left).offset(-10);
        make.centerY.equalTo(ws.infoBackgroundView);
    }];
    [self.downLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.infoBackgroundView);
        make.right.equalTo(ws.mas_right).offset(-15);
        
    }];
    [self.playButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(ws.backgroundImageView);
    }];
    [self.commentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws).offset(20);
        make.centerY.equalTo(ws.backgroundImageView.mas_bottom).offset(15);
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.with.right.equalTo(ws);
        make.bottom.equalTo(ws);
        make.height.equalTo(@(0.5));
    }];
}
- (void)playButtonClicked:(UIButton*)sender
{
    if ([self.delegate respondsToSelector:@selector(videoView:play:)]) {
        [self.delegate videoView:self play:sender];
    }
}
@end
