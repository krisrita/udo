//
//  HDVideoWebViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDVideoWebViewController.h"

@interface HDVideoWebViewController ()<UIWebViewDelegate>

@end

@implementation HDVideoWebViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [UIApplication sharedApplication].statusBarHidden = YES;

    // Do any additional setup after loading the view.
    UIWebView *webView = [[UIWebView alloc] init];
    [webView setFrame:CGRectMake(0,0,APP_SCREEN_WIDTH,APP_SCREEN_HEIGHT)];
    [webView setDelegate:self];
    [self.view addSubview:webView];
    webView.scrollView.scrollEnabled = NO;
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlString]]];
//    self.leftView = [HDUICommon leftBackView:self];
//    [self.view bringSubviewToFront:self.headView];
    self.headView.hidden = YES;
    UIButton *courseHeadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *courseHeadImage = [UIImage imageNamed:@"btn_back"];
    
    courseHeadButton.frame = CGRectMake(APP_CONTENT_WIDTH - 49+5, 20,98/2,98/2);
    [courseHeadButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [courseHeadButton setImage:courseHeadImage forState:UIControlStateNormal];
    courseHeadButton.transform = CGAffineTransformMakeRotation(M_PI_2);
    [self.view addSubview:courseHeadButton];
}

- (void)back:(UIButton *)sender
{
    [UIApplication sharedApplication].statusBarHidden = NO;

    [self.navigationController popViewControllerAnimated:self.animation];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = NO;
}

- (void)viewWillDisappear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = YES;
}

-(void) webViewDidFinishLoad:(UIWebView *)webView { 
}

@end
