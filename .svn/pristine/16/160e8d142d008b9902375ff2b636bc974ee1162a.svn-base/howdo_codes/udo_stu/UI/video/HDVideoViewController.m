//
//  HDVideoViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDVideoViewController.h"
#import "HDCommentCell.h"
#import "HDCommentDetailBottom.h"
#import "HDVideoView.h"
#import "HDVideoWebViewController.h"
#import "HDShareProxy.h"
#import "HDMainBlankPageView.h"
#define bottomViewHeight 50

@interface HDVideoViewController ()<HDTableViewDelegate,HDTableViewCellDelegate,CommentBottomDelegate,HDVideoViewDelegate>
{
    NSIndexPath *currentIndexPath;
    CGFloat _lastPosition;
    NSInteger _lastDirection;
}

/// 评论tableView
@property (nonatomic,strong)HDTableView *hdTableView;
/// 视频图片和讲师头像
@property (nonatomic,strong)HDVideoView *videoView;
@property (nonatomic, strong) HDCommentDetailBottom *bottomView;

/// 课程id，如果一开是0.说明是从试卷详情页面push过来的
@property (nonatomic, assign) NSInteger courseId;
@end

@implementation HDVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.courseId = [self getCourseId];
    // Do any additional setup after loading the view.
    self.leftView = [HDUICommon leftBackView:self];
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:[UIImage imageNamed:@"btn_share_default"] forState:0];
    [rightButton setFrame:CGRectMake(0, 0, 44, 44)];
    [rightButton addTarget:self action:@selector(rightViewClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.rightView = rightButton;
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self initLoadView];
    [self buildBottomView];
    [self.view bringSubviewToFront:self.headView];
    
    self.centerView = [HDUICommon getTitleView:[self getChapterOrSectionName]];
    [self requestSectionDetail]; //请求节信息
    [self requestData:0]; // 请求评论信息
}

- (void)initLoadView
{
    HDVideoView *videoView = [[HDVideoView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.headView.frame), APP_CONTENT_WIDTH, 225)];
    videoView.delegate = self;
    self.videoView = videoView;
    [self.view addSubview:videoView];
    HDTableView *hdTableView = [[HDTableView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT) rowHeightType:HD_CELL_HEIGHT_TYPE_DYNAMIC cellClassName:[HDCommentCell class] blankViewClass:[HDMainBlankPageView class] refreshType:HD_TABLE_REFRESH_UPDOWN];
    self.hdTableView = hdTableView;
    hdTableView.hdTableViewDelegate = self;
    [self.view addSubview:self.hdTableView];
    
    [self.view bringSubviewToFront:self.headView];
}

-(void)buildBottomView{
    _bottomView = [[HDCommentDetailBottom alloc]initWithFrame:CGRectMake(0, APP_CONTENT_HEIGHT-bottomViewHeight, APP_CONTENT_WIDTH, bottomViewHeight)];
    _bottomView.delegate = self;
    [self.view addSubview:_bottomView];
}
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    self.hdTableView.frame =  CGRectMake(0,CGRectGetMaxY(self.videoView.frame), APP_CONTENT_WIDTH,CGRectGetHeight(self.view.frame)-CGRectGetMaxY(self.videoView.frame)-bottomViewHeight);
    //    secionBlankPageView = [[MCSectionBlankPageView alloc]initWithFrame:self.tableview.frame];
}
- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}
- (void)rightViewClicked:(UIButton *)sender
{
    [[HDShareProxy sharedInstance]share:self title:SHARE_TITLE text:SHARE_CONTENT imageUrl:SHARE_IMAGE_URL image:nil resourceUrl:[HDNetworkConfig getModuleUrl:URL_TYPE_SHARE] completion:^(HDCommonResult *result) {
        [HDTip showMessage:@"分享成功"];
    } viewPoped:nil viewDissMissed:nil];
}

#pragma mark - 请求节信息
- (void)requestSectionDetail
{
    WS(ws);
    
    [[HDManager sharedInstance].courseService getSectionDetail:[self getChapterOrSectionId] videoId:[self getVideoId] resultBack:^(HDServiceResult *result, id object) {
        switch (result.resultCode) {
            case HD_RESULT_CODE_SUCCESS:{
                ws.videoView.detailModel = (HDSectionDetailModel *)object;
                
                // 请求评论数据，由于从试卷详情页面过来，没有couseid。无法获取评论数据。需先获取到视频信息之后再获取评论数据
                if (ws.courseId == 0) {
                    ws.courseId = [(HDSectionDetailModel *)object courseId];
                    [ws requestData:0];
                }
                
                break;
            }
            case HD_RESULT_CODE_FAILURE: {
                [self.hdTableView setTableDataWithAry:nil];
                [self.hdTableView setTableNetworkFailure];
                break;
            }
            case HD_RESULT_CODE_NETWORK_FAILURE: {
                [self.hdTableView setTableDataWithAry:nil];
                [self.hdTableView setTableNetworkFailure];
                break;
            }
            default: {
                break;
            }
        }
    }];
}

#pragma mark 请求评论信息
- (void)requestData:(NSInteger )lastCommentId
{
    if (self.courseId == 0) {
        return;
    }
    WS(ws);
    [[HDManager sharedInstance].courseService getCommentList:self.courseId videoId:[self getVideoId] lastCommentId:lastCommentId resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS) {
            
                if (lastCommentId==0) {
                    [ws.hdTableView setTableDataWithAry:object];
                }else{
                    [ws.hdTableView tableAppendDataWithAry:object];
                }
          
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (0 == lastCommentId) {
                self.hdTableView.HDTableIsRefreshing = NO;
            }else {
                self.hdTableView.HDTableIsLoadingMore = NO;
            }
        });
    }];
}

- (void)HDTableViewDidTriggerRefresh:(HDTableView*)pullTableView
{
    [self requestData:0];
}

- (void)HDTableViewDidTriggerLoadMore:(HDTableView*)pullTableView
{
    HDLogInfo(@"2342423424");
    HDCommentModel *model = [[self.hdTableView getTableDataAry] lastObject];
    
    [self requestData:model.Id];
    
}
- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag
{
    HDCommentCell *commentCell = cell;
    HDCommentModel *model = commentCell.cellData;
    switch (tag) {
        case UIVIEW_TAG+1:
        {
            [[HDManager sharedInstance].courseService reportComment:model.Id resultBack:^(HDServiceResult *result, id object) {
                switch (result.resultCode) {
                    case HD_RESULT_CODE_SUCCESS:
                    case HD_RESULT_CODE_EMPTY:{
                        
                        break;
                    }
                        
                    case HD_RESULT_CODE_FAILURE: {
                        
                        break;
                    }
                    case HD_RESULT_CODE_NETWORK_FAILURE: {
                        
                        break;
                    }
                    default: {
                        break;
                    }
                }
                [HDTip showMessage:@"举报成功"];
            }];
        }
            break;
        case UIVIEW_TAG+2:
        {
            NSIndexPath *indexPath = [self.hdTableView indexPathForCell:cell];
            currentIndexPath = indexPath;
            NSMutableArray *mutableArray = [self.hdTableView getTableDataAry];
            HDCommentModel *model = mutableArray[currentIndexPath.row];
            [self.bottomView editComment:[NSString stringWithFormat:@"回复%@:",model.sender.nickname]];
        }
            break;
        default:
            break;
    }
}
- (void)sendComment:(HDCommentTextInput *)textInput
{
    if ([textInput.textView.text isEqualToString:@""]) {
        [HDTip showMessage:@"评论不能为空"];
        return;
    }
    NSInteger sectionId = 0;
    NSInteger replyCommentId = 0;
    if (currentIndexPath) {
        NSMutableArray *mutableArray = [self.hdTableView getTableDataAry];
        HDCommentModel *model = mutableArray[currentIndexPath.row];
        sectionId = model.section.Id;
        replyCommentId = model.Id;
    }
    [[HDManager sharedInstance].courseService sendComment:textInput.textView.text courseId:self.courseId videoId:[self getVideoId] replyCommentId:replyCommentId resultBack:^(HDServiceResult *result, id object) {
        switch (result.resultCode) {
            case HD_RESULT_CODE_SUCCESS:
            case HD_RESULT_CODE_EMPTY:{
                textInput.textView.text = @"";
                [self.bottomView setPlaceHolderText:@""];
                currentIndexPath = nil;

                NSMutableArray *mutableArray = [[self.hdTableView getTableDataAry] mutableCopy];
                [mutableArray insertObject:object atIndex:0];
                [self.hdTableView setTableDataWithAry:mutableArray];
                break;
            }
            case HD_RESULT_CODE_FAILURE: {
                
                break;
            }
            case HD_RESULT_CODE_NETWORK_FAILURE: {
                
                break;
            }
            default: {
                break;
            }
        }
    }];
    [textInput.textView resignFirstResponder];

}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSInteger direction = 0;
    CGFloat currentPostion = scrollView.contentOffset.y;
    if (currentPostion - _lastPosition > 25) {
        _lastPosition = currentPostion;
        direction = 1;
    }
    else if (_lastPosition - currentPostion > 25)
    {
        _lastPosition = currentPostion;
        direction = 2;
    }
    
    if (direction > 0 && direction != _lastDirection) {
        if ([self.bottomView.input.textView isFirstResponder]) {
            [self.bottomView.input.textView resignFirstResponder];
            [self.bottomView setPlaceHolderText:@""];
            currentIndexPath = nil;
        }
        _lastDirection = direction;
    }
}
-(void)HDTableViewDidSelected:(id)data didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.bottomView.input.textView isFirstResponder]) {
        [self.bottomView.input.textView resignFirstResponder];
        [self.bottomView setPlaceHolderText:@""];
        currentIndexPath = nil;
    }else{
        HDLogInfo(@"didSelectRowAtIndexPath");
    }
}
-(void)videoView:(HDVideoView *)videoView play:(UIButton *)playButton
{
    HDVideoWebViewController *videoWebViewController = [[HDVideoWebViewController alloc]init];
    videoWebViewController.urlString = self.videoView.detailModel.videoUrl;
    [self.navigationController pushViewController:videoWebViewController animated:YES];

}

#pragma mark 点击了赞
-(void)videoView:(HDVideoView *)videoView up:(UIImageView *)upImageview
{
    HDLogInfo(@"upImageviewupImageview");
    [[HDManager sharedInstance].courseService like:[self getVideoId] resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS) {
            if ([upImageview.image isEqual:[UIImage imageNamed:@"up_highlighted"]]) {
                upImageview.image = [UIImage imageNamed:@"comment_up"];
                videoView.upLabel.text = conversionstring([videoView.upLabel.text integerValue]-1);
            }else{
                upImageview.image = [UIImage imageNamed:@"up_highlighted"];
                if ([videoView.downImageView.image isEqual:[UIImage imageNamed:@"video_down"]]) {
                    videoView.downImageView.image = [UIImage imageNamed:@"comment_down"];
                    videoView.downLabel.text = conversionstring([videoView.downLabel.text integerValue]-1);
                }
                videoView.upLabel.text = conversionstring([videoView.upLabel.text integerValue]+1);
                
            }
        }
    }];
}

#pragma mark 点击了踩
-(void)videoView:(HDVideoView *)videoView down:(UIImageView *)downImageview
{
    HDLogInfo(@"downImageviewdownImageviewdownImageview");
    [[HDManager sharedInstance].courseService dislike:[self getVideoId] resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS) {
            if ([downImageview.image isEqual:[UIImage imageNamed:@"video_down"]]) {
                downImageview.image = [UIImage imageNamed:@"comment_down"];
                videoView.downLabel.text = conversionstring([videoView.downLabel.text integerValue]-1);
            }else{
                downImageview.image = [UIImage imageNamed:@"video_down"];
                if ([videoView.upImageView.image isEqual:[UIImage imageNamed:@"up_highlighted"]]) {
                    videoView.upImageView.image = [UIImage imageNamed:@"comment_up"];
                    videoView.upLabel.text = conversionstring([videoView.upLabel.text integerValue]-1);
                }
                videoView.downLabel.text = conversionstring([videoView.downLabel.text integerValue]+1);

            }
        }
    }];
}

- (NSInteger)getChapterOrSectionId
{
    NSInteger Id = 0;
    
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            Id = chapter.Id;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            Id = section.Id;
        }
    }
    
    return Id;
}

- (NSString *)getChapterOrSectionName
{
    NSString *name = @"";
    
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            name = chapter.name;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            name = section.name;
        }
    }
    if (self.answerModel) {
        name = [name stringByAppendingFormat:@"第%ld题", (long)self.answerModel.questionSeq];
    }
    
    return name;
}

- (NSInteger)getVideoId
{
    NSInteger videoId = 0;
    
    if (self.chapterOrSectionModel && [self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
        HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
        videoId = section.videoId;
    }
    else if (self.answerModel) {
        videoId = self.answerModel.videoId;
    }
    
    return videoId;
}

- (NSInteger)getCourseId
{
    NSInteger Id = 0;
    
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            Id = chapter.courseId;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            Id = section.courseId;
        }
    }
    
    return Id;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
@end
