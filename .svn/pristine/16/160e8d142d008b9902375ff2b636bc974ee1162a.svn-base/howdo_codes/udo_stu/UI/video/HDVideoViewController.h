//
//  HDVideoViewController.h
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDVideoViewController : HDBaseViewController

@property (nonatomic, strong) id chapterOrSectionModel;
@property (nonatomic, strong) HDAnswerModel *answerModel;
@end
