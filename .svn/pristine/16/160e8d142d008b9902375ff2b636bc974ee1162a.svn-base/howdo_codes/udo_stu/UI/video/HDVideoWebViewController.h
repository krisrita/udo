//
//  HDVideoWebViewController.h
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDVideoWebViewController : HDBaseViewController
@property (nonatomic,strong) NSString *urlString;

@end
