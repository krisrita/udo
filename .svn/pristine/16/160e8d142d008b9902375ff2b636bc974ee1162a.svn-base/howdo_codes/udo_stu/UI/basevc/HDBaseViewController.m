//
//  HDBaseViewController.m
//  udo-stu
//
//  Created by nobody on 15/5/27.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDBaseViewController ()

@end

@implementation HDBaseViewController
- (void)setLeftView:(UIView *)leftView
{
    _leftView =leftView;
    [self.headView addSubview:_leftView];
    _leftView.frame = CGRectMake(0,
                                 (CGRectGetHeight(self.headView.frame)-CGRectGetHeight(_leftView.frame))/2+10,
                                 MIN(CGRectGetWidth(_leftView.frame), CGRectGetHeight(self.headView.frame)),
                                 MIN(CGRectGetHeight(_leftView.frame), CGRectGetHeight(self.headView.frame)) );
    
}
- (void)setRightView:(UIView *)rightView
{
    _rightView =rightView;
    [self.headView addSubview:_rightView];
    _rightView.frame = CGRectMake(CGRectGetWidth(self.headView.frame)-CGRectGetWidth(_rightView.frame),
                                  (CGRectGetHeight(self.headView.frame)-CGRectGetHeight(_rightView.frame))/2+10,
                                  MIN(CGRectGetWidth(_rightView.frame), CGRectGetHeight(self.headView.frame)),
                                  MIN(CGRectGetHeight(_rightView.frame), CGRectGetHeight(self.headView.frame)));
}

- (void)setCenterView:(UIView *)centerView
{
    [_centerView removeFromSuperview];
    _centerView =centerView;
    [self.headView  addSubview:_centerView];
    
    _centerView.frame = CGRectMake( MAX((CGRectGetWidth(self.headView .frame)-CGRectGetWidth(_centerView.frame))/2, 50), (CGRectGetHeight(self.headView .frame)-CGRectGetHeight(_centerView.frame))/2+10,MIN(CGRectGetWidth(_centerView.frame), CGRectGetWidth(self.headView.frame)-100) ,MIN(CGRectGetHeight(_centerView.frame), CGRectGetHeight(self.headView .frame)) );
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.animation = YES;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_STATUS_HEIGHT)];
    _headView.backgroundColor = UIColorFromRGB(34, 177, 139);
    self.headView = _headView;
    self.headView.alpha = .99;
    
    [self.view addSubview:_headView];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate
{
    return NO;
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
