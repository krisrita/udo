//
//  HDBaseViewController.h
//  udo-stu
//
//  Created by nobody on 15/5/27.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDBaseViewController : UIViewController

@property (nonatomic,strong)UIView *headView;
@property (nonatomic,strong)UIView *leftView;
@property (nonatomic,strong)UIView *rightView;
@property (nonatomic,strong)UIView *centerView;

@property (nonatomic, assign) NSInteger tag;
@property (nonatomic,strong)id data;

@property (nonatomic,assign)BOOL animation;

- (void)back:(UIButton *)btn;

@end