//
//  HDWebViewController.h
//  udo_stu
//
//  Created by nobody on 6/20/15.
//  All rights reserved.
//

#import "HDBaseViewController.h"
#import "HDNetworkConfig.h"

@interface HDWebViewController : HDBaseViewController

@property (nonatomic, strong) NSString *url;
@property (nonatomic, strong) NSString *title;

+ (void)jumpToWebViewWithUrlType:(UIViewController *)viewController urlType:(HDURLType)urlType title:(NSString *)title;

@end
