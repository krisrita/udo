//
//  HDWebViewController.m
//  udo_stu
//
//  Created by nobody on 6/20/15.
//  All rights reserved.
//

#import "HDWebViewController.h"

@interface HDWebViewController () <UIWebViewDelegate>

@property (nonatomic, strong) UIWebView *webView;

@end

@implementation HDWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.leftView = [HDUICommon leftBackView:self];
    self.centerView = [HDUICommon getTitleView:self.title];
    
    self.webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT - APP_STATUS_HEIGHT)];
    self.webView.delegate = self;
    [self.view addSubview:self.webView];
    
    [HDLoading startAnimating];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.url]]];
}

- (void)dealloc
{
    self.webView = nil;
}

- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [HDLoading stopAnimating];
}

+ (void)jumpToWebViewWithUrlType:(UIViewController *)viewController urlType:(HDURLType)urlType title:(NSString *)title
{
    HDWebViewController *webViewController = [[HDWebViewController alloc] init];
    webViewController.title = title;
    webViewController.url = [HDNetworkConfig getModuleUrl:urlType];
    [viewController.navigationController pushViewController:webViewController animated:YES];
}

@end
