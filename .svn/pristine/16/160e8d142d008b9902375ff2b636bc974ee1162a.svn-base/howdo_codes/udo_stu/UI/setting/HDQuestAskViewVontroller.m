
//
//  HDQuestAskViewVontroller.m
//  udo_stu
//
//  Created by kaola on 15/6/7.
//  All rights reserved.
//

#import "HDQuestAskViewVontroller.h"

#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

@interface HDQuestAskViewVontroller ()<UITextViewDelegate>
{
    UITextView * myTextView;
    UILabel * label;
    UITextView * _contactTxtView;
    UILabel *_lianxiLbl;
}

@end

@implementation HDQuestAskViewVontroller

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setNavbar];
    
    self.view.backgroundColor = RGBColor(231, 231, 231);
    
    UIImageView *imaVBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 42+64, APP_CONTENT_WIDTH, 150)];
    imaVBack.image = [[UIImage imageNamed:@"yijian"]stretchableImageWithLeftCapWidth:0 topCapHeight:2];
    [self.view addSubview:imaVBack];
    imaVBack.userInteractionEnabled = YES;
    //意见框
    myTextView = [[UITextView alloc]initWithFrame:CGRectMake(10,
                                                             10,
                                                             imaVBack.frame.size.width-20,
                                                             imaVBack.frame.size.height-20)];
    myTextView.delegate = self;
    myTextView.tag = 200;
    [myTextView setUserInteractionEnabled:YES];
    [myTextView setBackgroundColor:[UIColor clearColor]];
    myTextView.textAlignment = NSTextAlignmentLeft;
    [myTextView setBackgroundColor:[UIColor clearColor ]];
    myTextView.layer.borderColor = [[UIColor redColor] CGColor];
//    myTextView.textColor = [UIColor textColor];
    myTextView.font = [UIFont systemFontOfSize:14];
    myTextView.autocapitalizationType = UITextAutocapitalizationTypeNone;
    myTextView.autocorrectionType = UITextAutocorrectionTypeNo;
    [imaVBack addSubview:myTextView];
    
    label = [[UILabel alloc]init];
    label.frame =CGRectMake(6, 6, APP_SCREEN_WIDTH - 20, 20);
    label.font = [UIFont systemFontOfSize:14];
    label.enabled = NO;
    label.backgroundColor = [UIColor clearColor];
    [myTextView addSubview:label];
    
    
    UIImageView *imaVLianXiBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(imaVBack.frame)+35, APP_CONTENT_WIDTH, 35)];
    imaVLianXiBack.image = [[UIImage imageNamed:@"yijian"]stretchableImageWithLeftCapWidth:0 topCapHeight:2];
    [self.view addSubview:imaVLianXiBack];
    imaVLianXiBack.userInteractionEnabled = YES;
    
    _lianxiLbl = [[UILabel alloc]init];
    _lianxiLbl.frame =CGRectMake(15, CGRectGetMaxY(imaVBack.frame)+39, 150, 25);
    _lianxiLbl.backgroundColor = [UIColor clearColor];
    _lianxiLbl.font = [UIFont systemFontOfSize:14];
    _lianxiLbl.enabled = NO;
    [self.view addSubview:_lianxiLbl];
    //号码输入的框
    _contactTxtView = [[UITextView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(imaVBack.frame)+35, APP_SCREEN_WIDTH - 20, 35)];
    _contactTxtView.delegate = self;
    _contactTxtView.tag = 201;
    _contactTxtView.backgroundColor = [UIColor clearColor];
    _contactTxtView.font = [UIFont systemFontOfSize:14];
    _contactTxtView.autocapitalizationType = UITextAutocapitalizationTypeNone;
    _contactTxtView.autocorrectionType = UITextAutocorrectionTypeNo;
    ;

    [self.view addSubview:_contactTxtView];
    
    UILabel *labBottomLine = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_contactTxtView.frame), APP_CONTENT_WIDTH, 0.5)];
    labBottomLine.backgroundColor = RGBColor(203, 205, 203);
    [self.view addSubview:labBottomLine];
    
    // 第一个标题
    UILabel *labFContent = [[UILabel alloc] initWithFrame:CGRectMake(15, 64+24, 100, 15)];
    labFContent.text = @"您的问题与建议";
    labFContent.font = [UIFont systemFontOfSize:13];
    labFContent.textColor = RGBColor(97, 97, 97);
    labFContent.backgroundColor = [UIColor clearColor];
    [self.view addSubview:labFContent];
    
    // 第二个标题
    UILabel *labLianXiContent = [[UILabel alloc] initWithFrame:CGRectMake(15,
                                                                          imaVBack.frame.size.height+imaVBack.frame.origin.y+18,
                                                                          300,
                                                                          15)];
    labLianXiContent.text = @"您的联系方式（手机/邮箱/QQ）";
    labLianXiContent.font = [UIFont systemFontOfSize:13];
    labLianXiContent.textColor = RGBColor(97, 97, 97);
    labLianXiContent.backgroundColor = [UIColor clearColor];
    [self.view addSubview:labLianXiContent];
    
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(15 ,
                                                               imaVLianXiBack.frame.size.height+imaVLianXiBack.frame.origin.y+100, APP_CONTENT_WIDTH-30, 44)];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    [btn setBackgroundImage:[UIImage imageNamed:@"sunmitButton"] forState:UIControlStateNormal];
    [btn setTitle:@"提交" forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    [btn addTarget:self action:@selector(commitSuget:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

//当点击输入框以外的地方键盘退出
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [myTextView resignFirstResponder];
    [_contactTxtView resignFirstResponder];
}

-(void)textViewDidChange:(UITextView *)textView
{
    if (textView.tag == 200) {
        if (textView.text.length == 0){
            label.hidden = NO;
        }
        else{
            label.hidden = YES;
        }
    }else if (textView.tag == 201){
        if (textView.text.length == 0){
            _lianxiLbl.hidden = NO;
        }
        else{
            _lianxiLbl.hidden = YES;
        }
    }
    
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (text.length !=  0)
    {
        int MAX_CHARS = 140;
        NSMutableString *newtxt = [NSMutableString stringWithString:textView.text];
        [newtxt replaceCharactersInRange:range withString:text];
        return ([newtxt length] <= MAX_CHARS );
    }
    
//    if ([text isEqualToString:@""]) return YES;
//    
//    if (textView.text.length > 10) return NO;
    
    return YES;
}

-(void)resignAllFirstResponder
{
    [myTextView resignFirstResponder];
    [_contactTxtView resignFirstResponder];
}

-(void)commitSuget:(UIButton *)btn
{
    myTextView.text = [myTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _contactTxtView.text = [_contactTxtView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if(_contactTxtView.text.length == 0)
    {
        [self resignAllFirstResponder];
        [HDTip showSystemAlartTitle:@"提示" message:@"联系方式不能为空"];
        return;
    }
    if (myTextView.text.length == 0 )
    {
        [HDTip showSystemAlartTitle:@"提示" message:@"输入内容不能为空"];
        return;
    }
    else if (myTextView.text.length>140)
    {
        [myTextView resignFirstResponder];
        [HDTip showMessage:@"字符长度超出限制" inView:self.view duration:2];
    }
    
    [_contactTxtView resignFirstResponder];
    [myTextView resignFirstResponder];
    [[[HDManager sharedInstance]appService]sendFeedback:myTextView.text content:_contactTxtView.text resultBack:^(HDServiceResult *result, id object) {
        
        if (result.resultCode == HD_RESULT_CODE_SUCCESS)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
        else
        {
            [result show];
        }
    }];
    
}
- (void)setNavbar
{
    self.centerView = [HDUICommon getTitleView:@"意见反馈"];
    self.leftView = [HDUICommon leftBackView:self];
}

- (void)back:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
