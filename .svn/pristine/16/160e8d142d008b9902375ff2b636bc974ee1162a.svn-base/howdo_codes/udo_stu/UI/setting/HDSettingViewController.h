//
//  HDSettingViewController.h
//  udo_stu
//
//  Created by kaola on 15/6/7.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HDResetPasswordViewController.h"

@interface HDSettingViewController : HDBaseViewController

@end
