



//
//  HDSettingCell.m
//  udo_stu
//
//  Created by kaola on 15/6/7.
//  All rights reserved.
//

#import "HDSettingCell.h"

// 判断字符串不为空并且不为空字符串
#define STR_Not_NullAndEmpty(str) (str!=nil&&![str isEqualToString:@""])
#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

@interface HDSettingCell ()
{
    UIImageView *imgVzhong;
    UISwitch *swich;
}

@end

@implementation HDSettingCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier withDicData:(NSDictionary *)dic
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = [UIColor whiteColor];
        // 最前边的图标
        CGFloat labPointX = 30;
        if (STR_Not_NullAndEmpty([dic objectForKey:@"imgqian"]))
        {
            UIImageView *imgV = [[UIImageView alloc] initWithFrame:CGRectMake(30, 18, 18, 18)];
            imgV.image = [UIImage imageNamed:[dic objectForKey:@"imgqian"]];
            [self.contentView addSubview:imgV];
            
            labPointX = 30+18+17;
        }
        
        // lable文字描述
        UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(labPointX, 0, APP_CONTENT_WIDTH-labPointX, 54)];
        lab.text = [dic objectForKey:@"text"];
        lab.textColor = RGBColor(116, 117, 118);
        lab.font = [UIFont systemFontOfSize:14];
        lab.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:lab];
        
        // 中间的图标（检查更新）
        if (STR_Not_NullAndEmpty([dic objectForKey:@"imgzhong"]))
        {
            imgVzhong = [[UIImageView alloc] initWithFrame:CGRectMake(APP_CONTENT_WIDTH-90, 18, 18, 18)];
            imgVzhong.image = [UIImage imageNamed:[dic objectForKey:@"imgzhong"]];
            [self.contentView addSubview:imgVzhong];
        }
        
        // 后边的箭头
        if (STR_Not_NullAndEmpty([dic objectForKey:@"imghou"]))
        {
            UIImageView *imgV = [[UIImageView alloc] initWithFrame:CGRectMake(APP_CONTENT_WIDTH-35, 20, 8, 14)];
            imgV.image = [UIImage imageNamed:[dic objectForKey:@"imghou"]];
            [self.contentView addSubview:imgV];
        }
        
        // lable提示语 (开启流量cell)
        // 表明是显示两行文字的
        if ([[NSNumber numberWithInteger:cell_Two] isEqual:[dic objectForKey:@"celltype"]])
        {
            lab.frame = CGRectMake(labPointX, -5, APP_CONTENT_WIDTH-labPointX, 54);
            
            // lable文字描述
            UILabel *labSub = [[UILabel alloc] initWithFrame:CGRectMake(labPointX, 18, APP_CONTENT_WIDTH-labPointX, 42)];
            labSub.text = [dic objectForKey:@"textTiShi"];
            labSub.textColor = RGBColor(116, 117, 118);
            labSub.font = [UIFont systemFontOfSize:11];
            labSub.backgroundColor = [UIColor clearColor];
            [self.contentView addSubview:labSub];
            
            swich = [[UISwitch alloc] initWithFrame:CGRectMake(APP_CONTENT_WIDTH-77, 20, 50, 40)];
            swich.on = NO;
            [swich addTarget:self action:@selector(swickClick:) forControlEvents:UIControlEventValueChanged];
            BOOL tag =  [[NSUserDefaults standardUserDefaults]boolForKey:HD_ALLOW_VIDEO_IN_WWAN_KEY];
            swich.on = tag;
            [self.contentView addSubview:swich];
            
            self.selectionStyle = UITableViewCellSelectionStyleNone;
        }
    }
    return self;
}

- (void)swickClick:(id)sender
{
    if (_delegate && [_delegate respondsToSelector:@selector(swichIsOn:)])
    {
        [_delegate swichIsOn:swich.on];
    }
}

- (void)dractLineWithIndexpath:(NSIndexPath *)indexpath
{
    // 顶部的分割线
    UILabel *labTopLine = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, APP_CONTENT_WIDTH-30, 1)];
    labTopLine.backgroundColor = RGBColor(203, 203, 205);
    [self.contentView addSubview:labTopLine];
    
    // 底部的分割线
    UILabel *labBottomLine = [[UILabel alloc] initWithFrame:CGRectMake(15, 53, APP_CONTENT_WIDTH-30, 1)];
    labBottomLine.backgroundColor = RGBColor(203, 203, 205);
    [self.contentView addSubview:labBottomLine];

    if (indexpath.section == 0)
    {
        labTopLine.hidden = YES;
        if (indexpath.row==4)
        {
            labBottomLine.frame = CGRectMake(0, 53, APP_CONTENT_WIDTH, 1);
        }
        else if (indexpath.row==0)
        {
            labBottomLine.frame = CGRectMake(0, 59, APP_CONTENT_WIDTH, 1);
        }
    }
    else if (indexpath.section == 1)
    {
        labTopLine.frame = CGRectMake(0, 0, APP_CONTENT_WIDTH, 1);
        labBottomLine.frame = CGRectMake(0, 53, APP_CONTENT_WIDTH, 1);
    }
}

@end
