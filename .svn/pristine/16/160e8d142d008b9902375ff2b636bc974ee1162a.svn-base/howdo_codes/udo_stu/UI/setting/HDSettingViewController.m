
//
//  HDSettingViewController.m
//  udo_stu
//
//  Created by kaola on 15/6/7.
//  All rights reserved.
//

#import "HDSettingViewController.h"
#import "HDSettingCell.h"
#import "HDChangePasswordViewController.h"
#import "HDQuestAskViewVontroller.h"
#import "HDGuideViewController.h"
#import "HDLoginProxy.h"
#import "UIAlertView+Blocks.h"

#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

@interface HDSettingViewController ()<UITableViewDataSource,UITableViewDelegate,HDSettingCellClickSwickDelegate>
{
    NSMutableArray *aryData;
}

@property (nonatomic, strong) UITableView *tvew;

@end

@implementation HDSettingViewController

-(void)closeSettingVC
{
    [self.navigationController dismissViewControllerAnimated:YES completion:NULL];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = RGBColor(230, 231, 233);
    
    UIButton * leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    [leftBtn setImage:[UIImage imageNamed:@"btn_close"] forState:UIControlStateNormal];
    self.leftView = leftBtn;
    [leftBtn addTarget:self action:@selector(closeSettingVC) forControlEvents:UIControlEventTouchUpInside];
    self.centerView = [HDUICommon getTitleView:@"系统设置"];
    
    [self initVariable]; /// 初始化变量
    [self initViews]; /// 初始化界面
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc
{
    
}

- (void)initVariable
{
    // 文字描述
    {
        NSDictionary *dic0 = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"允许非WIFI网络播放视频",@"text",
                              [NSNumber numberWithInteger:cell_Two],@"celltype",
                              @"请慎重选择开启，避免过度使用流量",@"textTiShi",
                              nil];
        NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"ic_setting_lock",@"imgqian",
                              @"ic_cell_arrow.png",@"imghou",
                              @"修改密码",@"text",
                              [NSNumber numberWithInteger:cell_one],@"celltype",
                              nil];
        
        NSDictionary *dic2 = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"ic_setting_update",@"imgqian",
                              @"",@"imgzhong",
                              @"ic_cell_arrow.png",@"imghou",
                              @"检测新版本",@"text",
                              [NSNumber numberWithInteger:cell_one],@"celltype",
                              nil];
        NSDictionary *dic3 = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"ic_setting_feedback",@"imgqian",
                              @"ic_cell_arrow.png",@"imghou",
                              @"问题反馈",@"text",
                              [NSNumber numberWithInteger:cell_one],@"celltype",
                              nil];
        NSDictionary *dic4 = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"ic_setting_about",@"imgqian",
                              @"ic_cell_arrow.png",@"imghou",
                              @"关于",@"text",
                              [NSNumber numberWithInteger:cell_one],@"celltype",
                              nil];
        NSDictionary *dic5 = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"ic_setting_logout",@"imgqian",
                              @"ic_cell_arrow.png",@"",
                              @"注销",@"text",
                              [NSNumber numberWithInteger:cell_one],@"celltype",
                              nil];
        NSArray *arySection0 = [[NSArray alloc] initWithObjects:dic0,dic1,dic2,dic3,dic4, nil];
        NSArray *arySection1 = [[NSArray alloc] initWithObjects:dic5, nil];
        aryData = [[NSMutableArray alloc] initWithObjects:arySection0,arySection1, nil];
    }
}

- (void)initViews
{
    _tvew = [[UITableView alloc] initWithFrame:CGRectMake(0,
                                                          64,
                                                          APP_CONTENT_WIDTH,
                                                          APP_CONTENT_HEIGHT-64)
                                         style:UITableViewStylePlain];
    _tvew.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tvew.delegate = self;
    _tvew.dataSource = self;
    _tvew.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_tvew];
}

#pragma mark - ************* delegate *************

#pragma mark - cellDelegate回调
- (void)swichIsOn:(BOOL)isOn
{
    [[NSUserDefaults standardUserDefaults]setBool:isOn forKey:HD_ALLOW_VIDEO_IN_WWAN_KEY];
    if (isOn)
    {
        NSLog(@"开开了");
    }
    else
    {
        NSLog(@"关上了");
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0 && indexPath.row==0)
    {
        return 60;
    }
    return 54.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section==1)
    {
        return 8.0;
    }
    else
    {
        return 0.0f;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.0f;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[aryData objectAtIndex:section] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *areaIdentifier = @"areaIdentifier";
    HDSettingCell *cell = [tableView dequeueReusableCellWithIdentifier:areaIdentifier];
    if (cell == nil)
    {
        cell = [[HDSettingCell alloc] initWithStyle:UITableViewCellStyleDefault
                                    reuseIdentifier:areaIdentifier
                                        withDicData:[[aryData objectAtIndex:indexPath.section]
                                                     objectAtIndex:indexPath.row]];
        cell.delegate = self;
        [cell dractLineWithIndexpath:indexPath];
    }
    
    if (2 == indexPath.row) {
        if ([HDUpgrade sharedInstance].hasNewVersion) {
            UIImage *newIcon = [UIImage imageNamed:@"ic_new"];
            UIImageView *newIconView = [[UIImageView alloc] initWithFrame:CGRectMake(140, (CGRectGetHeight(cell.frame)-newIcon.size.height)/2 + 5, newIcon.size.width, newIcon.size.height)];
            newIconView.image = newIcon;
            [cell addSubview:newIconView];
        }
    }
    
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return aryData.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 )
    {
        switch (indexPath.row)
        {
            case 1:
            {
                HDLogInfo(@"修改密码");
                HDChangePasswordViewController * resetP = [[HDChangePasswordViewController alloc]init];
                [self.navigationController pushViewController:resetP animated:YES];
                
                break;
            }
            case 2:
                [[HDUpgrade sharedInstance] checkNewVersion:NO];
                
                break;
            case 3:
            {
                HDLogInfo(@"问题反馈");
                HDQuestAskViewVontroller * resetP = [[HDQuestAskViewVontroller alloc]init];
                [self.navigationController pushViewController:resetP animated:YES];
                
                break;
            }
            case 4: //关于
                [HDWebViewController jumpToWebViewWithUrlType:self urlType:URL_TYPE_ABOUT title:@"关于UDO"];
                break;
            default:
                
                break;
        }
    }
    else
    {
        
        [[[UIAlertView alloc] initWithTitle:@""
                                    message:@"确认注销？"
                           cancelButtonItem:[RIButtonItem itemWithLabel:@"取消" action:^{}]
                           otherButtonItems:[RIButtonItem itemWithLabel:@"确定" action:^{
            
                        [[HDLoginProxy sharedInstance] logout];
            
            [[HDLoginProxy sharedInstance]loginWithContext:self result:^(HDCommonResult *result) {
               
                
                
            }];

                    }], nil] show];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
