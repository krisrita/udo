//
//  HDSettingCell.h
//  udo_stu
//
//  Created by kaola on 15/6/7.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, cellType) {

    /// 两行文字的
    cell_Two = 0,
    /// 一行文字的
    cell_one
};

@protocol HDSettingCellClickSwickDelegate;
@interface HDSettingCell : UITableViewCell

@property(nonatomic,strong)NSDictionary *dicData;

@property (weak, nonatomic) id<HDSettingCellClickSwickDelegate>delegate;

/// 初始化方法
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier withDicData:(NSDictionary *)dic;

/// 初始化cell的分割线
- (void)dractLineWithIndexpath:(NSIndexPath *)indexpath;

@end

@protocol HDSettingCellClickSwickDelegate <NSObject>

/**
 *  isOn swich是开启状态 还是关闭状态 YES开启 NO关闭
 */
- (void)swichIsOn:(BOOL)isOn;

@end
