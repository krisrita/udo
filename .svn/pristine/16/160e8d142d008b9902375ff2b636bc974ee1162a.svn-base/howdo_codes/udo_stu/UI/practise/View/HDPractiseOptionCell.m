//
//  HDPractiseOptionCell.m
//  udo_stu
//
//  Created by nobody on 15/7/8.
//  All rights reserved.
//

#import "HDPractiseOptionCell.h"

@interface HDPractiseOptionCell () <UIWebViewDelegate>

@end

@implementation HDPractiseOptionCell

- (void)awakeFromNib {
    // Initialization code
    
    [self.checkButton setTitleColor:UIColorFromRGB(45, 140, 252) forState:UIControlStateNormal];
    [self.checkButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
    [self.checkButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateSelected];
    self.webView.userInteractionEnabled = NO;
    self.webView.dataDetectorTypes = UIDataDetectorTypeNone;
    self.webView.delegate = self;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)ClickCheckButton:(UIButton *)sender {
    self.optionModel.selected = YES;
    sender.selected = YES;
    // 进入下一题
    if ([self.cellDelegate respondsToSelector:@selector(practiseOptionCellDidClickCheckButton:)]) {
        [self.cellDelegate practiseOptionCellDidClickCheckButton:self];
    }
}

- (void)setOptionModel:(HDOptionModel *)optionModel {
    if (optionModel == nil || optionModel.Id == 0) return;
    
    _optionModel = optionModel;
    self.webView.hidden = YES;
    if (optionModel.content && optionModel.content.length > 0) {
        [self.webView loadHTMLString:optionModel.content baseURL:nil];
    } else {
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:optionModel.url]]];
    }
    
    [self.checkButton setTitle:optionModel.letterSeq forState:UIControlStateNormal];
    self.checkButton.selected = optionModel.selected;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    webView.hidden = NO;
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
//    MyLog(@"选项家长失败 - %@", error);
}


@end
