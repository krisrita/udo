//
//  HDPractiseController.m
//  udo_stu
//
//  Created by nobody on 15/7/8.
//   All rights reserved.
//

#import "HDPractiseController.h"
#import "HDPractiseCell.h"
#import "HDAnswerCardView.h"
#import "HDPractiseSelectResultCell.h"

NSString * const HDPractiseCellReuseId = @"HDPractiseCellReuseId";
NSString * const HDPractiseSelectResultCellReuseId = @"HDPractiseSelectResultCellReuseId";


const NSInteger AlertViewTagWhenBack = 100;

@interface HDPractiseController () <UICollectionViewDataSource, UICollectionViewDelegate, HDPractiseDelegate, UIScrollViewDelegate, HDAnswerCardDelegate, HDPractiseCellDelegate, HDPractiseSelectResultCellDelegate>
/// 练习名称
@property (weak, nonatomic) IBOutlet UILabel *practiseTitleLabel;
/// 序号
@property (weak, nonatomic) IBOutlet UILabel *seqLabel;

@property (nonatomic, weak) UICollectionView *collectionView;
/// 计时
@property (nonatomic, strong) UILabel *timerLabel;

/// 定时器
@property (nonatomic, strong) NSTimer *timer;
/// 答题时间
@property (nonatomic, assign) NSInteger spendSeconds;

// [HDQuestion]
@property (nonatomic, strong) NSMutableArray *questions;

/// 当前页码
@property (nonatomic, assign) NSInteger currentSeq;

/// 答题按钮
@property (nonatomic, strong) UIButton *answerCardButton;
/// 答题卡
@property (nonatomic, strong) HDAnswerCardView *cardView;

@end

@implementation HDPractiseController
#pragma mark - Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupNav];
    
    [self setupCollectionView];
    
    [self setupTimeView];
    
    // 右下角答题卡
    [self setupAnwserCard];
    
    [self requestDataWithSeq:1];
}

#pragma mark - Init View
- (void)setupNav {
    self.leftView = [HDUICommon leftBackView:self];
    ((MLNavigationController *)self.navigationController).canDragBack = NO;
    self.centerView = [HDUICommon getTitleView:@"随堂练习"];
}

- (void)setupCollectionView {
    CGSize itemSize = CGSizeMake(APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT - 64.0);
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.minimumLineSpacing = 0;
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flowLayout.itemSize = itemSize;
    
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    self.collectionView = collectionView;
    collectionView.frame = CGRectMake(0, 64.0, itemSize.width, itemSize.height);
    [collectionView registerNib:[UINib nibWithNibName:@"HDPractiseCell" bundle:nil] forCellWithReuseIdentifier:HDPractiseCellReuseId];
    [collectionView registerNib:[UINib nibWithNibName:@"HDPractiseSelectResultCell" bundle:nil] forCellWithReuseIdentifier:HDPractiseSelectResultCellReuseId];
    collectionView.backgroundColor = [UIColor whiteColor];
    collectionView.pagingEnabled = YES;
    collectionView.showsHorizontalScrollIndicator = NO;
    collectionView.showsVerticalScrollIndicator = NO;
    collectionView.dataSource = self;
    collectionView.delegate = self;
    [self.view addSubview:collectionView];
}

- (void)setupTimeView {
    UIView *timerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 58.5, 44)];
    UIImageView *timerIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ic_practise_timer"]];
    [timerView addSubview:timerIcon];
    
    [timerIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(timerView).offset(4.5);
        make.right.equalTo(timerView).offset(-16.5);
    }];
    
    self.timerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 58, 44)];
    [self.timerLabel setTextAlignment:NSTextAlignmentRight];
    [self.timerLabel setTextColor:[UIColor whiteColor]];
    [self.timerLabel setText:@"00:00"];
    [timerView addSubview:self.timerLabel];
    
    [self.timerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(timerView).offset(-12);
        make.top.equalTo(timerView).offset(15);
    }];
    
    self.rightView = timerView;
    self.timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(changeTime:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    [self.timer fire];
}

- (void)setupAnwserCard {
    
    self.answerCardButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.answerCardButton setImage:[UIImage imageNamed:@"btn_answer_card"] forState:UIControlStateNormal];
    [self.answerCardButton addTarget:self action:@selector(answerCardClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.answerCardButton];
    [self.answerCardButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view).offset(-14);
        make.bottom.equalTo(self.view).offset(-13.5);
    }];
}

#pragma mark - Network Request

- (void)requestDataWithSeq:(NSInteger)seq {
    HDQuestionModel *questionM = self.questions[seq - 1];
    if (questionM.Id > 0) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:seq - 1 inSection:0];
        [self.collectionView reloadItemsAtIndexPaths:@[indexPath]];
        return;
    }
    
    __weak __typeof(self)weakSelf = self;
    [[HDManager sharedInstance].courseService getPractiseQuestion:self.sectionModel.Id questionSeq:seq resultBack:^(HDServiceResult *result, id object) {
        if (!weakSelf) return;
        __weak typeof(weakSelf) strongSelf = weakSelf;
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            if (object && [object isKindOfClass:[HDQuestionModel class]]) {
                HDQuestionModel *question = (HDQuestionModel *)object;
                [strongSelf.questions replaceObjectAtIndex:seq - 1 withObject:question];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [strongSelf.collectionView reloadData];
                });
            }
        }
    }];
}

#pragma mark - UITableViewDelegate

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (self.sectionModel.practiseNum == 0) return 0;
    
    return self.sectionModel.practiseNum + 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == self.sectionModel.practiseNum) {
        HDPractiseSelectResultCell *rsItem = [collectionView dequeueReusableCellWithReuseIdentifier:HDPractiseSelectResultCellReuseId forIndexPath:indexPath];
        rsItem.anwsers = [self getAnswers];
        rsItem.practiseTitleLabel.text = self.sectionModel.name;
        rsItem.cellDelegate = self;
        return rsItem;
    }
    
    HDPractiseCell *item = [collectionView dequeueReusableCellWithReuseIdentifier:HDPractiseCellReuseId forIndexPath:indexPath];
    item.practiseTitleLabel.text = self.sectionModel.name;
    item.seqLabel.text = [NSString stringWithFormat:@"%ld/%ld", (long)(indexPath.row + 1), (long)self.sectionModel.practiseNum];
    item.questionModel = self.questions[indexPath.row];
    item.cellDelegate = self;
    return item;
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSInteger seq = (NSInteger)(scrollView.contentOffset.x / scrollView.bounds.size.width + 0.5);
    if (self.currentSeq == seq) return;
    self.currentSeq = seq;
    
    // 是否是最后一题，
    BOOL isLast = seq == self.sectionModel.practiseNum;
    self.answerCardButton.hidden = isLast;
    if (isLast) return;
    
    [self requestDataWithSeq:seq + 1];
}


#pragma mark - CustomDelegate

#pragma mark HDPractiseCellDelegate
- (void)practiseCellDidSelectedAnswer:(HDPractiseCell *)practiseCell {
    NSIndexPath *indexPath = [self.collectionView indexPathForCell:practiseCell];
    [self jumpToSeq:indexPath.row + 1];
}

#pragma mark HDPractiseSelectResultCellDelegate 
#pragma mark 提交答案
- (void)practiseSelectResultCellDidSubmitAnswer:(HDPractiseSelectResultCell *)practiseSelectResultCell {
    [self submitAnswerClicked];
}

// 选择题目
- (void)practiseSelectResultCell:(HDPractiseSelectResultCell *)practiseSelectResultCell didSelectSeq:(NSInteger)seq {
    [self jumpToSeq:seq - 1];
}

#pragma mark HDAnswerCard Delegate
- (void)questionSeqSelected:(NSInteger)questionSeq
{
    [self hideAnswerCard:YES];
    [self jumpToSeq:questionSeq - 1];
}

#pragma mark 交卷
- (void)submitAnswerClicked
{
    NSArray *answers = [self getAnswers];
    NSInteger unfinishCount = 0;
    for (HDAnswerModel *answer in answers) {
        if (answer.optionId <= 0) {
            unfinishCount++;
        }
    }
    NSString *message = unfinishCount > 0 ? [NSString stringWithFormat:@"有%d道题目尚未作答，是否确认交卷?", unfinishCount] : @"是否确认交卷";
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    [alertView show];
}

#pragma mark UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) return;
    
    if (alertView.tag == AlertViewTagWhenBack) {
        [self.timer invalidate];
        self.timer = nil;
        [self.navigationController popViewControllerAnimated:self.animation];
        return;
    }
    
    [self.timer invalidate];
    self.timer = nil;
    
    [HDLoading startAnimating:@"正在提交答题结果..."];
    [[HDManager sharedInstance].courseService submitPractiseAnswers:self.sectionModel.Id answers:[self getAnswers] spentTime:self.spendSeconds resultBack:^(HDServiceResult *result, id object) {
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            [self hideAnswerCard:NO];
            [HDLoading stopAnimating];
            self.sectionModel.hasPracticed = YES;
            [[HDPractiseProxy sharedInstance] showPractiseReport:self practiseType:self.practiseType chapterOrSection:self.sectionModel];
        } else {
            [HDTip showSystemAlartTitle:@"提交失败" message:@"提交答题结果失败，请再试一次"];
        }
    }];
}

#pragma mark - Event Response
- (void)back:(UIButton *)btn {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"确定要退出练习?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alertView.tag = AlertViewTagWhenBack;
    [alertView show];
}

// 点击了答题
- (void)answerCardClicked:(UIButton *)sender
{
    self.cardView = [[HDAnswerCardView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT + 40, APP_CONTENT_WIDTH, 250)];
    self.cardView.delegate = self;
    self.cardView.answers = [self getAnswers];
    
    BSbottomModel *model = [BSbottomModel sharedInstance];
    model.backgroundDisplayStyle = BSModalBackgroundDisplayStyleSolid;
    model.showCloseButton = NO;
    [[BSbottomModel sharedInstance] showWithContentView:self.cardView
                                            andAnimated:YES
                                              showBlock:^{
                                                  self.answerCardButton.hidden = YES;
                                              }
                                           dismissBlock:^{
                                               self.answerCardButton.hidden = NO;
                                               [self.cardView removeFromSuperview];
                                               self.cardView = nil;
                                           }];
}

#pragma mark - Public Methods

#pragma mark - Private Methods

- (void)jumpToSeq:(NSInteger)seq {
    NSIndexPath *nextIndexPath = [NSIndexPath indexPathForItem:seq inSection:0];
    [self.collectionView scrollToItemAtIndexPath:nextIndexPath atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
}

/// 更改时间
- (void)changeTime:(NSTimer *)timer {
    self.spendSeconds++;
    self.timerLabel.text = [NSString stringWithFormat:@"%02ld:%02ld", (long)self.spendSeconds / 60, (long)self.spendSeconds % 60];
}

/// 获取答案
- (NSArray *)getAnswers
{
    NSMutableArray *answers = [NSMutableArray array];
    
    for (NSInteger i = 0; i < self.sectionModel.practiseNum; i++) {
        HDAnswerModel *answer = [[HDAnswerModel alloc] init];
        answer.questionSeq = i + 1;
        [answers addObject:answer];
    }
    
    @synchronized(self.questions) {
        for (HDQuestionModel *question in self.questions) {
            if (question.seq > 0 && question.seq <= [answers count]) {
                HDAnswerModel *answer = (HDAnswerModel *)[answers objectAtIndex:(question.seq - 1)];
                answer.questionId = question.Id;
                answer.questionSeq = question.seq;
                answer.optionId = question.optionId;
            }
        }
    }
    
    return answers;
}

- (void)hideAnswerCard:(BOOL)animated
{
    [[BSbottomModel sharedInstance]hideAnimated:animated dismissBlock:^{
        self.answerCardButton.hidden = NO;
        [self.cardView removeFromSuperview];
        self.cardView = nil;
    }];
}

#pragma mark - Getters & Setters

- (NSMutableArray *)questions {
    if (_questions == nil) {
        _questions = [[NSMutableArray alloc] initWithCapacity:self.sectionModel.practiseNum];
        for (int i = 0; i < self.sectionModel.practiseNum; i++) {
            [_questions addObject:[[HDQuestionModel alloc] init]];
        }
    }
    return _questions;
}


#pragma mark - 没有用
- (void)initPractise
{
    //    self.answerCardButton.enabled = NO;
    [HDLoading startAnimating:@"正在准备练习题..."];
    
    // 创建一个HDPractise实例，并将传入的参数赋值到属性上
    [HDPractise createPractise:HD_PRACTISE_TYPE_SECTION chapterOrSectionId:[self getChapterOrSectionId]];
    
    // 拿到上面创建的HDPractise实例设置代理
    [[HDPractise currentPractise] setPractiseDelegate:self];
    
    // 准备题目，里面请求网络
    [[HDPractise currentPractise] preparePractise:^(HDCommonResult *result) {
        [HDLoading stopAnimating];
        [[HDPractise currentPractise] startPractise]; //开始计时
        [self jumpToQuestion:1];
    }];
}
/// 获取id
- (NSInteger)getChapterOrSectionId
{
    NSInteger Id = 0;
    
    if (self.sectionModel) {
        if ([self.sectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.sectionModel;
            Id = chapter.Id;
        }
        else if ([self.sectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.sectionModel;
            Id = section.Id;
        }
    }
    
    return Id;
}


- (void)jumpToQuestion:(NSInteger)questionSeq
{
    __weak __typeof(self)weakSelf = self;
    [[HDPractise currentPractise] jumpToQuestion:questionSeq resultBack:^(BOOL isFirst, BOOL isFinished, HDQuestionModel *question) {
        if (!weakSelf) return;
        // 拿到question模型
        __strong __typeof(weakSelf)strongSelf = weakSelf;
        //        strongSelf.isFirstQuestion = isFirst;
        //        strongSelf.isLastQuestion = isFinished;
        //        strongSelf.currentQuestion = question;
        [strongSelf.questions replaceObjectAtIndex:questionSeq - 1 withObject:question];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [strongSelf.collectionView reloadData];
            //            [strongSelf showQuestion:strongSelf.currentQuestion];
            //            strongSelf.answerCardButton.enabled = YES;
        });
    }];
}

@end
