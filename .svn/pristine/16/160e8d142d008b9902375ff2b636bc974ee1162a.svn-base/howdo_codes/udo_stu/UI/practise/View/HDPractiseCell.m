//
//  HDPractiseCell.m
//  udo_stu
//
//  Created by nobody on 15/7/8.
//  All rights reserved.
//

#import "HDPractiseCell.h"
#import "HDPractiseOptionCell.h"

NSString * const HDPractiseOptionCellReuseId = @"HDPractiseOptionCellReuseId";

/*
@interface HDPractiseCellHeader: UIView

/// 名称
@property (nonatomic, weak) UILabel *titleLabel;
/// 序号
@property (nonatomic, weak) UILabel *seqLabel;
/// 线
@property (nonatomic, weak) UIImageView *lineView;

@end

@implementation HDPractiseCellHeader

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // 底部的线
        UIImageView *lineView = [[UIImageView alloc] init];
        lineView.image = [UIImage imageNamed:@"bg_practise_top_line"];
        [self addSubview:lineView];
        _lineView = lineView;
        
        // 名称
        UILabel *titleLabel = [[UILabel alloc] init];
        [self addSubview:titleLabel];
        _titleLabel = titleLabel;
        
        // 序号
        UILabel *seqLabel = [[UILabel alloc] init];
        [self addSubview:seqLabel];
        _seqLabel = seqLabel;
        
        [self setupConstrains];
    }
    return self;
}

- (void)setupConstrains {
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self);
        make.height.equalTo(@3.0);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(23.0);
        make.right.equalTo(self).offset(45.0);
        make.top.equalTo(self);
        make.bottom.equalTo(self.lineView.mas_top);
    }];
    
    [self.seqLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.titleLabel.mas_right);
        make.top.equalTo(self);
        make.bottom.equalTo(self.lineView.mas_top);
        make.width.equalTo(@45.0);
    }];
}

@end
*/

#pragma mark -
@interface HDPractiseCell () <UITableViewDataSource, UITableViewDelegate, UIWebViewDelegate, HDPractiseOptionCellDelegate>
/// 内容
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, weak) UIWebView *topicWebView;

@end

@implementation HDPractiseCell

- (void)dealloc {
    [self.topicWebView.scrollView removeObserver:self forKeyPath:@"contentSize"];
}

- (void)awakeFromNib {
    // 题目
    UIWebView *topicWebView = [[UIWebView alloc] init];
    topicWebView.bounds = CGRectMake(0, 0, APP_CONTENT_WIDTH, 44.0);
    topicWebView.delegate = self;
    topicWebView.dataDetectorTypes = UIDataDetectorTypeNone;
    self.topicWebView = topicWebView;
    
    self.tableView.tableHeaderView = topicWebView;
    [self.tableView registerNib:[UINib nibWithNibName:@"HDPractiseOptionCell" bundle:nil] forCellReuseIdentifier:HDPractiseOptionCellReuseId];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    // KVO监听webView的cotentSize
    [topicWebView.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if (self.topicWebView.scrollView.contentSize.height > 44.0) {
        CGRect frame = self.topicWebView.bounds;
        frame.size.height = self.topicWebView.scrollView.contentSize.height;
//        frame.size = self.topicWebView.scrollView.contentSize;
        
        self.topicWebView.frame = frame;
//        self.topicWebView.frame = CGRectMake(0, 0, 702, 93);
        self.tableView.tableHeaderView = self.topicWebView;
    }
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.questionModel.options count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HDPractiseOptionCell *cell = [tableView dequeueReusableCellWithIdentifier:HDPractiseOptionCellReuseId];
    cell.cellDelegate = self;
    cell.optionModel = self.questionModel.options[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark UIWebViewDelegate

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    if (webView == self.topicWebView) {
        self.topicWebView.hidden = NO;
    }
}


#pragma mark - Coustom Delegate
#pragma mark HDPractiseOptionCellDelegate
- (void)practiseOptionCellDidClickCheckButton:(HDPractiseOptionCell *)practiseOptionCell {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:practiseOptionCell];
    for (int i = 0; i < [self.questionModel.options count]; i++) {
        if (i != indexPath.row) {
            // 对应的model取消选中
            HDOptionModel *optionModel = self.questionModel.options[i];
            optionModel.selected = NO;
            // 对应的cell取消选中
            HDPractiseOptionCell *cell = (HDPractiseOptionCell *)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
            cell.checkButton.selected = NO;
        }
    }
    // 将已经选择答案的问题赋值答案id
    HDOptionModel *selectOption = self.questionModel.options[indexPath.row];
    self.questionModel.optionId = selectOption.Id;
    // 进入下一题
    if ([self.cellDelegate respondsToSelector:@selector(practiseCellDidSelectedAnswer:)]) {
        [self.cellDelegate practiseCellDidSelectedAnswer:self];
    }
}

#pragma mark - Getters & Setters

- (void)setQuestionModel:(HDQuestionModel *)questionModel {
    if (questionModel == nil || questionModel.Id == 0) return;

    _questionModel = questionModel;
    self.topicWebView.hidden = YES;
//    if (self.topicWebView.isLoading) [self.topicWebView stopLoading];
//    MyLog(@"loadcontent");
//    questionModel.url = @"http://www.baidu.com";
//    questionModel.content = @"<p>haha</p>";
    MyLog(@"nimei %@ %@", questionModel.url, questionModel.content);
    if (questionModel.content && questionModel.content.length > 0) {
        [self.topicWebView loadHTMLString:questionModel.content baseURL:nil];
    } else {
        [self.topicWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:questionModel.url]]];
    }
    
    [self.tableView reloadData];
}

@end
