//
//  HDPractiseSelectResultCell.h
//  udo_stu
//
//  Created by nobody on 15/7/9.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPractiseSelectResultCell;

@protocol HDPractiseSelectResultCellDelegate <NSObject>

/// 提交答案
- (void)practiseSelectResultCellDidSubmitAnswer:(HDPractiseSelectResultCell *)practiseSelectResultCell;

/// 选择了某道题
- (void)practiseSelectResultCell:(HDPractiseSelectResultCell *)practiseSelectResultCell didSelectSeq:(NSInteger)seq;

@end

@interface HDPractiseSelectResultCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *practiseTitleLabel;

/// 答案
@property (nonatomic, strong) NSArray *anwsers;

@property (nonatomic, weak) id<HDPractiseSelectResultCellDelegate> cellDelegate;

@end
