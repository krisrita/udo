//
//  HDAnswerCorrectCell.m
//  udo_stu
//
//  Created by nobody on 6/16/15.
//  All rights reserved.
//

#import "HDAnswerCorrectCell.h"

@implementation HDAnswerCorrectCell

-(void)setCellData:(id)cellData
{
    HDAnswerModel *answer = (HDAnswerModel *)cellData;
    self.currentAnswer = answer;
    
    [self.questionButton setTitle:[NSString stringWithFormat:@"%ld", (long)answer.questionSeq] forState:UIControlStateNormal];
    if (answer) {
        if (answer.isCorrect) {
            [self.questionButton setBackgroundImage:[UIImage imageNamed:@"ic_question_answered"] forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
        } else {
            [self.questionButton setBackgroundImage:[UIImage imageNamed:@"ic_answer_wrong"] forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
        }
    }
}

@end
