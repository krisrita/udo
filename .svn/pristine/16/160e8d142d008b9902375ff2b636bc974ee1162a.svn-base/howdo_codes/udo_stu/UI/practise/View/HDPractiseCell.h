//
//  HDPractiseCell.h
//  udo_stu
//
//  Created by nobody on 15/7/8.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPractiseCell;

@protocol HDPractiseCellDelegate <NSObject>

/// 选择了答案
- (void)practiseCellDidSelectedAnswer:(HDPractiseCell *)practiseCell;

@end

@interface HDPractiseCell : UICollectionViewCell

/// 试卷标题
@property (weak, nonatomic) IBOutlet UILabel *practiseTitleLabel;
/// 序号
@property (weak, nonatomic) IBOutlet UILabel *seqLabel;

@property (nonatomic, strong) HDQuestionModel *questionModel;

@property (nonatomic, weak) id<HDPractiseCellDelegate> cellDelegate;

@end
