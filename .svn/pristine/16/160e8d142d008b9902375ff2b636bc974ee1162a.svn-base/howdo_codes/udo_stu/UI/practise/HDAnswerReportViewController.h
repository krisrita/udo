//
//  HDAnswerReportViewController.h
//  udo_stu
//
//  Created by nobody on 6/15/15.
//  All rights reserved.All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDAnswerReportViewController : HDBaseViewController

@property (nonatomic, assign) HDPractiseType practiseType;
@property (nonatomic, strong) HDPractiseReportModel *practiseReportModel;
@property (nonatomic, strong) id chapterOrSectionModel;

@end
