//
//  HDPractiseSelectResultCell.m
//  udo_stu
//
//  Created by nobody on 15/7/9.
//   All rights reserved.
//

#import "HDPractiseSelectResultCell.h"
#import "HDAnswerCardView.h"

@interface HDPractiseSelectResultCell () <HDAnswerCardDelegate>

@property (nonatomic, weak) HDAnswerCardView *cardView;

@end

@implementation HDPractiseSelectResultCell

- (void)awakeFromNib {
    HDAnswerCardView *cardView = [[HDAnswerCardView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT + 40, APP_CONTENT_WIDTH, 250)];
    self.cardView = cardView;
    self.cardView.delegate = self;
//    self.cardView.answers = [[HDPractise currentPractise] getAnswers];
    [self.contentView addSubview:self.cardView];
    
    [self.cardView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(40.0);
        make.left.equalTo(self.contentView).offset(0);
        make.right.equalTo(self.contentView).offset(0);
        make.bottom.equalTo(self.contentView).offset(0);
    }];
}

- (void)setAnwsers:(NSArray *)anwsers {
    _anwsers = anwsers;
    self.cardView.answers = anwsers;
}

- (void)questionSeqSelected:(NSInteger)questionSeq {
    if ([self.cellDelegate respondsToSelector:@selector(practiseSelectResultCell:didSelectSeq:)]) {
        [self.cellDelegate practiseSelectResultCell:self didSelectSeq:questionSeq];
    }
}

- (void)submitAnswerClicked {
    if ([self.cellDelegate respondsToSelector:@selector(practiseSelectResultCellDidSubmitAnswer:)]) {
        [self.cellDelegate practiseSelectResultCellDidSubmitAnswer:self];
    }
}

@end
