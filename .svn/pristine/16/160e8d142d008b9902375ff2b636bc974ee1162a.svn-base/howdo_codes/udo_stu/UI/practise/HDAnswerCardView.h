//
//  HDAnswerCardView.h
//  udo_stu
//
//  Created by nobody on 6/14/15.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HDAnswerCardDelegate <NSObject>

- (void)questionSeqSelected:(NSInteger)questionSeq;
- (void)submitAnswerClicked;

@end

@interface HDAnswerCardView : UIView

@property (nonatomic, weak) id<HDAnswerCardDelegate> delegate;
@property (nonatomic, strong) NSArray *answers;

@end
