//
//  HDAnswerCardView.m
//  udo_stu
//
//  Created by nobody on 6/14/15.
//  All rights reserved.
//

#import "HDAnswerCardView.h"
#import "HDAnswerCell.h"

@interface HDAnswerCardView () <HDTableViewDelegate, HDTableViewCellDelegate>

@property (nonatomic, strong) UIButton *submitAnswerButton;
@property (nonatomic, strong) HDTableView *tableView;

@end

@implementation HDAnswerCardView

- (instancetype)init
{
    if (self = [super init]) {
        [self buildUI];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self buildUI];
    }
    return self;
}

- (void)dealloc
{
    self.answers = nil;
    self.submitAnswerButton = nil;
    self.tableView = nil;
}

- (void)buildUI
{
    WS(ws);
    self.backgroundColor = UIColorFromRGB(255, 255, 255);
    
    self.submitAnswerButton = [[UIButton alloc] init];
    [self.submitAnswerButton setBackgroundColor:UIColorFromRGB(34, 177, 139)];
    [self.submitAnswerButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateNormal];
    [self.submitAnswerButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
    [self.submitAnswerButton.titleLabel setFont:[UIFont boldSystemFontOfSize:16.0]];
    [self.submitAnswerButton setTitle:@"交卷并查看答题结果" forState:UIControlStateNormal];
    [self.submitAnswerButton addTarget:self action:@selector(submitAnswerClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.submitAnswerButton];
    
    [self.submitAnswerButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws).offset(0);
        make.right.equalTo(ws).offset(0);
        make.bottom.equalTo(ws).offset(0);
        make.height.equalTo(@(104/2));
    }];
    
    self.tableView = [[HDTableView alloc] initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, self.frame.size.height) cellClassName:[HDAnswerCell class] itemSize:CGSizeMake((self.frame.size.width-50)/5.0, (self.frame.size.width-50)/5.0) sectionInset:UIEdgeInsetsMake(50, 0, 0, 50) blankViewClass:[HDBlankPageView class] refreshType:HD_TABLE_REFRESH_NONE];
    self.tableView.hdTableViewDelegate = self;
    [self addSubview:self.tableView];
    
    [self bringSubviewToFront:self.submitAnswerButton];
}

- (void)setAnswers:(NSArray *)answers
{
    _answers = answers;
    [self.tableView setTableDataWithAry:self.answers];
}

- (void)submitAnswerClicked:(id)sender
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(submitAnswerClicked)]) {
        [self.delegate submitAnswerClicked];
    }
}

- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(questionSeqSelected:)]) {
        [self.delegate questionSeqSelected:tag];
    }
}

@end
