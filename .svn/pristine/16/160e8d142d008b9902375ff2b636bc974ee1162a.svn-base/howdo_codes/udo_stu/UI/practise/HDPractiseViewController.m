//
//  HDPractiseViewController.m
//  udo_stu
//
//  Created by nobody on 6/13/15.
//  All rights reserved.
//

#import "HDPractiseViewController.h"
#import "HDOptionCell.h"
#import "HDAnswerCardView.h"
#import "BSbottomModel.h"
#import "HDAnswerReportViewController.h"

@interface HDPractiseViewController () <HDPractiseDelegate, HDTableViewCellDelegate, HDTableViewDelegate, HDAnswerCardDelegate, UIWebViewDelegate, UIAlertViewDelegate>

@property (nonatomic, strong) UILabel *timerLabel;
@property (nonatomic, strong) UILabel *csNameLabel;
@property (nonatomic, strong) UILabel *seqLabel;
/// 题目
@property (nonatomic, strong) UIWebView *qWebView;
/// 选项
@property (nonatomic, strong) HDTableView *pTableView;
@property (nonatomic, strong) UIButton *answerCardButton;
@property (nonatomic, strong) HDAnswerCardView *cardView;

/// 当前题目
@property (nonatomic, strong) HDQuestionModel *currentQuestion;
@property (nonatomic, assign) BOOL isFirstQuestion;
@property (nonatomic, assign) BOOL isLastQuestion;

@end

@implementation HDPractiseViewController

#pragma mark - Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    WS(ws);
    self.leftView = [HDUICommon leftBackView:self];
    self.centerView = [HDUICommon getTitleView:HD_PRACTISE_TYPE_SECTION == self.practiseType ? @"随堂练习" : @"章节测试"];
    
    [self setupTimeView]; //时间视图
    
    // 顶部，名称
    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT, APP_CONTENT_WIDTH, 40)];
    self.csNameLabel = [[UILabel alloc] init];
    self.csNameLabel.font = [UIFont systemFontOfSize:15];
    self.csNameLabel.text = [self getChapterOrSectionName];
    [topView addSubview:self.csNameLabel];
    [self.csNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(topView).offset(45.5/2);
        make.right.equalTo(topView).offset(-80);
        make.top.equalTo(topView).offset(6.5);
        make.bottom.equalTo(topView).offset(-9.5);
    }];
    
    self.seqLabel = [[UILabel alloc] init];
    self.seqLabel.textAlignment = NSTextAlignmentRight;
    self.seqLabel.font = [UIFont systemFontOfSize:15];
    self.seqLabel.textColor = UIColorFromRGB(34, 177, 139);
    
    [topView addSubview:self.seqLabel];
    [self.seqLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws.csNameLabel.mas_right).offset(0);
        make.right.equalTo(topView).offset(-45.5/2);
        make.top.equalTo(topView).offset(6.5);
        make.bottom.equalTo(topView).offset(-9.5);
    }];
    
    UIImageView *topLineImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_practise_top_line"]];
    [topView addSubview:topLineImageView];
    [topLineImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(topView).offset(0);
        make.right.equalTo(topView).offset(0);
        make.bottom.equalTo(topView).offset(0);
    }];
    
    [self.view addSubview:topView];
    
    // 题目
    self.qWebView = [[UIWebView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT + topView.frame.size.height, APP_CONTENT_WIDTH, 30)];
//    self.qWebView.scalesPageToFit = YES;
    [self.qWebView setBackgroundColor:[UIColor redColor]];
    self.qWebView.scrollView.scrollEnabled = NO;
    self.qWebView.delegate = self;
    
    // 选项
    self.pTableView = [[HDTableView alloc] initDeleteStyleTableWithFrame:CGRectMake(0, APP_STATUS_HEIGHT + topView.frame.size.height, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT-APP_STATUS_HEIGHT) rowHeightType:HD_CELL_HEIGHT_TYPE_DYNAMIC cellClassName:[HDOptionCell class] blankViewClass:[HDBlankPageView class] refreshType:HD_TABLE_REFRESH_NONE];
    
    self.pTableView.hdTableViewDelegate = self;
    [self.view addSubview:self.pTableView];
    self.pTableView.headView = self.qWebView;
    
    // 右下角答题卡
    self.answerCardButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.answerCardButton setImage:[UIImage imageNamed:@"btn_answer_card"] forState:0];
    [self.answerCardButton addTarget:self action:@selector(answerCardClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.answerCardButton];
    [self.answerCardButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.view).offset(-14);
        make.bottom.equalTo(ws.view).offset(-13.5);
    }];
    
    [self initPractise]; // 获取数据
    
    // 添加手势
    UISwipeGestureRecognizer *recognizer;
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeFrom:)];
    [recognizer setDirection:(UISwipeGestureRecognizerDirectionRight)];
    [self.pTableView addGestureRecognizer:recognizer];
    
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeFrom:)];
    [recognizer setDirection:(UISwipeGestureRecognizerDirectionLeft)];
    [self.pTableView addGestureRecognizer:recognizer];
}

#pragma mark - Init View
- (void)setupTimeView {
    UIView *timerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 58.5, 44)];
    UIImageView *timerIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ic_practise_timer"]];
    [timerView addSubview:timerIcon];
    
    [timerIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(timerView).offset(4.5);
        make.right.equalTo(timerView).offset(-16.5);
    }];
    
    self.timerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 58, 44)];
    [self.timerLabel setTextAlignment:NSTextAlignmentRight];
    [self.timerLabel setTextColor:[UIColor whiteColor]];
    [self.timerLabel setText:@"00:00"];
    [timerView addSubview:self.timerLabel];
    
    [self.timerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(timerView).offset(-12);
        make.top.equalTo(timerView).offset(15);
    }];
    
    self.rightView = timerView;
}

#pragma mark - Network Request
- (void)initPractise
{
    self.answerCardButton.enabled = NO;
    [HDLoading startAnimating:@"正在准备练习题..."];
    
    // 创建一个HDPractise实例，并将传入的参数赋值到属性上
    [HDPractise createPractise:self.practiseType chapterOrSectionId:[self getChapterOrSectionId]];
    
    // 拿到上面创建的HDPractise实例设置代理
    [[HDPractise currentPractise] setPractiseDelegate:self];
    
    // 准备题目，里面请求网络
    [[HDPractise currentPractise] preparePractise:^(HDCommonResult *result) {
        [HDLoading stopAnimating];
        [[HDPractise currentPractise] startPractise]; //开始计时
        [self jumpToQuestion:1];
    }];
}

- (NSInteger)getChapterOrSectionId
{
    NSInteger Id = 0;
    
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            Id = chapter.Id;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            Id = section.Id;
        }
    }
    
    return Id;
}

- (NSString *)getChapterOrSectionName
{
    NSString *name = @"";
    
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            name = chapter.name;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            name = section.name;
        }
    }
    
    return name;
}

- (void)setPractiseCompleted
{
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            chapter.hasPracticed = YES;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            section.hasPracticed = YES;
        }
    }
}

- (void)jumpToQuestion:(NSInteger)questionSeq
{
    __weak __typeof(self)weakSelf = self;
    [[HDPractise currentPractise] jumpToQuestion:questionSeq resultBack:^(BOOL isFirst, BOOL isFinished, HDQuestionModel *question) {
        if (!weakSelf) return;
        // 拿到question模型
        __strong __typeof(weakSelf)strongSelf = weakSelf;
        strongSelf.isFirstQuestion = isFirst;
        strongSelf.isLastQuestion = isFinished;
        strongSelf.currentQuestion = question;
        dispatch_async(dispatch_get_main_queue(), ^{
            [strongSelf showQuestion:strongSelf.currentQuestion];
            strongSelf.answerCardButton.enabled = YES;
        });
    }];
}

#pragma mark - 下一题
- (void)nextQuestion
{
    if (self.isLastQuestion) {
        
        self.cardView = [[HDAnswerCardView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT + 40, APP_CONTENT_WIDTH, 250)];
        self.cardView.delegate = self;
        self.cardView.answers = [[HDPractise currentPractise] getAnswers];
        [self.view addSubview:self.cardView];
        [self.view bringSubviewToFront:self.cardView];
        
        self.pTableView.hidden = YES;
        
        WS(ws);
        [self.cardView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(ws.pTableView.mas_top).offset(0);
            make.left.equalTo(ws.view).offset(0);
            make.right.equalTo(ws.view).offset(0);
            make.bottom.equalTo(ws.view).offset(0);
        }];
        
        self.seqLabel.attributedText = nil;
        
        return;
    }
    
    __weak __typeof(self)weakSelf = self;
    [[HDPractise currentPractise] nextQuestion:^(BOOL isFirst, BOOL isFinished, HDQuestionModel *question) {
        __strong __typeof(weakSelf)strongSelf = weakSelf;
        strongSelf.isFirstQuestion = isFirst;
        strongSelf.isLastQuestion = isFinished;
        strongSelf.currentQuestion = question;
        dispatch_async(dispatch_get_main_queue(), ^{
            [strongSelf showQuestion:strongSelf.currentQuestion];
        });
    }];
}

- (void)prevQuestion
{
    if (self.isFirstQuestion) {
        return;
    }
    
    __weak __typeof(self)weakSelf = self;
    [[HDPractise currentPractise] prevQuestion:^(BOOL isFirst, BOOL isFinished, HDQuestionModel *question) {
        __strong __typeof(weakSelf)strongSelf = weakSelf;
        strongSelf.isFirstQuestion = isFirst;
        strongSelf.isLastQuestion = isFinished;
        strongSelf.currentQuestion = question;
        dispatch_async(dispatch_get_main_queue(), ^{
            [strongSelf showQuestion:strongSelf.currentQuestion];
        });
    }];
}

#pragma mark 将题目显示到界面上
- (void)showQuestion:(HDQuestionModel *)question
{
    [self setSeqInfo:question.seq]; //设置右上角题号 1/1之类的
    
    if (question.content && question.content.length > 0) {
        [self.qWebView loadHTMLString:question.content baseURL:nil];
    } else {
        [self.qWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:question.url]]];
    }
    [self.pTableView setTableDataWithAry:question.options];
}

#pragma mark 设置右上角题号 1/1之类的
- (void)setSeqInfo:(NSInteger)seq
{
    NSString *seq_str = [NSString stringWithFormat:@"%ld", (long)seq];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@/%ld", seq_str, (long)[HDPractise currentPractise].questionNum]];
    [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:20] range:NSMakeRange(0, seq_str.length)];
    self.seqLabel.attributedText = str;
}

- (void)answerCardClicked:(UIButton *)sender
{
    self.cardView = [[HDAnswerCardView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT + 40, APP_CONTENT_WIDTH, 250)];
    self.cardView.delegate = self;
    self.cardView.answers = [[HDPractise currentPractise] getAnswers];
    
    BSbottomModel *model = [BSbottomModel sharedInstance];
    model.backgroundDisplayStyle = BSModalBackgroundDisplayStyleSolid;
    model.showCloseButton = NO;
    [[BSbottomModel sharedInstance] showWithContentView:self.cardView
                                            andAnimated:YES
                                              showBlock:^{
                                                  self.answerCardButton.hidden = YES;
                                              }
                                           dismissBlock:^{
                                               self.answerCardButton.hidden = NO;
                                               [self.cardView removeFromSuperview];
                                               self.cardView = nil;
                                           }];
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
}

- (void)viewWillAppear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = NO;
}

- (void)viewWillDisappear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = YES;
}

- (void)dealloc
{
    self.pTableView = nil;
    self.currentQuestion = nil;
}

- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)onTimer:(NSInteger)minutes seconds:(NSInteger)seconds
{
    self.timerLabel.text = [NSString stringWithFormat:@"%02ld:%02ld", (long)minutes, (long)seconds];
}

#pragma mark - UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    CGRect frame = webView.frame;
    frame.size.height = 1;
    webView.frame = frame;
    
    frame.size = [webView sizeThatFits:CGSizeZero];
    webView.frame = frame;
    
    self.pTableView.headView = webView;
}

- (IBAction)handleSwipeFrom:(UISwipeGestureRecognizer *)sender
{
    if (UISwipeGestureRecognizerDirectionLeft == sender.direction) {
        HDLogInfo(@"UISwipeGestureRecognizerDirectionLeft");
        [self nextQuestion];
    }
    else if (UISwipeGestureRecognizerDirectionRight == sender.direction) {
        HDLogInfo(@"UISwipeGestureRecognizerDirectionRight");
        [self prevQuestion];
    }
}

- (void)HDTableviewRefresh
{
    [self.pTableView refresh];
}

- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag
{
    for(HDOptionModel *option in self.currentQuestion.options) {
        if (option.Id != tag) {
            option.selected = NO;
        }
    }
    self.currentQuestion.optionId = tag;
    [self.pTableView refresh];
    
    double delayInSeconds = .3;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self nextQuestion];
    });
}

#pragma mark -HDAnswerCard Delegate

- (void)hideAnswerCard:(BOOL)animated
{
    [[BSbottomModel sharedInstance]hideAnimated:animated dismissBlock:^{
        self.answerCardButton.hidden = NO;
        [self.cardView removeFromSuperview];
        self.cardView = nil;
        
        if (self.pTableView.hidden) {
            self.pTableView.hidden = NO;
        }
    }];
}

- (void)questionSeqSelected:(NSInteger)questionSeq
{
    [self jumpToQuestion:questionSeq];
    [self hideAnswerCard:YES];
}

#pragma mark 点击了底部的交卷
- (void)submitAnswerClicked
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"是否确认交卷" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    [alertView show];
}

#pragma mark UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) return;
    [[HDPractise currentPractise] stopPractise];
    [HDLoading startAnimating:@"正在提交答题结果..."];
    [[HDPractise currentPractise] submitAnswers:^(HDCommonResult *result) {
        if (HD_RESULT_CODE_SUCCESS == result.resultCode) {
            [self hideAnswerCard:NO];
            [HDLoading stopAnimating];
            [self setPractiseCompleted];
            [[HDPractiseProxy sharedInstance] showPractiseReport:self practiseType:self.practiseType chapterOrSection:self.chapterOrSectionModel];
        }
        else {
            [HDTip showSystemAlartTitle:@"提交失败" message:@"提交答题结果失败，请再试一次"];
        }
    }];
}

@end
