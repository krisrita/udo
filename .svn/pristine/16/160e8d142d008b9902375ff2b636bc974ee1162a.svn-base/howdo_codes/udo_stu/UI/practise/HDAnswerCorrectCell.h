//
//  HDAnswerCorrectCell.h
//  udo_stu
//
//  Created by nobody on 6/16/15.
//  All rights reserved.
//

#import "HDAnswerCell.h"

@interface HDAnswerCorrectCell : HDAnswerCell

@end
