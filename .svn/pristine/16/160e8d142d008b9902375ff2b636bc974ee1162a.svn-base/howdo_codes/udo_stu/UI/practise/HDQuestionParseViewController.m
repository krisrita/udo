//
//  HDQuestionParseViewController.m
//  udo_stu
//
//  Created by nobody on 6/16/15.
//  All rights reserved.
//

#import "HDQuestionParseViewController.h"
#import "HDVideoViewController.h"
#import "HDNetworkConfig.h"

@interface HDQuestionParseViewController () <UIWebViewDelegate>

@property (nonatomic, strong) NSString *baseUrl;
@property (nonatomic, strong) UILabel *csNameLabel;
@property (nonatomic, strong) UILabel *seqLabel;
@property (nonatomic, strong) UIButton *watchVideoButton;
@property (nonatomic, strong) UIWebView *leftWebView;
@property (nonatomic, strong) UIWebView *rightWebView;
@property (nonatomic, strong) UIWebView *webView;

@end

@implementation HDQuestionParseViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    WS(ws);
    self.leftView = [HDUICommon leftBackView:self];
    
    self.centerView = [HDUICommon getTitleView:HD_PRACTISE_TYPE_SECTION == self.practiseType ? @"随堂练习" : @"章节测试"];
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:[UIImage imageNamed:@"btn_share_default"] forState:UIControlStateNormal];
    [rightButton setFrame:CGRectMake(0, 0, 44, 44)];
    [rightButton addTarget:self action:@selector(shareClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.rightView = rightButton;
    
    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT, APP_CONTENT_WIDTH, 40)];
    self.csNameLabel = [[UILabel alloc] init];
    self.csNameLabel.font = [UIFont systemFontOfSize:15];
    self.csNameLabel.text = [self getChapterOrSectionName];
    [topView addSubview:self.csNameLabel];
    [self.csNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(topView).offset(45.5/2);
        make.right.equalTo(topView).offset(-80);
        make.top.equalTo(topView).offset(6.5);
        make.bottom.equalTo(topView).offset(-9.5);
    }];
    
    self.seqLabel = [[UILabel alloc] init];
    self.seqLabel.textAlignment = NSTextAlignmentRight;
    self.seqLabel.font = [UIFont systemFontOfSize:15];
    self.seqLabel.textColor = UIColorFromRGB(34, 177, 139);
    
    [topView addSubview:self.seqLabel];
    [self.seqLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws.csNameLabel.mas_right).offset(0);
        make.right.equalTo(topView).offset(-45.5/2);
        make.top.equalTo(topView).offset(6.5);
        make.bottom.equalTo(topView).offset(-9.5);
    }];
    
    UIImageView *topLineImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_practise_top_line"]];
    [topView addSubview:topLineImageView];
    [topLineImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(topView).offset(0);
        make.right.equalTo(topView).offset(0);
        make.bottom.equalTo(topView).offset(0);
    }];
    
    [self.view addSubview:topView];
    
    _leftWebView = [[UIWebView alloc] init];
    [self.view addSubview:_leftWebView];
    [_leftWebView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView.mas_bottom).offset(0);
        make.left.equalTo(ws.view).offset(0);
        make.right.equalTo(ws.view).offset(0);
        make.bottom.equalTo(ws.view).offset(0);
    }];
    _leftWebView.hidden = YES;
    
    _webView = [[UIWebView alloc] init];
    [self.view addSubview:_webView];
    [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView.mas_bottom).offset(0);
        make.left.equalTo(ws.view).offset(0);
        make.right.equalTo(ws.view).offset(0);
        make.bottom.equalTo(ws.view).offset(0);
    }];
    _webView.delegate = self;
    
    _rightWebView = [[UIWebView alloc] init];
    [self.view addSubview:_rightWebView];
    [_rightWebView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView.mas_bottom).offset(0);
        make.left.equalTo(ws.view).offset(0);
        make.right.equalTo(ws.view).offset(0);
        make.bottom.equalTo(ws.view).offset(0);
    }];
    _rightWebView.hidden = YES;
    
    self.watchVideoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.watchVideoButton setImage:[UIImage imageNamed:@"btn_watch_video"] forState:0];
    [self.watchVideoButton addTarget:self action:@selector(watchVideoClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.watchVideoButton];
    [self.watchVideoButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.view).offset(-14);
        make.bottom.equalTo(ws.view).offset(-13.5);
    }];

    UISwipeGestureRecognizer *recognizer;
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeFrom:)];
    [recognizer setDirection:(UISwipeGestureRecognizerDirectionRight)];
    [self.view addGestureRecognizer:recognizer];
    
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeFrom:)];
    [recognizer setDirection:(UISwipeGestureRecognizerDirectionLeft)];
    [self.view addGestureRecognizer:recognizer];
    
    id<HDNetworkConfigDelegate> networkConfig = [[HDNetworkConfig alloc] init];
    self.baseUrl = [networkConfig getHttpServiceBaseUrl];
    
    [self initPractiseParse];
}

- (void)initPractiseParse
{
    [HDLoading startAnimating:@"准备解析中..."];
    [_webView loadRequest:[self getParseRequest:self.currentIndex]];
    [self showSeqInfo];
    
    if (![self isFirst]) {
        [_leftWebView loadRequest:[self getParseRequest:self.currentIndex - 1]];
    }
    
    if (![self isFinished]) {
        [_rightWebView loadRequest:[self getParseRequest:self.currentIndex + 1]];
    }
}

- (NSURLRequest *)getParseRequest:(NSInteger)index
{
    
    if (index < 1 || index > [self.answers count]) {
        return nil;
    }
    HDAnswerModel *answer = (HDAnswerModel *)[self.answers objectAtIndex:index-1];
    // self.baseUrl = http://182.92.110.119/
    //
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@practise/parse/section_id/%ld/seq/%ld?platform=ios&uid=%ld", self.baseUrl, (long)[self getChapterOrSectionId], (long)answer.questionSeq, (long)([HDManager sharedInstance].isLogined ? [HDManager sharedInstance].currentUser.Id : 0)]]];
    // 课程http://182.92.110.119/practise/parse/section_id/4740/seq/1?platform=ios&uid=12417
    NSLog(@"课程%@", request.URL);
    return request;
}

- (BOOL)isFirst
{
    return (self.currentIndex <= 1);
}

- (BOOL)isFinished
{
    return (self.currentIndex >= [self.answers count]);
}

- (NSInteger)getChapterOrSectionId
{
    NSInteger Id = 0;
    
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            Id = chapter.Id;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            Id = section.Id;
        }
    }
    
    return Id;
}

- (NSString *)getChapterOrSectionName
{
    NSString *name = @"";
    
    if (self.chapterOrSectionModel) {
        if ([self.chapterOrSectionModel isKindOfClass:[HDChapterModel class]]) {
            HDChapterModel *chapter = (HDChapterModel *)self.chapterOrSectionModel;
            name = chapter.name;
        }
        else if ([self.chapterOrSectionModel isKindOfClass:[HDSectionModel class]]) {
            HDSectionModel *section = (HDSectionModel *)self.chapterOrSectionModel;
            name = section.name;
        }
    }
    
    return name;
}

#pragma mark UIWebViewDelegate
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    webView.hidden = YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    webView.hidden = NO;
    [HDLoading stopAnimating];
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
}

- (void)dealloc
{
    self.answers = nil;
    self.chapterOrSectionModel = nil;
    self.leftWebView = nil;
    self.rightWebView = nil;
    self.webView = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = NO;
}

- (void)viewWillDisappear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = YES;
}

- (IBAction)handleSwipeFrom:(UISwipeGestureRecognizer *)sender
{
    if (UISwipeGestureRecognizerDirectionLeft == sender.direction) {
        HDLogInfo(@"UISwipeGestureRecognizerDirectionLeft");
        if ([self isFinished]) {
            return;
        }
        CGRect frame = _rightWebView.frame;
        frame.origin.x = APP_CONTENT_WIDTH;
        _rightWebView.frame = frame;
        _rightWebView.hidden = NO;
        [self.view bringSubviewToFront:_rightWebView];
        [self.view bringSubviewToFront:self.watchVideoButton];
        [UIView animateWithDuration:0.5
                              delay:0.0
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             CGRect frame = _rightWebView.frame;
                             frame.origin.x = 0;
                             _rightWebView.frame = frame;
                         } completion:^(BOOL finished) {
                             [UIView animateWithDuration:1
                                              animations:^{
                                              }
                                              completion:^(BOOL finished) {
                                                  [self switchToNext];
                                              }];
                         }];

    }
    else if (UISwipeGestureRecognizerDirectionRight == sender.direction) {
        HDLogInfo(@"UISwipeGestureRecognizerDirectionRight");
        if ([self isFirst]) {
            return;
        }
        CGRect frame = _leftWebView.frame;
        frame.origin.x = 0;
        _leftWebView.frame = frame;
        _leftWebView.hidden = NO;
        [self.view bringSubviewToFront:self.watchVideoButton];
        [UIView animateWithDuration:0.5
                              delay:0.0
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             CGRect frame = _webView.frame;
                             frame.origin.x = APP_CONTENT_WIDTH;
                             _webView.frame = frame;
                         } completion:^(BOOL finished) {
                             [UIView animateWithDuration:1
                                              animations:^{
                                              }
                                              completion:^(BOOL finished) {
                                                  [self switchToPrev];
                                              }];
                         }];
    }
}

- (void)switchToNext
{
    _webView.hidden = YES;
    UIWebView *tempView = _leftWebView;
    _leftWebView = _webView;
    _webView = _rightWebView;
    _rightWebView = tempView;
    
    self.currentIndex++;
    [self showSeqInfo];
    if (![self isFinished]) {
        [_rightWebView loadRequest:[self getParseRequest:self.currentIndex + 1]];
    }
    
}

- (void)switchToPrev
{
    [self.view sendSubviewToBack:_rightWebView];
    
    _webView.hidden = YES;
    UIWebView *tempView = _rightWebView;
    _rightWebView = _webView;
    _webView = _leftWebView;
    _leftWebView = tempView;
    
    self.currentIndex--;
    [self showSeqInfo];
    if (![self isFirst]) {
        [_leftWebView loadRequest:[self getParseRequest:self.currentIndex - 1]];
    }
}

- (void)showSeqInfo
{
    if (self.currentIndex < 1 || self.currentIndex > [self.answers count]) {
        return;
    }
    
    HDAnswerModel *answer = (HDAnswerModel *)[self.answers objectAtIndex:self.currentIndex - 1];
    
    NSString *seq_str = [NSString stringWithFormat:@"%ld", (long)answer.questionSeq];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@/%ld", seq_str, (long)[self.answers count]]];
    [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:20] range:NSMakeRange(0, seq_str.length)];
    self.seqLabel.attributedText = str;
}

- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)shareClicked:(id)sender
{
    [[HDShareProxy sharedInstance]share:self title:SHARE_TITLE text:SHARE_CONTENT imageUrl:SHARE_IMAGE_URL image:nil resourceUrl:[HDNetworkConfig getModuleUrl:URL_TYPE_SHARE] completion:^(HDCommonResult *result) {
        [HDTip showMessage:@"分享成功"];
    } viewPoped:nil viewDissMissed:nil];
}

- (void)watchVideoClicked:(id)sender
{
    HDAnswerModel *answerModel = [self.answers objectAtIndex:self.currentIndex - 1];
    if (answerModel.videoId <= 0) {
        [HDLoading startAnimating:@"暂无视频"];
        [HDLoading stopAnimating:@"暂无视频"];
        return;
    }
    
    [[HDVideoProxy sharedInstance] showVideo:self chapterOrSectionModel:self.chapterOrSectionModel answerModel:answerModel];
}


@end
