//
//  HDPractiseController.h
//  udo_stu
//
//  Created by nobody on 15/7/8.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDPractiseController : HDBaseViewController

/// 节信息
@property (nonatomic, strong) HDSectionModel *sectionModel;

@property (nonatomic, assign) HDPractiseType practiseType;

@end
