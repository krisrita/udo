//
//  HDAnswerReportViewController.m
//  udo_stu
//
//  Created by nobody on 6/15/15.
//  All rights reserved.All rights reserved.
//

#import "HDAnswerReportViewController.h"
#import "HDBaseViewController.h"
#import "HDQuestionParseViewController.h"
#import "HDAnswerCorrectCell.h"

@interface HDAnswerReportViewController () <HDTableViewDelegate, HDTableViewCellDelegate>

/// 课程名称(顶部)
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *completionTimeLabel;
@property (nonatomic, strong) UILabel *correctRateLabel;
@property (nonatomic, strong) UILabel *spentTimeLabel;
@property (nonatomic, strong) UILabel *rankLabel;
@property (nonatomic, strong) HDTableView *tableView;
@property (nonatomic, strong) UIButton *wrongParseButton;

/// 练习名称尺寸
@property (nonatomic, assign) CGSize titleLabelSize;

@end

@implementation HDAnswerReportViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    WS(ws);
    self.leftView = [HDUICommon leftBackView:self];
    self.centerView = [HDUICommon getTitleView:@"答题报告"];
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:[UIImage imageNamed:@"btn_share_default"] forState:UIControlStateNormal];
    [rightButton setFrame:CGRectMake(0, 0, 44, 44)];
    [rightButton addTarget:self action:@selector(shareClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.rightView = rightButton;
    
    UIView *bottomView = [[UIView alloc] init];
    bottomView.backgroundColor = UIColorFromRGB(34, 177, 139);
    [self.view addSubview:bottomView];
    
    _wrongParseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _wrongParseButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [_wrongParseButton setBackgroundColor:UIColorFromRGB(34, 177, 139)];
    [_wrongParseButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateNormal];
    [_wrongParseButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
    [_wrongParseButton setTitleColor:UIColorFromRGB(120, 120, 120) forState:UIControlStateDisabled];
    [_wrongParseButton.titleLabel setFont:[UIFont boldSystemFontOfSize:16.0]];
    [_wrongParseButton setTitle:@"错题解析" forState:UIControlStateNormal];
    [_wrongParseButton addTarget:self action:@selector(wrongParseClicked:) forControlEvents:UIControlEventTouchUpInside];
    [bottomView addSubview:_wrongParseButton];
    _wrongParseButton.enabled = NO;
    
    UIButton *allParseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    allParseButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [allParseButton setBackgroundColor:UIColorFromRGB(34, 177, 139)];
    [allParseButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateNormal];
    [allParseButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
    [allParseButton.titleLabel setFont:[UIFont boldSystemFontOfSize:16.0]];
    [allParseButton setTitle:@"全部解析" forState:UIControlStateNormal];
    [allParseButton addTarget:self action:@selector(allParseClicked:) forControlEvents:UIControlEventTouchUpInside];
    [bottomView addSubview:allParseButton];
    
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws.view).offset(0);
        make.right.equalTo(ws.view).offset(0);
        make.bottom.equalTo(ws.view).offset(0);
        make.height.equalTo(@(104/2));
    }];
    
    [_wrongParseButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(bottomView).offset(0);
        make.right.equalTo(bottomView).offset(-(APP_CONTENT_WIDTH/2));
        make.top.equalTo(bottomView).offset(0);
        make.bottom.equalTo(bottomView).offset(0);
    }];
    
    [allParseButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(bottomView).offset(APP_CONTENT_WIDTH/2);
        make.right.equalTo(bottomView).offset(0);
        make.top.equalTo(bottomView).offset(0);
        make.bottom.equalTo(bottomView).offset(0);
    }];
    
    self.tableView = [[HDTableView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT, APP_CONTENT_WIDTH, APP_SCREEN_HEIGHT-APP_STATUS_HEIGHT - 52) cellClassName:[HDAnswerCorrectCell class] itemSize:CGSizeMake((self.view.frame.size.width-50)/5.0, (self.view.frame.size.width-50)/5.0) sectionInset:UIEdgeInsetsMake(50, 0, 0, 50) blankViewClass:[HDBlankPageView class] refreshType:HD_TABLE_REFRESH_NONE];
    self.tableView.hdTableViewDelegate = self;
    self.tableView.backgroundColor = UIColorFromRGB(255, 255, 255);
    [self.view addSubview:self.tableView];
    
    self.tableView.headView = [self createHeadView]; // 顶部
    
    self.tableView.tableViewEdgeinsets = UIEdgeInsetsMake(373 + self.titleLabelSize.height, 0, 0,0);
    
    [self setPractiseReportData:self.practiseReportModel];
    
    [self.view bringSubviewToFront:bottomView];
}

- (UIView *)createHeadView
{
//    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, -395, APP_CONTENT_WIDTH, 395)];
    UIView *headView = [[UIView alloc] init];
    headView.backgroundColor = UIColorFromRGB(255, 255, 255);
    
    // 练习名称和答题时间
    UIView *topView = [[UIView alloc] init];
    topView.backgroundColor = UIColorFromRGB(26, 120, 97);
    [headView addSubview:topView];
    
    _titleLabel = [[UILabel alloc] init];
    _titleLabel.numberOfLines = 0;
    _titleLabel.text = [NSString stringWithFormat:@"练习名称：%@", self.practiseReportModel.name];
    _titleLabel.font = [UIFont boldSystemFontOfSize:12.0];
    //    _titleLabel.textColor = UIColorFromRGB(255, 255, 255);
    [topView addSubview:_titleLabel];
    
    _completionTimeLabel = [[UILabel alloc] init];
    _completionTimeLabel.font = [UIFont boldSystemFontOfSize:12.0];
    //    _completionTimeLabel.textColor = UIColorFromRGB(255, 255, 255);
    [topView addSubview:_completionTimeLabel];
    
    // 正确率和用时
    UIView *topView2 = [[UIView alloc] init];
    topView2.backgroundColor = UIColorFromRGB(34, 177, 139);
    [headView addSubview:topView2];
    
    UILabel *label1 = [[UILabel alloc] init];
    label1.font = [UIFont boldSystemFontOfSize:12.0];
    label1.textColor = UIColorFromRGB(255, 255, 255);
    label1.textAlignment = NSTextAlignmentCenter;
    label1.text = [NSString stringWithFormat:@"正确率"];
    [topView2 addSubview:label1];
    
    UILabel *label2 = [[UILabel alloc] init];
    label2.font = [UIFont boldSystemFontOfSize:12.0];
    label2.textColor = UIColorFromRGB(255, 255, 255);
    label2.textAlignment = NSTextAlignmentCenter;
    label2.text = [NSString stringWithFormat:@"用　时"];
    [topView2 addSubview:label2];
    
    _correctRateLabel = [[UILabel alloc] init];
    _correctRateLabel.font = [UIFont boldSystemFontOfSize:63.0];
    _correctRateLabel.textColor = UIColorFromRGB(255, 255, 255);
    _correctRateLabel.textAlignment = NSTextAlignmentCenter;
    [topView2 addSubview:_correctRateLabel];
    
    _spentTimeLabel = [[UILabel alloc] init];
    _spentTimeLabel.font = [UIFont boldSystemFontOfSize:63.0];
    _spentTimeLabel.textColor = UIColorFromRGB(255, 255, 255);
    _spentTimeLabel.textAlignment = NSTextAlignmentCenter;
    [topView2 addSubview:_spentTimeLabel];
    
    // 练习名称
    NSDictionary *attributes = @{NSFontAttributeName : _titleLabel.font,
                                 };
    CGSize titleLabelSize = [_titleLabel.text boundingRectWithSize:CGSizeMake(APP_CONTENT_WIDTH - 36.0, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes context:nil].size;
    titleLabelSize.height += 8;
    self.titleLabelSize = titleLabelSize;
    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView).offset(2);
        make.left.equalTo(topView).offset(36);
        make.right.equalTo(topView).offset(0);
//        make.height.equalTo(@(43/2));
        make.height.equalTo(@(titleLabelSize.height));
    }];
    
    [_completionTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(topView).offset(36);
        make.right.equalTo(topView).offset(0);
        make.bottom.equalTo(topView).offset(-2);
        make.height.equalTo(@(43/2)); //22
    }];
    
    
    // topview
    [topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(headView).offset(0);
        make.left.equalTo(headView).offset(0);
        make.right.equalTo(headView).offset(0);
        make.height.equalTo(@(titleLabelSize.height + 22.0));
//        make.height.equalTo(@100);
    }];
    
    
    [topView2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView.mas_bottom).offset(0);
        make.left.equalTo(headView).offset(0);
        make.right.equalTo(headView).offset(0);
        make.height.equalTo(@(198));
    }];
    
    [label1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView2).offset(33);
        make.left.equalTo(topView2).offset(0);
        make.height.equalTo(@(25));
        make.width.equalTo(@(APP_CONTENT_WIDTH/2));
    }];
    
    [label2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView2).offset(33);
        make.right.equalTo(topView2).offset(0);
        make.height.equalTo(@(25));
        make.width.equalTo(@(APP_CONTENT_WIDTH/2+13));
    }];
    
    [_correctRateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView2).offset(20);
        make.left.equalTo(topView2).offset(0);
        make.bottom.equalTo(topView2).offset(0);
        make.width.equalTo(@(APP_CONTENT_WIDTH/2));
    }];
    
    [_spentTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView2).offset(20);
        make.right.equalTo(topView2).offset(0);
        make.bottom.equalTo(topView2).offset(0);
        make.width.equalTo(@(APP_CONTENT_WIDTH/2+13));
    }];
    
    _rankLabel = [[UILabel alloc] init];
    _rankLabel.font = [UIFont boldSystemFontOfSize:12.0];
    _rankLabel.numberOfLines = 0;
    [headView addSubview:_rankLabel];
    
    UIImageView *lineImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_practise_top_line"]];
    [headView addSubview:lineImageView];
    
    UILabel *cardLabel = [[UILabel alloc] init];
    cardLabel.font = [UIFont boldSystemFontOfSize:12.0];
    cardLabel.text = @"答题卡";
    [headView addSubview:cardLabel];
    
    [_rankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView2.mas_bottom).offset(0);
        make.left.equalTo(headView).offset(39);
        make.right.equalTo(headView).offset(0);
        make.height.equalTo(@(118));
    }];
    
    [lineImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_rankLabel.mas_bottom).offset(0);
        make.left.equalTo(headView).offset(0);
        make.right.equalTo(headView).offset(0);
    }];
    
    [cardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lineImageView.mas_bottom).offset(15);
        make.left.equalTo(headView).offset(39);
        make.right.equalTo(headView).offset(0);
    }];
    
    headView.frame = CGRectMake(0, -(373 + titleLabelSize.height), APP_CONTENT_WIDTH, 373 + titleLabelSize.height);
    return headView;
}

- (void)setPractiseReportData:(HDPractiseReportModel *)reportData
{
    _completionTimeLabel.text = [NSString stringWithFormat:@"答题时间：%@", reportData.completionTime];
    _correctRateLabel.text = reportData.correctRate;
    _spentTimeLabel.text = reportData.spentTime;
    
    NSString *rankHonor = [NSString stringWithFormat:@"你获得了“%@”称号", reportData.rankHonor];
    NSMutableString *rankSummary = [NSMutableString string];
    [rankSummary appendString:@"本次练习中\n"];
    [rankSummary appendFormat:@"你的答题正确率击败了%@的学生\n", reportData.correctRateBeatRate];
    [rankSummary appendFormat:@"你的答题时间击败了%@的学生\n", reportData.spentTimeBeatRate];
    [rankSummary appendFormat:@"综合排名：%@　", reportData.totalRank];
    [rankSummary appendString:rankHonor];
    
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:rankSummary];
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:8];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [rankSummary length])];
    [attributedString addAttribute:(NSString *)NSForegroundColorAttributeName
                              value:UIColorFromRGB(34, 177, 139)
                              range:NSMakeRange(rankSummary.length-rankHonor.length, rankHonor.length)];
    _rankLabel.attributedText = attributedString;
    
    [self.tableView setTableDataWithAry:reportData.answers];
    
    for (HDAnswerModel *answer in reportData.answers) {
        if (!answer.isCorrect) {
            _wrongParseButton.enabled = YES;
            break;
        }
    }
    
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
}

- (void)viewWillAppear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = NO;
}

- (void)viewWillDisappear:(BOOL)animated
{
    ((MLNavigationController *)self.navigationController).canDragBack = YES;
}

- (void)dealloc
{
}

- (void)back:(UIButton *)btn
{
    for (UIViewController *viewController in [self.navigationController viewControllers]) {
        if ([viewController isKindOfClass:[HDBaseViewController class]] && TAG_PRACTISE_REPORT_BACK_TO == ((HDBaseViewController *)viewController).tag) {
            [self.navigationController popToViewController:viewController animated:YES];
            return;
        }
    }
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)shareClicked:(id)sender
{
    [[HDShareProxy sharedInstance]share:self title:SHARE_TITLE text:SHARE_CONTENT imageUrl:SHARE_IMAGE_URL image:nil resourceUrl:[HDNetworkConfig getModuleUrl:URL_TYPE_SHARE] completion:^(HDCommonResult *result) {
        [HDTip showMessage:@"分享成功"];
    } viewPoped:nil viewDissMissed:nil];
}

- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag
{
    [self showQuestionParse:tag answers:self.practiseReportModel.answers];
}

- (void)wrongParseClicked:(id)sender
{
    NSMutableArray *wrongAnswers = [NSMutableArray array];
    for (HDAnswerModel *answer in self.practiseReportModel.answers) {
        if (!answer.isCorrect) {
            [wrongAnswers addObject:answer];
        }
    }
    
    [self showQuestionParse:1 answers:wrongAnswers];
}

- (void)allParseClicked:(id)sender
{
    [self showQuestionParse:1 answers:self.practiseReportModel.answers];
}

#pragma mark - 跳转答案解析
- (void)showQuestionParse:(NSInteger)index answers:(NSArray *)answers
{
    HDQuestionParseViewController *parseViewController = [[HDQuestionParseViewController alloc]init];
    parseViewController.practiseType = self.practiseType;
    parseViewController.chapterOrSectionModel = self.chapterOrSectionModel;
    parseViewController.answers = answers;
    parseViewController.currentIndex = index;
    [self.navigationController pushViewController:parseViewController animated:YES];
}

@end
