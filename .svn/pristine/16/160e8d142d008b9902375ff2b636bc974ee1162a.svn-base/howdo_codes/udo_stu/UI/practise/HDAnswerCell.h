//
//  HDAnswerCell.h
//  udo_stu
//
//  Created by nobody on 6/14/15.
//  All rights reserved.
//

#import "HDCollectionViewCell.h"

@interface HDAnswerCell : HDCollectionViewCell

@property (nonatomic, strong) UIButton *questionButton;
@property (nonatomic, strong) HDAnswerModel *currentAnswer;

@end