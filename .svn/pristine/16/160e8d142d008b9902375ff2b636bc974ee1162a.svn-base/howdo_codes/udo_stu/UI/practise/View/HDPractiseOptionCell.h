//
//  HDPractiseOptionCell.h
//  udo_stu
//
//  Created by nobody on 15/7/8.
//   All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPractiseOptionCell;

@protocol HDPractiseOptionCellDelegate <NSObject>

- (void)practiseOptionCellDidClickCheckButton:(HDPractiseOptionCell *)practiseOptionCell;

@end

@interface HDPractiseOptionCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *checkButton;
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@property (nonatomic, strong) HDOptionModel *optionModel;

- (IBAction)ClickCheckButton:(UIButton *)sender;

@property (nonatomic, weak) id<HDPractiseOptionCellDelegate> cellDelegate;

@end
