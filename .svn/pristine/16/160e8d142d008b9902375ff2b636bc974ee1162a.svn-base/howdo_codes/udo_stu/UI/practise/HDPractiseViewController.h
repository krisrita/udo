//
//  HDPractiseViewController.h
//  udo_stu
//
//  Created by nobody on 6/13/15.
//  All rights reserved.
//

#import "HDBaseViewController.h"

/// 随堂练习
@interface HDPractiseViewController : HDBaseViewController

@property (nonatomic, assign) HDPractiseType practiseType;
@property (nonatomic, strong) id chapterOrSectionModel;

@end
