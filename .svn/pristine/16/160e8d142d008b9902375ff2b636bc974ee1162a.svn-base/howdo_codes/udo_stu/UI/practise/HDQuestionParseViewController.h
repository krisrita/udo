//
//  HDQuestionParseViewController.h
//  udo_stu
//
//  Created by nobody on 6/16/15.
//  All rights reserved.
//

#import "HDBaseViewController.h"

typedef NS_ENUM(NSInteger, ParseVCFrom) { //从哪个控制器过来的。
    ParseVCFromPaper = 1, //试卷
    ParseVCFromAnswerReport //答题报告
};

@interface HDQuestionParseViewController : HDBaseViewController

@property (nonatomic, assign) HDPractiseType practiseType;
@property (nonatomic, strong) id chapterOrSectionModel;
@property (nonatomic, strong) NSArray *answers;
@property (nonatomic, assign) NSInteger currentIndex;

/// 从哪个控制器过来的
//@property (nonatomic, assign) ParseVCFrom from;
/// 如果从试卷过来，值为paperId
@property (nonatomic, assign) NSInteger sectionId;
/// 总共的题目数
@property (nonatomic, assign) NSInteger practise_num;

@end
