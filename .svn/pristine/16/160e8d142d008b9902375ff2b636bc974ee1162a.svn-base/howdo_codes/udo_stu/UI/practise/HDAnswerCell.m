//
//  HDAnswerCell.m
//  udo_stu
//
//  Created by nobody on 6/14/15.
//  All rights reserved.
//

#import "HDAnswerCell.h"

@implementation HDAnswerCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.questionButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.questionButton.titleLabel.textAlignment = NSTextAlignmentCenter;
        
        [self.questionButton addTarget:self action:@selector(questionClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.questionButton];
        self.questionButton.frame = CGRectMake(0, 0, 74/2, 74/2);
        
        frame = self.questionButton.frame;
        frame.origin.x = ceilf((self.frame.size.width - frame.size.width) / 2);
        frame.origin.y = ceilf((self.frame.size.height - frame.size.height) / 2);
        self.questionButton.frame = frame;
    }
    return self;
}

-(void)setCellData:(id)cellData
{
    HDAnswerModel *answer = (HDAnswerModel *)cellData;
    self.currentAnswer = answer;
    
    [self.questionButton setTitle:[NSString stringWithFormat:@"%ld", (long)answer.questionSeq] forState:UIControlStateNormal];
    if (answer) {
        if (answer.optionId > 0) {
            [self.questionButton setBackgroundImage:[UIImage imageNamed:@"ic_question_answered"] forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
        } else {
            [self.questionButton setBackgroundImage:[UIImage imageNamed:@"ic_question_no_answer"] forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(34, 177, 139) forState:UIControlStateNormal];
            [self.questionButton setTitleColor:UIColorFromRGB(34, 177, 139) forState:UIControlStateHighlighted];
        }
    }
}

- (void)questionClicked:(id)sender
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(HDTableViewSubviewDidSelected:tag:)]) {
        [self.delegate HDTableViewSubviewDidSelected:self tag:self.currentAnswer.questionSeq];
    }
}

@end
