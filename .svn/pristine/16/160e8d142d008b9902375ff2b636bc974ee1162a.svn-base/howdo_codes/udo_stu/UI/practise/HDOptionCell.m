//
//  HDOptionCell.m
//  udo_stu
//
//  Created by nobody on 6/13/15.
//  All rights reserved.
//

#import "HDOptionCell.h"

@interface HDOptionCell () <UIWebViewDelegate>

@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic, strong) HDOptionModel *currentData;
@property (nonatomic, strong) UIButton *optionButton;

@end

#define MIN_CELL_HEIGHT 50.0
static CGFloat cellHeights[20];

@implementation HDOptionCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.optionButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.optionButton setBackgroundImage:[UIImage imageNamed:@"btn_option_unchecked"] forState:UIControlStateNormal];
        [self.optionButton setBackgroundImage:[UIImage imageNamed:@"btn_option_checked"] forState:UIControlStateHighlighted];
        [self.optionButton setBackgroundImage:[UIImage imageNamed:@"btn_option_checked"] forState:UIControlStateSelected];
        [self.optionButton setContentMode:UIViewContentModeCenter];
        
        [self.optionButton setTitleColor:UIColorFromRGB(45, 140, 252) forState:UIControlStateNormal];
        [self.optionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateHighlighted];
        [self.optionButton setTitleColor:UIColorFromRGB(255, 255, 255) forState:UIControlStateSelected];

        [self.optionButton addTarget:self action:@selector(optionClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.optionButton];
        self.optionButton.frame = CGRectMake(8, 0, 66/2, 66/2);
        
        self.webView = [[UIWebView alloc] initWithFrame:CGRectMake(self.optionButton.frame.size.width + 8, 0, APP_CONTENT_WIDTH- self.optionButton.frame.size.width - 8, 10)];
        self.webView.scrollView.scrollEnabled = NO;
        self.webView.delegate = self;
        [self addSubview:self.webView];
        self.currentData = nil;
    }
    return self;
}

- (void)setCellData:(id)cellData
{
    HDOptionModel *option = (HDOptionModel *)cellData;
    
    if (!self.currentData || self.currentData.Id != option.Id) {
        if (option.content && option.content.length > 0) {
            [self.webView loadHTMLString:option.content baseURL:nil];
        } else {
            MyLog(@"option.url - %@", option.url);
            [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:option.url]]];
        }
    }
    self.currentData = option;
    
    [self.optionButton setTitle:option.letterSeq forState:UIControlStateNormal];
    self.optionButton.selected = option.selected;
    
    [self setSubviewsLayout];
}

-(void)setSubviewsLayout
{
    CGRect frame = self.webView.frame;
    frame.origin.y = (cellHeights[1] - frame.size.height) / 2;
    self.webView.frame = frame;
    
    frame = self.optionButton.frame;
    frame.origin.y = (cellHeights[1] - frame.size.height) / 2;
    self.optionButton.frame = frame;
}

#pragma mark - UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
//    MyLog(@"contentSize - %@", NSStringFromCGSize(webView.scrollView.contentSize));
//    MyLog(@"转换前%@", NSStringFromCGRect(webView.frame));
    CGRect frame = webView.frame;
    frame.size.height = 1;
    webView.frame = frame;
    
    frame.size = [webView sizeThatFits:CGSizeZero];
    frame.size.height -= 8;
    cellHeights[1] = frame.size.height < MIN_CELL_HEIGHT ? MIN_CELL_HEIGHT : frame.size.height + 5;
    frame.origin.y = (cellHeights[1] - frame.size.height) / 2;
    webView.frame = frame;
//    MyLog(@"转换后%@", NSStringFromCGRect(webView.frame));

    if (self.delegate && [self.delegate respondsToSelector:@selector(HDTableviewRefresh)]) {
        [self.delegate HDTableviewRefresh];
    }
}

- (void)optionClicked:(id)sender
{
    self.currentData.selected = YES;
    self.optionButton.selected = YES;
    if (self.delegate && [self.delegate respondsToSelector:@selector(HDTableViewSubviewDidSelected:tag:)]) {
        [self.delegate HDTableViewSubviewDidSelected:self tag:self.currentData.Id];
    }
}

+(float)dynamicHeight:(id)data
{
    return cellHeights[1];
}

@end
