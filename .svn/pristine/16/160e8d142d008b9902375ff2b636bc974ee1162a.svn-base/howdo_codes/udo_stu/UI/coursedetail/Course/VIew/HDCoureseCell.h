//
//  HDCoureseCell.h
//  udo_stu
//
//  Created by nobody on 15/6/5.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDCoureseCell;
@protocol HDCoureseCellDelegate <NSObject>

- (void)courseCell:(HDCoureseCell *)cell selectedNote:(id)note;
- (void)courseCell:(HDCoureseCell *)cell selectedPan:(id)note;
@end

@interface HDCoureseCell : UITableViewCell

// 小圆圈
@property (nonatomic,strong)UIImageView *markImageView;
// 左边的箭头
@property (nonatomic,strong)UIImageView *currentCourseImageView;

@property (nonatomic,assign)id<HDCoureseCellDelegate> delegate;
@property (nonatomic,strong)HDSectionModel *sectionModel;

+(float)dynamicHeight:(id)data;
@end
