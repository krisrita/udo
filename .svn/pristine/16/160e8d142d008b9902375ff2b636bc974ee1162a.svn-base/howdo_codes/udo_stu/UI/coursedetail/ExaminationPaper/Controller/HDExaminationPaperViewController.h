//
//  HDExaminationPaperViewController.h
//  udo_stu
//
//  Created by nobody on 15/7/2.
//  All rights reserved.
//

#import "HDBaseViewController.h"

/**
 *  试卷
 */
@interface HDExaminationPaperViewController : HDBaseViewController

/// 课程模型
@property(nonatomic, strong) HDCourseModel *courseModel;
@end
