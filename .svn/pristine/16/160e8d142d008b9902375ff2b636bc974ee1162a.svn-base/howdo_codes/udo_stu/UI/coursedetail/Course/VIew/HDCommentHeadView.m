//
//  HDCommentHeadView.m
//  udo_stu
//
//  Created by nobody on 15/6/13.
//  All rights reserved.
//

#import "HDCommentHeadView.h"

@interface HDCommentHeadView ()
@property (nonatomic ,strong)UILabel *upLabel;
@property (nonatomic ,strong)UILabel *downLabel;
@property (nonatomic ,strong)UILabel *commentLabel;

@property (nonatomic ,strong)UIImageView *upImageView;
@property (nonatomic ,strong)UIImageView *downImageView;
@property (nonatomic ,strong)UIImageView *commentImageView;

@end

@implementation HDCommentHeadView


-(instancetype)init
{
    if (self =[super init]) {
        self.backgroundColor = [UIColor whiteColor];
        [self bulitUI];
    }
    
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];

        [self bulitUI];
    }
    return self;
}
- (void)bulitUI
{
    UIImage *upImage = [UIImage imageNamed:@"up"];
    UIImageView *upImageView = [[UIImageView alloc]initWithImage:upImage];
    self.upImageView =upImageView;
    [self addSubview:upImageView];
    
    _upLabel = [[UILabel alloc]init];
    _upLabel.font = [UIFont systemFontOfSize:15];;
    _upLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:_upLabel];
    
    UIImage *downImage = [UIImage imageNamed:@"comment_down"];
    UIImageView *downImageView = [[UIImageView alloc]initWithImage:downImage];
    self.downImageView = downImageView;
    [self addSubview:downImageView];
    
    _downLabel = [[UILabel alloc]init];
    _downLabel.font = [UIFont systemFontOfSize:15];;
    _downLabel.backgroundColor = [UIColor clearColor];
    
    [self addSubview:_downLabel];
    
    _upLabel = [[UILabel alloc]init];
    _upLabel.font = [UIFont systemFontOfSize:15];;
    _upLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:_upLabel];
    
    UIImage *commentImage = [UIImage imageNamed:@"comment_default"];
    UIImageView *commentImageView = [[UIImageView alloc]initWithImage:commentImage];
    self.commentImageView = commentImageView;
    [self addSubview:commentImageView];
    
    _commentLabel = [[UILabel alloc]init];
    _commentLabel.font = [UIFont systemFontOfSize:15];;
    _commentLabel.backgroundColor = [UIColor clearColor];
    
    [self addSubview:_commentLabel];
    [self setSubviewsLayout];
}
- (void)setInfoWithModel:(id)model
{
    HDCourseModel *coureseModel = (HDCourseModel *)model;
    self.upLabel.text = conversionstring(coureseModel.likedNum);
    self.downLabel.text = conversionstring(coureseModel.dislikedNum);
    self.commentLabel.text = conversionstring(coureseModel.commentNum);

    [self setSubviewsLayout];
    
}
-(void)setSubviewsLayout
{
    WS(ws);
    
    [self.upImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.upLabel.mas_left).offset(-5);
        make.centerY.equalTo(ws);
        
    }];
    [self.upLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.downImageView.mas_left).offset(-70);
        make.centerY.equalTo(ws);
        
    }];
    [self.downImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.mas_centerX).offset(-5);
        make.centerY.equalTo(ws);
    }];
    [self.downLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws);
        make.left.equalTo(ws.mas_centerX).offset(5);
        
    }];
    [self.commentImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws.downLabel.mas_right).offset(70);
        make.centerY.equalTo(ws);
    }];
    [self.commentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws);
        make.left.equalTo(ws.commentImageView.mas_right).offset(5);
        
    }];
}

@end
