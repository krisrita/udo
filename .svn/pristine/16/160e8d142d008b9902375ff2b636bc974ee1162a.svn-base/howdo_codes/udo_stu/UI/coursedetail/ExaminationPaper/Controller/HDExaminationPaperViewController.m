//
//  HDExaminationPaperViewController.m
//  udo_stu
//
//  Created by nobody on 15/7/2.
//  All rights reserved.
//

#import "HDExaminationPaperViewController.h"
#import "XLPagerTabStripViewController.h"
#import "HDQuestionParseViewController.h"
#import "HDPaperDetailViewController.h"

#import "HDPaperCell.h"

#import "HDPaper.h"

NSString * const HDPaperCellReuseId = @"HDPaperCellReuseId";

@interface HDExaminationPaperViewController () <XLPagerTabStripChildItem, UITableViewDataSource, UITableViewDelegate, PullTableViewDelegate>

@property (nonatomic, weak) PullTableView *tableView;
/// 所有试卷[HDPaper]
@property (nonatomic, strong) NSMutableArray *papers;

@end

@implementation HDExaminationPaperViewController

#pragma mark - Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.headView.hidden = YES;
//    self.view.backgroundColor = UIColorFromRGB(241, 241, 241);
    
    [self setupTableView];
    [self beginRefresh];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    CGRect frame = self.view.bounds;
    frame.origin.y = 104.0;
    frame.size.height -= 104.0;
    self.tableView.frame = frame;
}

#pragma mark - Init View
- (void)setupTableView {
    PullTableView *tableView = [[PullTableView alloc] initWithFrame:CGRectZero refeshType:HD_TABLE_REFRESH_UPDOWN];
    self.tableView = tableView;
    [tableView registerNib:[UINib nibWithNibName:@"HDPaperCell" bundle:nil] forCellReuseIdentifier:HDPaperCellReuseId];
    tableView.pullDelegate = self;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.rowHeight = 100.0;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:tableView];
}

#pragma mark - Network Request
/**
 *  @param type //0 下拉 1 上拉
 */
- (void)requestDataWithType:(HDRequestType)type paperId:(NSInteger)paperId {
    __weak __typeof(self)weakSelf = self;
    [[HDManager sharedInstance].courseService getPaperListWithWithCourseId:self.courseModel.Id paperId:paperId type:type resultBack:^(HDServiceResult *result, id object) {
        if (!weakSelf) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            if ((result.resultCode == HD_RESULT_CODE_SUCCESS) && [object count] > 0) {
                if (type == HDRequestTypeRefresh) {
                    [strongSelf.papers removeAllObjects];
                }
                HDPaper *paper = [(NSArray *)object lastObject];
                HDPaper *lastPaper = [strongSelf.papers lastObject];
                
                // 暂时先这么判断，应该由服务器判断
                if (lastPaper.Id == paper.Id) {
                    strongSelf.tableView.loadMoreViewHide = YES;
                } else {
                    [strongSelf.papers addObjectsFromArray:object];
                    [strongSelf.tableView reloadData];
                }
            }
            if ([object count] == 0) strongSelf.tableView.loadMoreViewHide = YES;
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (type == HDRequestTypeRefresh) {
                    strongSelf.tableView.pullTableIsRefreshing = NO;
                } else {
                    strongSelf.tableView.pullTableIsLoadingMore = NO;
                }
            });
        });
    }];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.papers count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HDPaperCell *cell = [tableView dequeueReusableCellWithIdentifier:HDPaperCellReuseId];
    cell.paper = self.papers[indexPath.row];
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    HDPaper *paper = self.papers[indexPath.row];
    
    if (paper.practise_num <= 0) {
        [HDLoading showError:@"正在绞尽脑汁出题中..."];
        return;
    }
    
    HDPaperDetailViewController *paperDetail = [[HDPaperDetailViewController alloc] init];

    paperDetail.paper = paper;
    [self.navigationController pushViewController:paperDetail animated:YES];
}

#pragma mark - CustomDelegate
#pragma mark XLPagerTabStripViewControllerDelegate
- (NSString *)titleForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController {
    return @"试卷";
}

- (UIColor *)colorForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController {
    return UIColorFromRGB(241, 241, 241);
}

#pragma mark - PullTableViewDelegate
- (void)pullTableViewDidTriggerRefresh:(PullTableView *)pullTableView {
    [self requestDataWithType:HDRequestTypeRefresh paperId:0];
}

- (void)pullTableViewDidTriggerLoadMore:(PullTableView *)pullTableView {
    HDPaper *paper = [self.papers lastObject];
    [self requestDataWithType:HDRequestTypeLoadMore paperId:paper.Id];
}

#pragma mark - Event Response
#pragma mark - Private Methods
- (void)beginRefresh {
    self.tableView.pullTableIsRefreshing = YES;
    [self pullTableViewDidTriggerRefresh:nil];
}

#pragma mark - Public Methods
#pragma mark - Getters & Setters
- (NSMutableArray *)papers {
    if (_papers == nil) {
        _papers = [[NSMutableArray alloc] init];
    }
    return _papers;
}

@end
