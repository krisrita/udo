//
//  HDPaperDetailViewController.h
//  udo_stu
//
//  Created by nobody on 15/7/4.
//   All rights reserved.
//

#import "HDBaseViewController.h"

@class HDPaper;

@interface HDPaperDetailViewController : HDBaseViewController
@property (nonatomic, strong) HDPaper *paper;
@end
