//
//  HDCourseViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/1.
//  All rights reserved.
//

#import "HDCourseViewController.h"
#import "XLPagerTabStripViewController.h"
#import "HDCoureseCell.h"
#import "HDNoteViewController.h"
#import "HDPractiseViewController.h"
#import "HDVideoViewController.h"

#import "HDPractiseController.h"

#define  SECTION_TAG    1000
@interface HDCourseViewController ()<XLPagerTabStripChildItem,UITableViewDelegate,UITableViewDataSource,HDCoureseCellDelegate>

@property (nonatomic,strong) UITableView *tableview;
@property (nonatomic,strong) UIView *tableHeadView;
@property (nonatomic,strong) UILabel *textLabel;
@property (nonatomic,strong) NSIndexPath *lastIndexPath;
@property (nonatomic,strong)NSMutableArray *sectionArray;
// 最后观看课程cell
@property (nonatomic, weak) HDCoureseCell *lastWatchCourseCell;
@end

@implementation HDCourseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self builtHeadView];
    self.headView.hidden = YES;
    _tableview = [[UITableView alloc]initWithFrame:CGRectMake(0,0, 0,0) style:UITableViewStylePlain];
    _tableview.backgroundColor = [UIColor whiteColor];
    _tableview.delegate = self;
    _tableview.dataSource = self;
    _tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableview.rowHeight = 45;
    //    _tableview.pullDelegate = self;
    [self.view addSubview:_tableview];
    [_tableview registerClass:[HDCoureseCell class] forCellReuseIdentifier:NSStringFromClass([HDCoureseCell class])];
    _tableview.tableHeaderView = self.tableHeadView;
    [self requestData];
}
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    _tableview.frame =  CGRectMake(0,0, APP_CONTENT_WIDTH,CGRectGetHeight(self.view.frame));
    _tableview.contentInset = UIEdgeInsetsMake(104, 0, 0, 0);
//    secionBlankPageView = [[MCSectionBlankPageView alloc]initWithFrame:self.tableview.frame];
}

- (void)builtHeadView
{
    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, 40)];
    UILabel *textLabel = [[UILabel alloc]init];
    textLabel.textColor = UIColorFromRGB(29, 29, 29);
    [headView addSubview:textLabel];
    [textLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(headView.mas_left).offset(20);
        make.right.equalTo(headView.mas_right).offset(-20);
        make.centerY.equalTo(headView.mas_centerY);
    }];
    self.textLabel = textLabel;
    self.textLabel.font = [UIFont systemFontOfSize:13];
    self.textLabel.text = [NSString stringWithFormat:@"%ld堂课  %ld小节  共计%ld分钟", (long)self.courseModel.chapterNum, (long)self.courseModel.sectionNum, (long)[self.courseModel.totalDuration minutes]];
    self.tableHeadView = headView;
}

- (void)requestData
{
    WS(ws);
    [[HDManager sharedInstance].courseService getChapterList:self.courseModel.Id resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS) {
            self.sectionArray = object;
            [ws.tableview reloadData];
        }
    }];
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *customSectionHeaderView;
    UILabel *titleLabel;
    customSectionHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,APP_CONTENT_WIDTH, 40)];
    titleLabel = [[UILabel alloc] init];
    
    customSectionHeaderView.backgroundColor = UIColorFromRGB(241, 241, 241);
    titleLabel.textAlignment = NSTextAlignmentLeft;
    [titleLabel setTextColor:UIColorFromRGB(29, 29, 29)];
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [titleLabel setBackgroundColor:customSectionHeaderView.backgroundColor];
    titleLabel.font = [UIFont boldSystemFontOfSize:15];
    
    [customSectionHeaderView addSubview:titleLabel];
    UILabel  *leftOpenTimeLabel = [[UILabel alloc] init];

    leftOpenTimeLabel.textAlignment = NSTextAlignmentCenter;
    [leftOpenTimeLabel setTextColor:UIColorFromRGB(34, 177, 139)];
    leftOpenTimeLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [leftOpenTimeLabel setBackgroundColor:[UIColor clearColor]];
    leftOpenTimeLabel.font = [UIFont systemFontOfSize:15];
    
    [customSectionHeaderView addSubview:leftOpenTimeLabel];
    
    HDChapterModel *chaperModel = self.sectionArray[section];
    titleLabel.text = chaperModel.name;
        [titleLabel setTextColor:[UIColor blackColor]];
    if (chaperModel.hasOpened) {
        leftOpenTimeLabel.text = @"";
    }else{
        titleLabel.textColor = UIColorFromRGB(163, 163, 163);
        leftOpenTimeLabel.text = chaperModel.leftOpenTimeHint;
    }
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button setImage:[UIImage imageNamed:@"lianxi"] forState:UIControlStateNormal];
    button.tag = SECTION_TAG+section;
    [customSectionHeaderView addSubview:button];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(customSectionHeaderView).offset(20);
        make.centerY.equalTo(customSectionHeaderView);
    }];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(customSectionHeaderView).offset(-20);
        make.centerY.equalTo(customSectionHeaderView);
    }];
    
    [leftOpenTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(button.mas_left).offset(-20);
        make.centerY.equalTo(customSectionHeaderView);
    }];
    
    button.enabled = chaperModel.hasOpened;
    
    return customSectionHeaderView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.sectionArray.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    HDChapterModel *chaperModel = self.sectionArray[section];
    return [chaperModel.sections count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HDCoureseCell *cell = (HDCoureseCell *)[tableView dequeueReusableCellWithIdentifier:NSStringFromClass([HDCoureseCell class])];
    HDChapterModel *chaperModel = self.sectionArray[indexPath.section];
    HDSectionModel *sectionModel =chaperModel.sections[indexPath.row];
    cell.sectionModel = sectionModel;
    cell.delegate = self;
    if (sectionModel.isLast) {
        self.lastWatchCourseCell = cell;
    }
    return cell;
}

#pragma mark - 进入视频页
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    HDChapterModel *chaperModel = self.sectionArray[indexPath.section];
    HDSectionModel *sectionModel =chaperModel.sections[indexPath.row];
    if (sectionModel.videoId == 0) {
        [HDLoading startAnimating:@"暂无视频"];
        [HDLoading stopAnimating:@"暂无视频"];
        return;
    }
    if (sectionModel.hasOpened) {
        
        // 圆圈选中
        HDCoureseCell *cell = (HDCoureseCell *)[tableView cellForRowAtIndexPath:indexPath];
        cell.markImageView.image = [UIImage imageNamed:@"coure_learned"];
        
        // 箭头
        if (self.lastWatchCourseCell != cell) {
            self.lastWatchCourseCell.currentCourseImageView.hidden = YES;
            cell.currentCourseImageView.hidden = NO;
            self.lastWatchCourseCell = cell;
        }
        
//        // 发出通知
//        [[NSNotificationCenter defaultCenter] postNotificationName:WatchedNumIncrementNotification object:nil];
        
        [[HDVideoProxy sharedInstance] showVideo:self chapterOrSectionModel:sectionModel answerModel:nil];
    }
   
}

- (void)setSectionArray:(NSMutableArray *)sectionArray
{
    if (_sectionArray !=sectionArray) {
        _sectionArray = sectionArray;
    }
    
}
- (void)setScrollIndexPath:(NSIndexPath *)scrollIndexPath
{
    if (!_sectionArray||!_sectionArray.count) {
        
    }else{
        [_tableview scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionNone animated:NO];
    }
}

- (void)buttonClicked:(UIButton *)send
{
    NSInteger section = send.tag -SECTION_TAG;
    HDChapterModel *chaperModel = self.sectionArray[section];
    // 章练习
    [[HDPractiseProxy sharedInstance] doPractise:self practiseType:HD_PRACTISE_TYPE_CHAPTER chapterOrSection:chaperModel];
}

#pragma mark - Event Response
#pragma mark 点击了练习
- (void)courseCell:(HDCoureseCell *)cell selectedNote:(id)note
{
    // 节练习
    [[HDPractiseProxy sharedInstance] doPractise:self practiseType:HD_PRACTISE_TYPE_SECTION chapterOrSection:cell.sectionModel];
}

#pragma mark 点击了笔记
- (void)courseCell:(HDCoureseCell *)cell selectedPan:(id)note
{
    HDNoteViewController *noteViewController = [[HDNoteViewController alloc]init];
    noteViewController.sectionModel = cell.sectionModel;
    [self.navigationController pushViewController:noteViewController animated:YES];
}
#pragma mark - XLPagerTabStripViewControllerDelegate

-(NSString *)titleForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController
{
    return @"课程";
}

-(UIColor *)colorForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController
{
    return [UIColor whiteColor];
}
@end
