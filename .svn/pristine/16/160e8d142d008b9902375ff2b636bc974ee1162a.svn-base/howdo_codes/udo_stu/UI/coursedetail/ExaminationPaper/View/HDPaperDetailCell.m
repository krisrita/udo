//
//  HDPaperDetailCell.m
//  udo_stu
//
//  Created by nobody on 15/7/4.
//   All rights reserved.
//

#import "HDPaperDetailCell.h"
#import "UIColor+TransformCMYKString.h"

@interface HDPaperDetailCell () <UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loadingvView;

@end

@implementation HDPaperDetailCell

- (void)awakeFromNib {
    self.webView.scrollView.backgroundColor = [UIColor whiteColor];
    self.webView.delegate = self;
}

#pragma mark - UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    self.webView.hidden = NO;
    [self.loadingvView stopAnimating];
    MyLog(@"%@", webView.request.URL.absoluteString);
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    self.webView.hidden = YES;
}

- (void)setUrlStr:(NSString *)urlStr {
    self.webView.hidden = YES;
    [self.loadingvView startAnimating];
    _urlStr = urlStr;
    NSURL *url = [NSURL URLWithString:urlStr];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
}

- (IBAction)watchVideoClicked {
    if ([self.cellDelegate respondsToSelector:@selector(paperDetailCellDidClickWatchVideo:)]) {
        [self.cellDelegate paperDetailCellDidClickWatchVideo:self];
    }
}

@end
