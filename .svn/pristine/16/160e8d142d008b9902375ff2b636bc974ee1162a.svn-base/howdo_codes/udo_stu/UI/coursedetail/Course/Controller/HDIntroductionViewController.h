//
//  HDIntroductionViewController.h
//  udo_stu
//
//  Created by nobody on 15/6/1.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDIntroductionViewController : HDBaseViewController

@property(nonatomic,strong)HDCourseModel *courseModel;

@end
