//
//  HDPaperAnswerCardCell.h
//  udo_stu
//
//  Created by mayun on 15/7/16.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPaperAnswerCardCell;

@protocol HDPaperAnswerCardCellDelegate <NSObject>

/// 选择了某道题
- (void)paperAnswerCardCell:(HDPaperAnswerCardCell *)paperAnswerCardCell didSelectSeq:(NSInteger)seq;

@end

@interface HDPaperAnswerCardCell : UICollectionViewCell

/// 答案
@property (nonatomic, strong) NSArray *answers;

@property (nonatomic, weak) id<HDPaperAnswerCardCellDelegate> cellDelegate;

@end
