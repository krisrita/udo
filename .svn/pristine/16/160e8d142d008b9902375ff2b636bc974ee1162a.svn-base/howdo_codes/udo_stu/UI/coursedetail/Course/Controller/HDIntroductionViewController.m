//
//  HDIntroductionViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/1.
//  All rights reserved.
//

#import "HDIntroductionViewController.h"
#import "XLPagerTabStripViewController.h"
#import "HDIntroductionCell.h"
#import "HDUserIntrodutionCell.h"
@interface HDIntroductionViewController ()<XLPagerTabStripChildItem,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *tableview;
@property (nonatomic,strong) NSIndexPath *lastIndexPath;
@property (nonatomic,strong)HDCourseIntroModel *coureseIntroModel;
@end

@implementation HDIntroductionViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.headView.hidden = YES;
    _tableview = [[UITableView alloc]initWithFrame:CGRectMake(0,0, 0,0) style:UITableViewStylePlain];
    _tableview.backgroundColor = [UIColor whiteColor];
    _tableview.delegate = self;
    _tableview.dataSource = self;
    _tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableview.rowHeight = 150;
    [self.view addSubview:_tableview];
    [_tableview registerClass:[HDIntroductionCell class] forCellReuseIdentifier:NSStringFromClass([HDIntroductionCell class])];
    [_tableview registerClass:[HDUserIntrodutionCell class] forCellReuseIdentifier:NSStringFromClass([HDUserIntrodutionCell class])];

    [self requestData];
}
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    _tableview.frame =  CGRectMake(0,0, APP_CONTENT_WIDTH,CGRectGetHeight(self.view.frame));
    _tableview.contentInset = UIEdgeInsetsMake(104, 0, 0, 0);
    //    secionBlankPageView = [[MCSectionBlankPageView alloc]initWithFrame:self.tableview.frame];
}
- (void)requestData
{
    WS(ws);
    [[HDManager sharedInstance].courseService getCourseIntro:self.courseModel.Id resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS) {
            ws.coureseIntroModel = object;
            [ws.tableview reloadData];
        }
    }];
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 42;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *customSectionHeaderView;
    UILabel *titleLabel;
    UIFont *labelFont;
    customSectionHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 42)];
    
    titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 6, tableView.frame.size.width-15, 30)];
    
    labelFont = [UIFont systemFontOfSize:15];
    
    customSectionHeaderView.backgroundColor = UIColorFromRGB(241, 241, 241);
    
    titleLabel.textAlignment = NSTextAlignmentLeft;
    [titleLabel setTextColor:UIColorFromRGB(29, 29, 29)];
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [titleLabel setBackgroundColor:customSectionHeaderView.backgroundColor];
    titleLabel.font = labelFont;
    
    [customSectionHeaderView addSubview:titleLabel];
    switch (section) {
        case 0:
            titleLabel.text = @"讲师简介";
            break;
        case 1:
        {
            titleLabel.text = @"专题介绍";
        }
        default:
            break;
    }
    return customSectionHeaderView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0:
        {
          return [HDIntroductionCell dynamicHeight:self.coureseIntroModel isHeadImageView:YES indexPath:indexPath];
        }
            break;
        case 1:
        {
          return [HDUserIntrodutionCell dynamicHeight:self.coureseIntroModel isHeadImageView:NO indexPath:indexPath];
            
        }
            break;
        default:
            break;
    }
    return 0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return self.coureseIntroModel.teachers.count;
            break;
        case 1:
            return 1;
        default:
            break;
    }
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    switch (indexPath.section) {
        case 0:
        {
            
            HDIntroductionCell *cell = (HDIntroductionCell *)[tableView dequeueReusableCellWithIdentifier:NSStringFromClass([HDIntroductionCell class])];
            [cell setCoureseIntroModel:self.coureseIntroModel isHeadImageView:YES indexPath:indexPath];
            return cell;
        }
            break;
        case 1:
        {
            
            HDUserIntrodutionCell *cell = (HDUserIntrodutionCell *)[tableView dequeueReusableCellWithIdentifier:NSStringFromClass([HDUserIntrodutionCell class])];
            [cell setCoureseIntroModel:self.coureseIntroModel isHeadImageView:NO indexPath:indexPath];
            return cell;
        }
            break;
        default:
            break;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}
#pragma mark - XLPagerTabStripViewControllerDelegate

-(NSString *)titleForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController
{
    return @"简介";
}

-(UIColor *)colorForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController
{
    return [UIColor whiteColor];
}
@end
