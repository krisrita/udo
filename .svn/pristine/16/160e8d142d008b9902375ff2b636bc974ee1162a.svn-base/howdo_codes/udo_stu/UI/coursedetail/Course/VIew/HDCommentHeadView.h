//
//  HDCommentHeadView.h
//  udo_stu
//
//  Created by nobody on 15/6/13.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDCommentHeadView : UIView

- (void)setInfoWithModel:(id)model;


@end
