//
//  HDIntroductionCell.m
//  udo_stu
//
//  Created by nobody on 15/6/6.
//  All rights reserved.
//

#import "HDIntroductionCell.h"

@interface HDIntroductionCell ()
{
    BOOL isHeadImage;
}
@property(nonatomic,strong)UIView *userView;
@property(nonatomic,strong)HDImageView *headImageView;
@property(nonatomic,strong)UILabel *nicknameLabel;
@property(nonatomic,strong)UILabel *jobLabel;
@property(nonatomic,strong)UILabel *userInfoLabel;
@end

@implementation HDIntroductionCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        isHeadImage = YES;
        // Initialization code
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        self.backgroundColor = [UIColor whiteColor];
        
        UIView *userView = [[UIView alloc]init];
        self.userView = userView;
        self.userView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:userView];
        
        
        _headImageView = [[HDImageView alloc]init];
        [self.userView addSubview:_headImageView];
        
        _nicknameLabel = [[UILabel alloc]init];
        _nicknameLabel.font = [UIFont systemFontOfSize:12];
        _nicknameLabel.textAlignment = NSTextAlignmentLeft;
        _nicknameLabel.textColor = UIColorFromRGB(29, 29, 29);
        _nicknameLabel.backgroundColor = [UIColor clearColor];
        [self.userView addSubview:_nicknameLabel];
        
        
        _jobLabel = [[UILabel alloc]init];
        _jobLabel.font = [UIFont systemFontOfSize:12];
        _jobLabel.numberOfLines = 0;
        _jobLabel.textColor = UIColorFromRGB(29, 29, 29);

        _jobLabel.textAlignment = NSTextAlignmentLeft;
        _jobLabel.backgroundColor = [UIColor clearColor];
        [self.userView addSubview:_jobLabel];
        
        _userInfoLabel = [[UILabel alloc]init];
        _userInfoLabel.numberOfLines = 0;
        _userInfoLabel.textColor = UIColorFromRGB(29, 29, 29);

        _userInfoLabel.font = [UIFont systemFontOfSize:12];
        _userInfoLabel.textAlignment = NSTextAlignmentLeft;
        _userInfoLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_userInfoLabel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (void)setCoureseIntroModel:(HDCourseIntroModel *)coureseIntroModel isHeadImageView:(BOOL)isHeadImageview
{
    isHeadImage = isHeadImageview;
    _coureseIntroModel = coureseIntroModel;
    HDTeacherModel *teacherModel = coureseIntroModel.teachers[0];
    [_headImageView setHDImageURL:[NSURL URLWithString:teacherModel.imageUrl.imageName] placeholderImage:nil imageType:HD_IMAGE_CIRCLE];
    _nicknameLabel.text = teacherModel.name;
    _jobLabel.text = teacherModel.title;
    if (isHeadImageview) {
        _userInfoLabel.text = teacherModel.introduction;
    }else{
        _userInfoLabel.text = coureseIntroModel.introduction;

    }
    [self setSubviewsLayout];
}
- (void)setCoureseIntroModel:(HDCourseIntroModel *)coureseIntroModel isHeadImageView:(BOOL)isHeadImageview indexPath:(NSIndexPath *)indexPath
{
    isHeadImage = isHeadImageview;
    _coureseIntroModel = coureseIntroModel;
    HDTeacherModel *teacherModel = coureseIntroModel.teachers[indexPath.row];
    [_headImageView setHDImageURL:[NSURL URLWithString:[teacherModel.imageUrl small]] placeholderImage:[UIImage imageNamed:@"headImage_placeholder"] imageType:HD_IMAGE_CIRCLE];
    _nicknameLabel.text = teacherModel.name;
    _jobLabel.text = teacherModel.title;
    if (isHeadImageview) {
        _userInfoLabel.text = teacherModel.introduction;
    }else{
        _userInfoLabel.text = coureseIntroModel.introduction;
        
    }
    [self setSubviewsLayout];
}
-(void)setSubviewsLayout
{
    WS(ws);
    
 
    if (isHeadImage) {
        
        [self.userView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.with.right.equalTo(ws.contentView);
            make.top.equalTo(ws.contentView);
            make.bottom.equalTo(ws.headImageView.mas_bottom).offset(10);
        }];
        
        [self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws.userView).offset(20);
            make.width.equalTo(@(40));
            make.height.equalTo(@(40));
            make.centerY.equalTo(ws.userView);
        }];
        
        
        
        [self.nicknameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(ws.headImageView);
            make.left.equalTo(ws.headImageView.mas_right).offset(8);
        }];
        
        
        [self.jobLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws.nicknameLabel);
            make.top.equalTo(ws.nicknameLabel.mas_bottom).offset(10);
            
        }];
        self.userView.hidden = NO;
        [self.userInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws.contentView).offset(15);
            make.right.equalTo(ws.contentView).offset(-15);
            make.top.equalTo(ws.userView.mas_bottom);
            
        }];
    }else{
        [self.contentView removeConstraints:self.contentView.constraints];
        self.userView.hidden = YES;
        [self.userInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws.contentView).offset(15);
            make.right.equalTo(ws.contentView).offset(-15);
            make.top.equalTo(ws.contentView).offset(10);
            
        }];
    }
   
 
}
+(float)dynamicHeight:(HDCourseIntroModel *)data isHeadImageView:(BOOL)isHeadImageview
{
    if (isHeadImageview) {
        HDTeacherModel *teacherModel = data.teachers[0];
        CGSize size = [teacherModel.introduction fitSize:[UIFont systemFontOfSize:12] contentWidth:APP_CONTENT_WIDTH-30 maxHeight:1000];
        return 50+size.height+15;
    }else{
        CGSize size = [data.introduction fitSize:[UIFont systemFontOfSize:12] contentWidth:APP_CONTENT_WIDTH-30 maxHeight:1000];
        return size.height+15;
    }
    return 0;
}
+(float)dynamicHeight:(HDCourseIntroModel *)data isHeadImageView:(BOOL)isHeadImageview indexPath:(NSIndexPath *)indexPath
{
    if (isHeadImageview) {
        HDTeacherModel *teacherModel = data.teachers[indexPath.row];
        CGSize size = [teacherModel.introduction fitSize:[UIFont systemFontOfSize:12] contentWidth:APP_CONTENT_WIDTH-30 maxHeight:1000];
        return 50+size.height+15;
    }else{
        CGSize size = [data.introduction fitSize:[UIFont systemFontOfSize:12] contentWidth:APP_CONTENT_WIDTH-30 maxHeight:1000];
        return size.height+15;
    }
    return 0;
}
@end
