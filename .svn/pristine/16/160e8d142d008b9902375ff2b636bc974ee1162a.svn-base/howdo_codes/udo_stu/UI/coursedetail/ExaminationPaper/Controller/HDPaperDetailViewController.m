//
//  HDPaperDetailViewController.h
//  udo_stu
//
//  Created by nobody on 15/7/4.
//   All rights reserved.
//

#import "HDPaperDetailViewController.h"

#import "HDPaperDetailCell.h"
#import "HDPaperAnswerCardCell.h"
#import "HDAnswerCell.h"

#import "HDPaper.h"

NSString * const HDPaperDetailCellResueId = @"HDPaperDetailCell";

NSString * const AnswerCardCellId = @"AnswerCardCellId";

@interface HDPaperDetailViewController () <UICollectionViewDataSource, UICollectionViewDelegate, HDPaperDetailCellDelegate, HDPaperAnswerCardCellDelegate, HDTableViewDelegate>
@property (nonatomic, weak) UICollectionViewFlowLayout *flowLayout;
@property (nonatomic, weak) UICollectionView *collectionView;
/// 试题索引
@property (weak, nonatomic) IBOutlet UILabel *indexLabel;
/// 试卷名称
@property (weak, nonatomic) IBOutlet UILabel *paperTitleLabel;

/// 当前试题
@property (nonatomic, assign) NSInteger currentIndex;
/// 路径地址
@property (nonatomic, copy) NSString *baseUrl;

/// 答题卡
@property (nonatomic, strong) HDTableView *answerCard;
@end

@implementation HDPaperDetailViewController

#pragma mark - Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setup];
    
    [self setupNav];
    
    [self setupCollectionView];
}

- (void)setup {
    self.currentIndex = 1;
    id<HDNetworkConfigDelegate> networkConfig = [[HDNetworkConfig alloc] init];
    self.baseUrl = [networkConfig getHttpServiceBaseUrl];
    
    self.paperTitleLabel.text = self.paper.name;
    self.indexLabel.text = [NSString stringWithFormat:@"1/%ld", (long)self.paper.practise_num];
}

#pragma mark - Init View
- (void)setupNav {
    self.leftView = [HDUICommon leftBackView:self];
    ((MLNavigationController *)self.navigationController).canDragBack = NO;
    self.centerView = [HDUICommon getTitleView:@"题目详情"];
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:[UIImage imageNamed:@"btn_share_default"] forState:UIControlStateNormal];
    [rightButton setFrame:CGRectMake(0, 0, 44, 44)];
    [rightButton addTarget:self action:@selector(shareClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.rightView = rightButton;
    
    // 答题卡按钮
    UIButton *answerCard = [UIButton buttonWithType:UIButtonTypeCustom];
    [answerCard setImage:[UIImage imageNamed:@"paper_detail_answer_card"] forState:UIControlStateNormal];
    [answerCard setFrame:CGRectMake(CGRectGetWidth(self.headView.frame) - 88, 20, 44, 44)];
    [answerCard addTarget:self action:@selector(answerCardClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.headView addSubview:answerCard];
}

- (void)setupCollectionView {
    CGSize itemSize = CGSizeMake(APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT - 104.0);
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.minimumLineSpacing = 0;
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flowLayout.itemSize = itemSize;
    self.flowLayout = flowLayout;
    
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    self.collectionView = collectionView;
    collectionView.frame = CGRectMake(0, 104.0, itemSize.width, itemSize.height);
    [collectionView registerNib:[UINib nibWithNibName:@"HDPaperDetailCell" bundle:nil] forCellWithReuseIdentifier:HDPaperDetailCellResueId];
    [collectionView registerClass:[HDPaperAnswerCardCell class] forCellWithReuseIdentifier:AnswerCardCellId]; //答题卡cell
    collectionView.backgroundColor = [UIColor whiteColor];
    collectionView.pagingEnabled = YES;
    collectionView.showsHorizontalScrollIndicator = NO;
    collectionView.showsVerticalScrollIndicator = NO;
    collectionView.dataSource = self;
    collectionView.delegate = self;
    [self.view addSubview:collectionView];
}

#pragma mark - Network Request

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
//    if (self.paper.practise_num == 0) return 0;
//    
//    return self.paper.practise_num + 1;
    return self.paper.practise_num;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
//    if (indexPath.row == self.paper.practise_num) {
//        HDPaperAnswerCardCell *rsItem = [collectionView dequeueReusableCellWithReuseIdentifier:AnswerCardCellId forIndexPath:indexPath];
//        rsItem.answers = [self getAnswers];
//        rsItem.cellDelegate = self;
//        return rsItem;
//    }
    
    HDPaperDetailCell *item = [collectionView dequeueReusableCellWithReuseIdentifier:HDPaperDetailCellResueId forIndexPath:indexPath];
    item.cellDelegate = self;
    item.urlStr = [self urlStrWithIndex:indexPath.row];
//    MyLog(@"cellForItemAtIndexPath, %zd", indexPath.row);
    return item;
}

#pragma mark - UICollectionViewDelegate

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int index = (int)(scrollView.contentOffset.x / scrollView.bounds.size.width + 0.5);
    self.indexLabel.text = [NSString stringWithFormat:@"%d/%ld", index+1, (long)self.paper.practise_num];
    self.indexLabel.hidden = self.paper.practise_num == index;
}


#pragma mark - CustomDelegate
#pragma mark HDPaperDetailCellDelegate
- (void)paperDetailCellDidClickWatchVideo:(HDPaperDetailCell *)paperDetailCell {
    NSIndexPath *indexPath = [self.collectionView indexPathForCell:paperDetailCell];
    NSInteger videoId = [self.paper.practise_video_list[indexPath.row] integerValue];
    if (videoId <= 0) {
        [HDLoading startAnimating:@"暂无视频，敬请期待"];
        [HDLoading stopAnimating:@"暂无视频，敬请期待"];
        return;
    }
    HDSectionModel *sectionModel = [[HDSectionModel alloc] init];
    sectionModel.Id = self.paper.Id;
    sectionModel.videoId = videoId;
    sectionModel.courseId = self.paper.course_id;
    sectionModel.name = self.paper.name;
    [[HDVideoProxy sharedInstance] showVideo:self chapterOrSectionModel:sectionModel answerModel:nil];
}

#pragma mark HDTableViewDelegate
- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag
{
    [self hideAnswerCardWithAnimated:YES];
    [self jumpToSeq:tag - 1];
}

#pragma mark - Event Response
- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)answerCardClicked {
    [self showAnswerCard];
}

#pragma mark - Private Methods
- (void)jumpToSeq:(NSInteger)seq {
    if (seq < 0) return;
    NSIndexPath *nextIndexPath = [NSIndexPath indexPathForItem:seq inSection:0];
    [self.collectionView scrollToItemAtIndexPath:nextIndexPath atScrollPosition:UICollectionViewScrollPositionLeft animated:NO];
}

- (NSString *)urlStrWithIndex:(NSInteger)index {
    HDManager *manager = [HDManager sharedInstance];
    NSInteger uid = manager.isLogined ? manager.currentUser.Id : 0;
    // 之前的practise/parse
//    NSString *urlStr = [NSString stringWithFormat:@"%@practise/parse/section_id/%ld/seq/%ld?platform=ios&uid=%ld", self.baseUrl, (long)self.paper.Id, (long)(index + 1), (long)uid];
    // 现在的practise/exam
    NSString *urlStr = [NSString stringWithFormat:@"%@practise/exam/section_id/%ld/seq/%ld?platform=ios&uid=%ld", self.baseUrl, (long)self.paper.Id, (long)(index + 1), (long)uid];
    // 试卷http://182.92.110.119/practise/parse/section_id/4710/seq/1?platform=ios&uid=12417
    return urlStr;
}

/// 获取答案
- (NSArray *)getAnswers
{
    NSMutableArray *answers = [NSMutableArray array];
    
    for (NSInteger i = 0; i < self.paper.practise_num; i++) {
        HDAnswerModel *answer = [[HDAnswerModel alloc] init];
        answer.questionSeq = i + 1;
        [answers addObject:answer];
    }
    
//    @synchronized(self.questions) {
//        for (HDQuestionModel *question in self.questions) {
//            if (question.seq > 0 && question.seq <= [answers count]) {
//                HDAnswerModel *answer = (HDAnswerModel *)[answers objectAtIndex:(question.seq - 1)];
//                answer.questionId = question.Id;
//                answer.questionSeq = question.seq;
//                answer.optionId = question.optionId;
//            }
//        }
//    }
    
    return answers;
}

/// 显示答题卡
- (void)showAnswerCard {
    if (self.answerCard) [self hideAnswerCardWithAnimated:YES];
//    APP_STATUS_HEIGHT + 40
    CGFloat w = APP_CONTENT_WIDTH;
    CGFloat itemWH = (w-50)/5.0;
    CGFloat h = 250;
    CGFloat y = APP_CONTENT_HEIGHT - h;
    self.answerCard = [[HDTableView alloc] initWithFrame:CGRectMake(0, y, w, h) cellClassName:[HDAnswerCell class] itemSize:CGSizeMake(itemWH, itemWH) sectionInset:UIEdgeInsetsMake(50, 0, 0, 50) blankViewClass:[HDBlankPageView class] refreshType:HD_TABLE_REFRESH_NONE];
    self.answerCard.hdTableViewDelegate = self;
    self.answerCard.backgroundColor = [UIColor whiteColor];
    NSArray *answers = [self getAnswers];
    if (answers) [self.answerCard setTableDataWithAry:answers];
    
    BSbottomModel *model = [BSbottomModel sharedInstance];
    model.backgroundDisplayStyle = BSModalBackgroundDisplayStyleSolid;
    model.showCloseButton = NO;
    [[BSbottomModel sharedInstance] showWithContentView:self.answerCard
                                            andAnimated:YES
                                              showBlock:^{
//                                                  self.answerCardButton.hidden = YES;
                                              }
                                           dismissBlock:^{
//                                               self.answerCardButton.hidden = NO;
                                               [self.answerCard removeFromSuperview];
                                               self.answerCard = nil;
                                           }];
}

/// 隐藏答题卡
- (void)hideAnswerCardWithAnimated:(BOOL)animated
{
    [[BSbottomModel sharedInstance]hideAnimated:animated dismissBlock:^{
        [self.answerCard removeFromSuperview];
        self.answerCard = nil;
    }];
}

#pragma mark - Public Methods
#pragma mark - Getters & Setters

- (void)shareClicked:(id)sender
{
    [[HDShareProxy sharedInstance]share:self title:SHARE_TITLE text:SHARE_CONTENT imageUrl:SHARE_IMAGE_URL image:nil resourceUrl:[HDNetworkConfig getModuleUrl:URL_TYPE_SHARE] completion:^(HDCommonResult *result) {
        [HDTip showMessage:@"分享成功"];
    } viewPoped:nil viewDissMissed:nil];
}

@end
