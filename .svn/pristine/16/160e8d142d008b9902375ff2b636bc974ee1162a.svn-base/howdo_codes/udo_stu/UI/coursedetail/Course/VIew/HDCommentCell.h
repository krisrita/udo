//
//  HDCommentCell.h
//  udo_stu
//
//  Created by nobody on 15/6/11.
//  All rights reserved.
//

#import "HDTableViewCell.h"
#define UIVIEW_TAG 1000

@interface HDCommentCell : HDTableViewCell

@end
