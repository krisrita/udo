//
//  HDCoureseCell.m
//  udo_stu
//
//  Created by nobody on 15/6/5.
//  All rights reserved.
//

#import "HDCoureseCell.h"

@interface HDCoureseCell ()

@property (nonatomic,strong)UILabel *sectionLabel;
@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UIImageView *timeImageView;
@property (nonatomic,strong)UILabel *timeLabel;
/// 笔记
@property (nonatomic,strong)UIImageView *noteImageView;
/// 练习
@property (nonatomic,strong)UIImageView *practiceImageView;
@property (nonatomic,strong)UIView *verticalLine;
@end

@implementation HDCoureseCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self setSelectionStyle:UITableViewCellSelectionStyleGray];
        self.backgroundColor = [UIColor whiteColor];
        
        UIImage *currentCoureseImage = [UIImage imageNamed:@"current_course"];
        _currentCourseImageView = [[UIImageView alloc]init];
        _currentCourseImageView.userInteractionEnabled = YES;
        _currentCourseImageView.image = currentCoureseImage;
        [self.contentView addSubview:_currentCourseImageView];
        
        _sectionLabel = [[UILabel alloc]init];
        _sectionLabel.font = [UIFont systemFontOfSize:12];
        _sectionLabel.textAlignment = NSTextAlignmentLeft;
        _sectionLabel.textColor = UIColorFromRGB(29, 29, 29);
        _sectionLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_sectionLabel];
        
        // 竖线
        UIView *verticalLine = [[UIView alloc]init];
        self.verticalLine = verticalLine;
        self.verticalLine.backgroundColor = UIColorFromRGB(242, 242, 242);
        [self.contentView addSubview:self.verticalLine];
        
        UIImage *markImage = [UIImage imageNamed:@"coure_learned"];
        _markImageView = [[UIImageView alloc]init];
        _markImageView.image = markImage;
        [self.contentView addSubview:_markImageView];
        
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.font = [UIFont systemFontOfSize:12];
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        _titleLabel.text = @"集合的概念";
        _titleLabel.textColor = UIColorFromRGB(29, 29, 29);
        _titleLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_titleLabel];
        
        UIImage *timeImage = [UIImage imageNamed:@"time"];
        _timeImageView = [[UIImageView alloc]init];
        _timeImageView.image = timeImage;
        [self.contentView addSubview:_timeImageView];
        
        _timeLabel = [[UILabel alloc]init];
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.textAlignment = NSTextAlignmentLeft;
        _timeLabel.text = @"集合的概念";
        _timeLabel.textColor = UIColorFromRGB(163, 163, 163);
        _timeLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_timeLabel];
        
        UIImage *panImage = [UIImage imageNamed:@"pan"];
        _noteImageView = [[UIImageView alloc]init];
        _noteImageView.contentMode = UIViewContentModeCenter;
        _noteImageView.userInteractionEnabled = YES;
        _noteImageView.image = panImage;
        [self.contentView addSubview:_noteImageView];
        WS(ws);
        [self.noteImageView bk_whenTapped:^{
            if ([ws.delegate respondsToSelector:@selector(courseCell:selectedPan:)]) {
                [ws.delegate courseCell:ws selectedPan:ws.noteImageView];
            }
        }];
        UIImage *noteImage = [UIImage imageNamed:@"training"];
        _practiceImageView = [[UIImageView alloc]init];
        _practiceImageView.contentMode = UIViewContentModeCenter;
        _practiceImageView.userInteractionEnabled = YES;
        _practiceImageView.image = noteImage;
        [self.contentView addSubview:_practiceImageView];
       
        [self.practiceImageView bk_whenTapped:^{
            if ([ws.delegate respondsToSelector:@selector(courseCell:selectedNote:)]) {
                [ws.delegate courseCell:ws selectedNote:ws.noteImageView];
            }
        }];
        
        // 分割线
        [self.contentView addSubview:[HDUICommon sectionSplitLine:44.5]];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (void)setSectionModel:(HDSectionModel *)sectionModel
{
    _sectionModel = sectionModel;
    self.titleLabel.text = self.sectionModel.name;
    self.timeLabel.text = self.sectionModel.duration.ENAUTOHHMMSS;
    self.sectionLabel.text = conversionstring(_sectionModel.seq);
    if (self.sectionModel.hasOpened) {
        self.titleLabel.textColor =  UIColorFromRGB(29, 29, 29);
        self.sectionLabel.textColor =  UIColorFromRGB(29, 29, 29);
        if (self.sectionModel.hasStudied) {
            self.markImageView.image = [UIImage imageNamed:@"coure_learned"];

        }else{
            self.markImageView.image = [UIImage imageNamed:@"course_unlearned"];

        }
        self.noteImageView.userInteractionEnabled = YES;
        self.practiceImageView.userInteractionEnabled = YES;
    }else{
        self.titleLabel.textColor = UIColorFromRGB(163, 163, 163);
        self.sectionLabel.textColor = UIColorFromRGB(163, 163, 163);
         self.markImageView.image = [UIImage imageNamed:@"course_unlearned"];
        self.noteImageView.userInteractionEnabled = NO;
        self.practiceImageView.userInteractionEnabled  =NO;
    }
    if (self.sectionModel.isLast) {
        self.currentCourseImageView.hidden = NO;
    }else{
        self.currentCourseImageView.hidden = YES;
    }
    [self setSubviewsLayout];
}

-(void)setSubviewsLayout
{
    WS(ws);
    
    [self.currentCourseImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(14.0, 15.0));
        make.centerY.equalTo(ws.contentView);
        make.left.equalTo(ws.contentView).offset(10);
    }];
//    CGSize sectionSize = [self.sectionLabel.text fitSize:self.titleLabel.font contentWidth:APP_CONTENT_WIDTH maxHeight:100];
//    self.sectionLabel.backgroundColor = [UIColor redColor];
    [self.sectionLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws.contentView).offset(40);
        make.width.equalTo(@(15));
        make.top.equalTo(ws.contentView);
        make.bottom.equalTo(ws.contentView);
    }];
    
    
    [self.markImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws.contentView).offset(60);
        make.centerY.equalTo(ws.contentView);
    }];
    
    [self.verticalLine mas_updateConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(ws.markImageView).priorityLow();
        make.height.equalTo(ws.contentView);
        make.width.equalTo(@(0.5));
    }];
   
    [self.titleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.contentView);
        make.left.equalTo(ws.markImageView.mas_right).offset(8);
         make.right.lessThanOrEqualTo(ws.timeImageView.mas_left).with.offset(-10);
    }];
    [self.timeImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.timeLabel.mas_left).offset(-5);
        make.centerY.equalTo(ws.contentView);
    }];
    CGSize timeSize = [self.timeLabel.text fitSize:self.titleLabel.font contentWidth:APP_CONTENT_WIDTH maxHeight:100];
    
    [self.timeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.practiceImageView.mas_left).offset(-20);
        make.centerY.equalTo(ws.contentView);
        make.width.equalTo(@(timeSize.width+10));
        
    }];

    // 笔记，后
    [self.noteImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.contentView.mas_right);
        make.centerY.equalTo(ws.contentView);
        make.size.mas_equalTo(CGSizeMake(37.0, 45.0));
    }];
    
    // 练习，前
    [self.practiceImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.noteImageView.mas_left);
        make.centerY.equalTo(ws.contentView);
        make.size.mas_equalTo(CGSizeMake(37.0, 45.0));
    }];
    
    //设置label1的content hugging 为1000
    [self.titleLabel setContentHuggingPriority:UILayoutPriorityRequired
                               forAxis:UILayoutConstraintAxisHorizontal];
    
    //设置label1的content compression 为1000UILayoutPriorityDefaultLow
    [self.titleLabel setContentCompressionResistancePriority:UILayoutPriorityDefaultLow
                                             forAxis:UILayoutConstraintAxisHorizontal];
    
    //设置右边的label2的content hugging 为1000
    [self.timeImageView setContentHuggingPriority:UILayoutPriorityRequired
                               forAxis:UILayoutConstraintAxisHorizontal];
    
    //设置右边的label2的content compression 为250
    [self.timeImageView setContentCompressionResistancePriority:UILayoutPriorityRequired
                                             forAxis:UILayoutConstraintAxisHorizontal];
}
+(float)dynamicHeight:(id)data
{
    return 0;
}
@end
