//
//  HDPaperCell.h
//  udo_stu
//
//  Created by nobody on 15/7/2.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPaper;

/**
 *  试卷cell
 */
@interface HDPaperCell : UITableViewCell
/**
 *  试卷模型
 */
@property (nonatomic, strong) HDPaper *paper;
@end
