//
//  HDUserIntrodutionCell.h
//  udo_stu
//
//  Created by nobody on 15/6/23.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDUserIntrodutionCell : UITableViewCell

@property (nonatomic,strong)HDCourseIntroModel *coureseIntroModel;


- (void)setCoureseIntroModel:(HDCourseIntroModel *)coureseIntroModel isHeadImageView:(BOOL)isHeadImageview;
- (void)setCoureseIntroModel:(HDCourseIntroModel *)coureseIntroModel isHeadImageView:(BOOL)isHeadImageview indexPath:(NSIndexPath *)indexPath;

+(float)dynamicHeight:(id)data isHeadImageView:(BOOL)isHeadImageview;
+(float)dynamicHeight:(id)data isHeadImageView:(BOOL)isHeadImageview indexPath:(NSIndexPath *)indexPath;
@end
