//
//  HDPaperAnswerCardCell.m
//  udo_stu
//
//  Created by mayun on 15/7/16.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "HDPaperAnswerCardCell.h"
#import "HDAnswerCardView.h"
#import "HDAnswerCell.h"

@interface HDPaperAnswerCardCell ()<HDTableViewDelegate, HDTableViewCellDelegate>

@property (nonatomic, strong) HDTableView *tableView;
@end

@implementation HDPaperAnswerCardCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.tableView = [[HDTableView alloc] initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, self.frame.size.height) cellClassName:[HDAnswerCell class] itemSize:CGSizeMake((self.frame.size.width-50)/5.0, (self.frame.size.width-50)/5.0) sectionInset:UIEdgeInsetsMake(50, 0, 0, 50) blankViewClass:[HDBlankPageView class] refreshType:HD_TABLE_REFRESH_NONE];
        self.tableView.hdTableViewDelegate = self;
        [self.contentView addSubview:self.tableView];
    }
    return self;
}

- (void)setAnswers:(NSArray *)answers
{
    if (!answers) {
        return;
    }
    _answers = answers;
    [self.tableView setTableDataWithAry:answers];
}

- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag
{
    if ([self.cellDelegate respondsToSelector:@selector(paperAnswerCardCell:didSelectSeq:)]) {
        [self.cellDelegate paperAnswerCardCell:self didSelectSeq:tag];
    }
}


@end
