//
//  HDPaperDetailCell.h
//  udo_stu
//
//  Created by nobody on 15/7/4.
//   All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPaperDetailCell;

@protocol HDPaperDetailCellDelegate <NSObject>

/// 点击了右下角的看视频按钮
- (void)paperDetailCellDidClickWatchVideo:(HDPaperDetailCell *)paperDetailCell;

@end

@interface HDPaperDetailCell : UICollectionViewCell

@property (nonatomic, weak) id<HDPaperDetailCellDelegate> cellDelegate;

@property (nonatomic, copy) NSString *urlStr;

@end
