//
//  HDCourseDetailViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/1.
//  All rights reserved.
//

#import "HDCourseDetailViewController.h"
#import "HDCourseViewController.h"
#import "HDIntroductionViewController.h"
#import "HDCommentViewController.h"
#import "HDCommentViewController.h"
#import "HDExaminationPaperViewController.h"

@interface HDCourseDetailViewController ()

@end

@implementation HDCourseDetailViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.tag = TAG_PRACTISE_REPORT_BACK_TO;
    self.leftView = [HDUICommon leftBackView:self];
    self.automaticallyAdjustsScrollViewInsets = NO;
    // Do any additional setup after loading the view.
    [self.buttonBarView setBackgroundColor:[UIColor whiteColor]];
    [self.buttonBarView.selectedBar setBackgroundColor:UIColorFromRGB(34, 177, 139)];
     [self.view bringSubviewToFront:self.headView];
    [self reloadPagerTabStripView];
 
    self.centerView = [HDUICommon getTitleView:self.courseModel.name];
}

- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}
#pragma mark - XLPagerTabStripViewControllerDataSource

-(NSArray *)childViewControllersForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController
{
    NSMutableArray *childViewController = [[NSMutableArray alloc]init];
    // create child view controllers that will be managed by XLPagerTabStripViewController

    if (self.courseModel.type == HDCouseListTypeCourse) {
        // 课程
        HDCourseViewController * courseViewController = [[HDCourseViewController alloc] init];
        courseViewController.courseModel = self.courseModel;
        [childViewController addObject:courseViewController];
    } else if (self.courseModel.type == HDCouseListTypePaper) {
        // 试卷
        HDExaminationPaperViewController * paperViewController = [[HDExaminationPaperViewController alloc] init];
        paperViewController.courseModel = self.courseModel;
        [childViewController addObject:paperViewController];
    }
    
    
    HDIntroductionViewController * introductionViewController = [[HDIntroductionViewController alloc] init];
    introductionViewController.courseModel = self.courseModel;
    [childViewController addObject:introductionViewController];
    
    HDCommentViewController * commentViewController = [[HDCommentViewController alloc] init];
    commentViewController.courseModel = self.courseModel;
    [childViewController addObject:commentViewController];

    return childViewController;
}

-(void)pagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController updateIndicatorFromIndex:(NSInteger)fromIndex toIndex:(NSInteger)toIndex
{
    [self.buttonBarView moveToIndex:toIndex animated:YES swipeDirection:XLPagerTabStripDirectionNone];
    NSLog(@"self.pagerTabStripChildViewControllers[toIndex]::%@",self.pagerTabStripChildViewControllers[toIndex]);
}
#pragma merk - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGSize size = CGSizeMake(APP_CONTENT_WIDTH/3, collectionView.frame.size.height);
    size.width -= 7;
    return size;
}
@end
