//
//  HDUserIntrodutionCell.m
//  udo_stu
//
//  Created by nobody on 15/6/23.
//  All rights reserved.
//

#import "HDUserIntrodutionCell.h"

@interface HDUserIntrodutionCell ()
{
    BOOL isHeadImage;
}

@property(nonatomic,strong)UILabel *userInfoLabel;
@end

@implementation HDUserIntrodutionCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        isHeadImage = YES;
        // Initialization code
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        self.backgroundColor = [UIColor whiteColor];
        
        
        _userInfoLabel = [[UILabel alloc]init];
        _userInfoLabel.numberOfLines = 0;
        _userInfoLabel.textColor = UIColorFromRGB(29, 29, 29);
        
        _userInfoLabel.font = [UIFont systemFontOfSize:12];
        _userInfoLabel.textAlignment = NSTextAlignmentLeft;
        _userInfoLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_userInfoLabel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (void)setCoureseIntroModel:(HDCourseIntroModel *)coureseIntroModel isHeadImageView:(BOOL)isHeadImageview
{
    isHeadImage = isHeadImageview;
    _coureseIntroModel = coureseIntroModel;
    
        _userInfoLabel.text = coureseIntroModel.introduction;
        
    
    [self setSubviewsLayout];
}
- (void)setCoureseIntroModel:(HDCourseIntroModel *)coureseIntroModel isHeadImageView:(BOOL)isHeadImageview indexPath:(NSIndexPath *)indexPath
{
    isHeadImage = isHeadImageview;
    _coureseIntroModel = coureseIntroModel;
        _userInfoLabel.text = coureseIntroModel.introduction;
        

    [self setSubviewsLayout];
}
-(void)setSubviewsLayout
{
    WS(ws);
    
    
        [self.userInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws.contentView).offset(15);
            make.right.equalTo(ws.contentView).offset(-15);
            make.top.equalTo(ws.contentView).offset(10);
            
        }];
    
    
}
+(float)dynamicHeight:(HDCourseIntroModel *)data isHeadImageView:(BOOL)isHeadImageview
{

        CGSize size = [data.introduction fitSize:[UIFont systemFontOfSize:12] contentWidth:APP_CONTENT_WIDTH-30 maxHeight:1000];
        return size.height+15;

}
+(float)dynamicHeight:(HDCourseIntroModel *)data isHeadImageView:(BOOL)isHeadImageview indexPath:(NSIndexPath *)indexPath
{
    
        CGSize size = [data.introduction fitSize:[UIFont systemFontOfSize:12] contentWidth:APP_CONTENT_WIDTH-30 maxHeight:1000];
        return size.height+15;
}
@end
