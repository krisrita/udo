//
//  HDPaperCell.m
//  udo_stu
//
//  Created by nobody on 15/7/2.
//  All rights reserved.
//

#import "HDPaperCell.h"
#import "HDPaper.h"

@interface HDPaperCell ()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;

@property (weak, nonatomic) IBOutlet UILabel *paperNameLabel;

@end

@implementation HDPaperCell

- (void)awakeFromNib {
    // Initialization code
    [self setSelectionStyle:UITableViewCellSelectionStyleGray];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setPaper:(HDPaper *)paper {
    if (!paper) return;
    _paper = paper;
    self.iconView.hidden = !paper.isLast;
    self.paperNameLabel.text = paper.name;
}

@end
