//
//  HDCommentViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/1.
//  All rights reserved.
//

#import "HDCommentViewController.h"
#import "XLPagerTabStripViewController.h"
#import "HDCommentCell.h"
#import "HDCommentHeadView.h"
#import "HDCommentDetailBottom.h"
#import "HDMainBlankPageView.h"

#define bottomViewHeight 50
@interface HDCommentViewController ()<XLPagerTabStripChildItem,HDTableViewDelegate,HDTableViewCellDelegate,CommentBottomDelegate>
{
    NSIndexPath *currentIndexPath;
    NSInteger lastCommentId;
    CGFloat _lastPosition;
    NSInteger _lastDirection;

}
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)HDTableView *hdTableView;
@property (nonatomic,strong)HDCommentHeadView *tableHeadView;
@property (nonatomic, strong) HDCommentDetailBottom *bottomView;

@end


@implementation HDCommentViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.headView.hidden = YES;
    lastCommentId = 0;
    [self initLoadView];
    [self buildBottomView];
    self.hdTableView.HDTableIsRefreshing = YES;
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    [self requestData];
}

- (void)initLoadView
{
    HDTableView *hdTableView = [[HDTableView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, 0) rowHeightType:HD_CELL_HEIGHT_TYPE_DYNAMIC cellClassName:[HDCommentCell class] blankViewClass:[HDMainBlankPageView class] refreshType:HD_TABLE_REFRESH_UPDOWN];
    self.hdTableView = hdTableView;
    hdTableView.hdTableViewDelegate = self;
    [self.view addSubview:self.hdTableView];
    
    [self builtHeadView];
    [self.view addSubview:self.tableHeadView];
    [self.view bringSubviewToFront:self.headView];
}
- (void)builtHeadView
{
    HDCommentHeadView *headView = [[HDCommentHeadView alloc]initWithFrame:CGRectMake(0, 104, APP_CONTENT_WIDTH, 40)];
    [headView setInfoWithModel:self.courseModel];
    self.tableHeadView = headView;
    
}
-(void)buildBottomView{
    // 底部输入框
    _bottomView = [[HDCommentDetailBottom alloc]initWithFrame:CGRectMake(0, APP_CONTENT_HEIGHT-bottomViewHeight, APP_CONTENT_WIDTH, bottomViewHeight)];
    _bottomView.delegate = self;
    [self.view addSubview:_bottomView];
}
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    self.hdTableView.frame =  CGRectMake(0,0, APP_CONTENT_WIDTH,APP_CONTENT_HEIGHT-bottomViewHeight);
    self.hdTableView.tableViewEdgeinsets = UIEdgeInsetsMake(104+40, 0, 0, 0);
    //    secionBlankPageView = [[MCSectionBlankPageView alloc]initWithFrame:self.tableview.frame];
}
- (void)requestData
{
    WS(ws);
    [[HDManager sharedInstance].courseService getCommentList:self.courseModel.Id lastCommentId:lastCommentId resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS) {
                if (lastCommentId==0) {
                    [ws.hdTableView setTableDataWithAry:object];
                }else{
                    [ws.hdTableView tableAppendDataWithAry:object];
                }
        }else if (HD_RESULT_CODE_NETWORK_FAILURE == result.resultCode) {
                    [self.hdTableView setTableDataWithAry:nil];
                    [self.hdTableView setTableNetworkFailure];
                
        
        }else if (HD_RESULT_CODE_FAILURE == result.resultCode)
        {
            [self.hdTableView setTableDataWithAry:nil];
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (0 == lastCommentId) {
                self.hdTableView.HDTableIsRefreshing = NO;
            }else {
                self.hdTableView.HDTableIsLoadingMore = NO;
            }
        });
        
    }];
}


- (void)HDTableViewDidTriggerRefresh:(HDTableView*)pullTableView
{
    lastCommentId = 0;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self requestData];
    });
}
- (void)HDTableViewDidTriggerLoadMore:(HDTableView*)pullTableView
{
    HDCommentModel *model = [[self.hdTableView getTableDataAry] lastObject];
    lastCommentId = model.Id;
    
    [self requestData];
    
}
- (void)HDTableViewSubviewDidSelected:(id)cell tag:(NSInteger)tag
{
    HDCommentCell *commentCell = cell;
    HDCommentModel *model = commentCell.cellData;
    switch (tag) {
        case UIVIEW_TAG+1: //举报
        {
            [self.view endEditing:YES];
            [[HDManager sharedInstance].courseService reportComment:model.Id resultBack:^(HDServiceResult *result, id object) {
                switch (result.resultCode) {
                    case HD_RESULT_CODE_SUCCESS:
                    case HD_RESULT_CODE_EMPTY:{
                        
                        break;
                    }
                  
                    case HD_RESULT_CODE_FAILURE: {
                        
                        break;
                    }
                    case HD_RESULT_CODE_NETWORK_FAILURE: {
                        
                        break;
                    }
                    default: {
                        break;
                    }
                }
                [HDTip showMessage:@"举报成功"];
            }];
        }
            break;
        case UIVIEW_TAG+2:
        {
            NSIndexPath *indexPath = [self.hdTableView indexPathForCell:cell];
            currentIndexPath = indexPath;
            NSMutableArray *mutableArray = [self.hdTableView getTableDataAry];
            HDCommentModel *model = mutableArray[currentIndexPath.row];
            [self.bottomView editComment:[NSString stringWithFormat:@"回复%@:",model.sender.nickname]];
        }
            break;
        default:
            break;
    }
}

#pragma mark - CommentBottomDelegate
- (void)sendComment:(HDCommentTextInput *)textInput
{
    CGRect bottomViewFrame = self.bottomView.frame;
    if (bottomViewFrame.size.height > 50.0) {
        bottomViewFrame.size.height = 50.0;
    }
    self.bottomView.frame = bottomViewFrame;
    
    [self.view endEditing:YES];
    NSString *text = textInput.textView.text;
    if ([text isEqualToString:@""] || textInput.textView.text.length == 0) {
        [HDTip showMessage:@"评论不能为空"];
        return;
    }
    if ([[text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length] == 0) {
        [HDTip showMessage:@"评论不能为空"];
        return;
    }

    NSInteger sectionId = 0;
    NSInteger replyCommentId = 0;
    if (currentIndexPath) {
       NSMutableArray *mutableArray = [self.hdTableView getTableDataAry];
        HDCommentModel *model = mutableArray[currentIndexPath.row];
        sectionId = model.section.Id;
        replyCommentId = model.Id;
    }
    __weak __typeof(self)weakSelf = self;
    [[HDManager sharedInstance].courseService sendComment:textInput.textView.text courseId:self.courseModel.Id videoId:0 replyCommentId:replyCommentId resultBack:^(HDServiceResult *result, id object) {
        if (!weakSelf) return;
        switch (result.resultCode) {
            case HD_RESULT_CODE_SUCCESS:
            case HD_RESULT_CODE_EMPTY:{
                dispatch_async(dispatch_get_main_queue(), ^{
                    __strong __typeof(weakSelf)strongSelf = weakSelf;
                    textInput.textView.text = @"";
                    [strongSelf.bottomView setPlaceHolderText:@""];
                    currentIndexPath = nil;
                    
                    NSMutableArray *mutableArray = [[strongSelf.hdTableView getTableDataAry] mutableCopy];
                    [mutableArray insertObject:object atIndex:0];
                    [strongSelf.hdTableView setTableDataWithAry:mutableArray];
                    // 刷新评论总数
                    strongSelf.courseModel.commentNum++;
                    [strongSelf.tableHeadView setInfoWithModel:strongSelf.courseModel];
                });
                break;
            }
            case HD_RESULT_CODE_FAILURE: {
                
                break;
            }
            case HD_RESULT_CODE_NETWORK_FAILURE: {
                
                break;
            }
            default: {
                break;
            }
        }
    }];
    [textInput.textView resignFirstResponder];

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSInteger direction = 0;
    CGFloat currentPostion = scrollView.contentOffset.y;
    if (currentPostion - _lastPosition > 25) {
        _lastPosition = currentPostion;
        direction = 1;
    }
    else if (_lastPosition - currentPostion > 25)
    {
        _lastPosition = currentPostion;
        direction = 2;
    }
    
    if (direction > 0 && direction != _lastDirection) {
        if ([self.bottomView.input.textView isFirstResponder]) {
            [self.bottomView.input.textView resignFirstResponder];
            [self.bottomView setPlaceHolderText:@""];
            currentIndexPath = nil;
        }
        _lastDirection = direction;
    }
}
-(void)HDTableViewDidSelected:(id)data didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.bottomView.input.textView isFirstResponder]) {
        [self.bottomView.input.textView resignFirstResponder];
        [self.bottomView setPlaceHolderText:@""];
        currentIndexPath = nil;
    }else{
       HDLogInfo(@"didSelectRowAtIndexPath");
    }
}
#pragma mark - XLPagerTabStripViewControllerDelegate

-(NSString *)titleForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController
{
    return @"评论";
}

-(UIColor *)colorForPagerTabStripViewController:(XLPagerTabStripViewController *)pagerTabStripViewController
{
    return [UIColor whiteColor];
}
@end
