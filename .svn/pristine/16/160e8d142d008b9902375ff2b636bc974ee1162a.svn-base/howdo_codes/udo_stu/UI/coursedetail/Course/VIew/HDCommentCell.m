//
//  HDCommentCell.m
//  udo_stu
//
//  Created by nobody on 15/6/11.
//  All rights reserved.
//

#import "HDCommentCell.h"
#import "NimbusKitAttributedLabel.h"

@interface HDCommentCell ()

@property(nonatomic,strong)HDImageView *headImageView;
@property(nonatomic,strong)UILabel *nicknameLabel;
@property (nonatomic ,strong)UILabel *titleLabel;
@property (nonatomic,strong)UILabel *timeLabel;
@property (nonatomic ,strong)UILabel *contentLabel;

@property(nonatomic,strong)UIView *lineView;

@property (nonatomic ,strong)NIAttributedLabel *actionStatusLabel;

@property (nonatomic ,strong)UIImageView *replyImageView;
/// 举报
@property (nonatomic ,strong)UILabel *reportLabel;
@property (nonatomic,strong)UIView *bottomLineView;
@end
@implementation HDCommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        // Initialization code
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        
        _headImageView = [[HDImageView alloc]init];
        [self.contentView addSubview:_headImageView];
        
        _nicknameLabel = [[UILabel alloc]init];
        _nicknameLabel.numberOfLines = 1;
        _nicknameLabel.textAlignment = NSTextAlignmentLeft;
        _nicknameLabel.textColor = UIColorFromRGB(29, 29, 20);
        _nicknameLabel.font = [UIFont systemFontOfSize:12];;
        _nicknameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView  addSubview:_nicknameLabel];
        
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.numberOfLines = 1;
        _titleLabel.textColor = UIColorFromRGB(29, 29, 29);
        _titleLabel.font = [UIFont systemFontOfSize:12];
        _titleLabel.textAlignment = NSTextAlignmentRight;

        _titleLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_titleLabel];
        
        _timeLabel = [[UILabel alloc]init];
        _timeLabel.backgroundColor = [UIColor clearColor];
        _timeLabel.textColor = UIColorFromRGB(163, 163, 163);
        _timeLabel.font = [UIFont systemFontOfSize:12];;

        [self.contentView addSubview:_timeLabel];
        
        _contentLabel = [[UILabel alloc]init];
        _contentLabel.font = [UIFont systemFontOfSize:12];;
        _contentLabel.numberOfLines = 0;
        _contentLabel.textColor = UIColorFromRGB(29, 29, 29);
        _contentLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_contentLabel];
        
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = UIColorFromRGB(240, 240, 240);
        [self.contentView addSubview:_lineView];
        
        _reportLabel = [[UILabel alloc]init];
        _reportLabel.userInteractionEnabled = YES;
        _reportLabel.font = [UIFont systemFontOfSize:12];
        _reportLabel.textColor = UIColorFromRGB(29, 29, 29);
        _reportLabel.backgroundColor = [UIColor clearColor];
        self.reportLabel.tag = UIVIEW_TAG+1;
        [self.contentView addSubview:_reportLabel];
        
        UIImage *remportImage = [UIImage imageNamed:@"comment_default"];
        UIImageView *replyImageView = [[UIImageView alloc]initWithImage:remportImage];
        replyImageView.userInteractionEnabled = YES;
        self.replyImageView = replyImageView;
        self.replyImageView.tag = UIVIEW_TAG+2;
        [self.contentView addSubview:replyImageView];
        WS(ws);
        [self.replyImageView bk_whenTapped:^{
            
            if ([ws.delegate respondsToSelector:@selector(HDTableViewSubviewDidSelected:tag:)]) {
                [ws.delegate HDTableViewSubviewDidSelected:ws tag:ws.replyImageView.tag];
            }
            
        }];
        
        // 举报
        [self.reportLabel bk_whenTapped:^{
            
            if ([ws.delegate respondsToSelector:@selector(HDTableViewSubviewDidSelected:tag:)]) {
                [ws.delegate  HDTableViewSubviewDidSelected:ws tag:ws.reportLabel.tag];
            }
        }];
        
        _actionStatusLabel = [[NIAttributedLabel alloc]init];
        _actionStatusLabel.font = [UIFont systemFontOfSize:12];;
        _actionStatusLabel.backgroundColor = [UIColor clearColor];
        _actionStatusLabel.textColor = UIColorFromRGB(163, 163, 163);
        [self.contentView addSubview:_actionStatusLabel];
        
        _bottomLineView = [[UIView alloc]init];
        _bottomLineView.backgroundColor = UIColorFromRGB(240, 240, 240);
        [self.contentView addSubview:_bottomLineView];
        [self setupConstraints]; //添加约束
    }
    return self;
}

#pragma mark 添加约束
- (void)setupConstraints {
    
    // 右上角的评论出处，章节名
    [self.titleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(12);
        make.right.equalTo(self.contentView).offset(-8);
        make.size.mas_equalTo(CGSizeMake(200.f, 21.f));
    }];
}

-(void)setCellData:(id)cellData
{
    [super setCellData:cellData];
    HDCommentModel *commentModel = (HDCommentModel *)cellData;
    
    // 章节名
    NSString *sectionName = commentModel.section.name;
    if (commentModel.practise_seq > 0) {
        sectionName = [sectionName stringByAppendingFormat:@" 第%ld题", (long)commentModel.practise_seq];
    }
    self.titleLabel.text = sectionName;
    
    [self.headImageView setHDImageURL:[NSURL URLWithString:commentModel.sender.imageUrl.small] placeholderImage:[UIImage imageNamed:@"headImage_placeholder"] imageType:HD_IMAGE_CIRCLE];
    self.nicknameLabel.text = commentModel.sender.nickname;
    self.timeLabel.text = commentModel.sentTime.INTERVALAGO;
    if (commentModel.isReply) {
       self.contentLabel.attributedText = [self getAttributedString:[NSString stringWithFormat:@"回复%@:%@",commentModel.replyUser.nickname,commentModel.content] color:UIColorFromRGB(45, 160, 220) range:NSMakeRange(2, [NSString stringWithFormat:@"%@",commentModel.replyUser.nickname].length)];
    }else{
      self.contentLabel.text = commentModel.content;
    }
    
    NSString *genderCall = (HD_GENDER_FEMALE == commentModel.sender.gender) ? @"她" : @"他";
    switch (commentModel.actionStatus) {
        case HD_ACTION_STATUS_NONE:
            self.actionStatusLabel.text = @"";
            break;
        case HD_ACTION_STATUS_LIKED:
            
            self.actionStatusLabel.text = [NSString stringWithFormat:@"%@%@", genderCall, @"了该讲解"];
            [self.actionStatusLabel insertImage:[UIImage imageNamed:@"up"] atIndex:genderCall.length
                                        margins:UIEdgeInsetsZero verticalTextAlignment:NIVerticalTextAlignmentMiddle];
            break;
        case HD_ACTION_STATUS_UNLIKEd:
            self.actionStatusLabel.text = [NSString stringWithFormat:@"%@%@", genderCall, @"了该讲解"];
            [self.actionStatusLabel insertImage:[UIImage imageNamed:@"down"] atIndex:genderCall.length
                                        margins:UIEdgeInsetsZero verticalTextAlignment:NIVerticalTextAlignmentMiddle];

            break;
        default:
            break;
    }
    self.reportLabel.text = @"举报";
    [self setSubviewsLayout];
}

-(void)setSubviewsLayout
{
    WS(ws);
   
    
    [self.headImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.contentView).offset(15);
        make.left.equalTo(ws.contentView).offset(9);
        make.width.equalTo(@(50));
        make.height.equalTo(@(50));
    }];
    
    [self.nicknameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.headImageView);
        make.left.equalTo(ws.headImageView.mas_right).offset(10);
        make.width.equalTo(@(200));
    }];
    
    [self.timeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.nicknameLabel.mas_bottom).offset(10);
        make.left.equalTo(ws.nicknameLabel);
    }];
    [self.lineView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.headImageView.mas_bottom).offset(10);
        make.left.equalTo(ws.contentView).offset(40);
        make.right.equalTo(ws.contentView).offset(-40);
        make.height.equalTo(@(0.5));
    }];
    [self.contentLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.lineView.mas_bottom).offset(10);
        make.left.equalTo(ws.contentView).offset(70);
        make.right.equalTo(ws.contentView).offset(-70);
    }];
 
    
    [self.actionStatusLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.contentView).offset(-10);
        make.left.equalTo(ws.contentView).offset(50);
    }];
    [self.replyImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.contentView.mas_bottom).offset(-7);
        make.right.equalTo(ws.reportLabel.mas_left).offset(-15);
    }];
    [self.reportLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.contentView.mas_bottom).offset(-6);
        make.right.equalTo(ws.contentView);
        make.size.mas_equalTo(CGSizeMake(45, 30));
    }];
    [self.bottomLineView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.contentView);
        make.left.equalTo(ws.contentView).offset(40);
        make.right.equalTo(ws.contentView).offset(-40);
        make.height.equalTo(@(0.5));
    }];
}

+(float)dynamicHeight:(id)data
{
    HDCommentModel *commentModel = data;
    CGSize size = [[NSString stringWithFormat:@"回复%@:%@",commentModel.replyUser.nickname,commentModel.content] fitSize:[UIFont systemFontOfSize:15] contentWidth:APP_CONTENT_WIDTH-140 maxHeight:1000];
    return 15+50+20+size.height+20+20;
}
- (void)layoutSubviews
{
    [super layoutSubviews];
}
-(NSMutableAttributedString *)getAttributedString:(NSString *)text color:(UIColor *)textColor range:(NSRange)range;
{
    NSMutableAttributedString *attriString = [[NSMutableAttributedString alloc] initWithString:text];
    
    [attriString addAttribute:(NSString *)NSForegroundColorAttributeName
                        value:textColor
                        range:range];
    NSMutableParagraphStyle* paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByCharWrapping;
    [attriString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle
                        range:NSMakeRange(0, text.length)];
    return attriString;
}

@end
