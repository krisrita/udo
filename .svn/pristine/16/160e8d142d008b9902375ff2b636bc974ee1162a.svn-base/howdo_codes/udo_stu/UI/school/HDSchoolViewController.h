//
//  HDSchoolViewController.h
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDBaseViewController.h"

/**
 *  学校列表
 */
@interface HDSchoolViewController : HDBaseViewController

@end
