//
//  HDSchoolCell.h
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDCollectionViewCell.h"

@interface HDSchoolCell : HDCollectionViewCell

@property (nonatomic,strong) id cellData;

@end
