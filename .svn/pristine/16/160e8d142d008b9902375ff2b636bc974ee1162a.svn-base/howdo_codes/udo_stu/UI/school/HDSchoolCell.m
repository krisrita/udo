//
//  HDSchoolCell.m
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDSchoolCell.h"

@interface HDSchoolCell ()

@property (nonatomic, strong) HDImageView *schoolImageView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *titleLabel;

@end

@implementation HDSchoolCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _schoolImageView = [[HDImageView alloc] init];
        self.layer.masksToBounds = YES;
        [self.contentView addSubview:_schoolImageView];
        
        
        UIView *labelBg = [[UIView alloc] init];
        labelBg.backgroundColor = UIColorFromRGBA(0, 0, 0, 0.5);
        [self.contentView addSubview:labelBg];
        
        _nameLabel = [[UILabel alloc] init];
        _nameLabel.textColor = UIColorFromRGB(255, 255, 255);
        _nameLabel.font = [UIFont boldSystemFontOfSize:15];
        [labelBg addSubview:_nameLabel];
        
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = UIColorFromRGB(255, 255, 255);
        _titleLabel.font = [UIFont systemFontOfSize:12];
        [labelBg addSubview:_titleLabel];
        
        WS(ws);
        [_schoolImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws).offset(0);
            make.right.equalTo(ws).offset(0);
            make.bottom.equalTo(ws).offset(0);
            make.top.equalTo(ws).offset(0);
        }];
        
        [labelBg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws).offset(0);
            make.right.equalTo(ws).offset(0);
            make.bottom.equalTo(ws).offset(0);
            make.height.equalTo(@(53));
        }];
        
        [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(labelBg).offset(10);
            make.right.equalTo(labelBg).offset(-10);
            make.top.equalTo(labelBg).offset(8);
        }];
        
        [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(labelBg).offset(10);
            make.right.equalTo(labelBg).offset(-10);
            make.bottom.equalTo(labelBg).offset(-8);
        }];

    }
    return self;
}

-(void)setCellData:(id)cellData
{
    HDSchoolModel *schoolModel = (HDSchoolModel *)cellData;
    
    if (schoolModel) {
        [_schoolImageView setHDImageURL:[NSURL URLWithString:[schoolModel.imageUrl large]] placeholderImage:nil imageType:HD_IMAGE_SQUARE];
        
        _nameLabel.text = schoolModel.name;
        _titleLabel.text = schoolModel.title;
    }
}

@end
