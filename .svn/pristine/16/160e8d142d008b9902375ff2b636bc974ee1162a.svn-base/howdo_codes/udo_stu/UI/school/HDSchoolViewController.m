//
//  HDSchoolViewController.m
//  udo_stu
//
//  Created by nobody on 6/29/15.
//  All rights reserved.
//

#import "HDSchoolViewController.h"
#import "HDSchoolCell.h"
#import "HDMainViewController.h"

@interface HDSchoolViewController () <HDTableViewDelegate>

@property (nonatomic, strong) HDTableView *tableView;

@end

@implementation HDSchoolViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.leftView = [HDUICommon MenuView:self];
    self.centerView = [HDUICommon getTitleView:@"UDO课堂"];

    _tableView = [[HDTableView alloc] initWithFrame:CGRectMake(0, APP_STATUS_HEIGHT, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT-APP_STATUS_HEIGHT) cellClassName:[HDSchoolCell class] itemSize:CGSizeMake((APP_CONTENT_WIDTH-2)/2.0, (APP_CONTENT_WIDTH-2)/2.0) sectionInset:UIEdgeInsetsMake(2, 0, 0, 2) blankViewClass:[HDBlankPageView class] refreshType:HD_TABLE_REFRESH_DOWN];
    _tableView.hdTableViewDelegate = self;
    [self.view addSubview:_tableView];
    
    [self requestSchoolList:0];
}

-(void)leftMenu:(UIButton *)sender
{
    [self.revealSideViewController pushOldViewControllerOnDirection:PPRevealSideDirectionLeft withOffset:OFFSET animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)requestSchoolList:(NSInteger)lastSchoolId
{
    [[HDManager sharedInstance].courseService getSchoolList:0 lastSchoolId:0 resultBack:^(HDServiceResult *result, NSArray *items) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (HD_RESULT_CODE_SUCCESS == result.resultCode || HD_RESULT_CODE_EMPTY == result.resultCode) {
                if (0 == lastSchoolId) {
                    [self.tableView setTableDataWithAry:items];
                }
                else {
                    [self.tableView tableAppendDataWithAry:items];
                }
            }
            else if ([result isExposedToUser]) {
                [result show];
            }
            else {
                if (0 == lastSchoolId && HD_RESULT_CODE_NETWORK_FAILURE == result.resultCode) {
                    [self.tableView setTableNetworkFailure];
                }
            }
            
            if (0 == lastSchoolId) {
                self.tableView.HDTableIsRefreshing = NO;
            }
            else {
                self.tableView.HDTableIsLoadingMore = NO;
            }
        });
    }];
}


#pragma - mark hdtableview

- (void)HDTableViewDidTriggerRefresh:(HDTableView*)pullTableView
{
    [self requestSchoolList:0];
}

- (void)HDTableViewDidTriggerLoadMore:(HDTableView*)pullTableView
{
    HDSchoolModel *model = [[self.tableView getTableDataAry] lastObject];
    [self requestSchoolList:model.Id];
}

-(void)HDTableViewDidSelected:(id)data didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HDMainViewController *mainViewController = [[HDMainViewController alloc] init];
    mainViewController.schoolModel = data;
    [self.navigationController pushViewController:mainViewController animated:YES];
}

@end
