//
//  HDChangePasswordViewController.m
//  udo_stu
//
//  Created by nobody on 15-6-7.
//  All rights reserved.
//

#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

#import "HDChangePasswordViewController.h"
#import "HDRegularClass.h"
#import "HDEyeBtn.h"
#import "HDCharacterDetectionClass.h"
@interface HDChangePasswordViewController ()

@property (nonatomic, strong) UITextField *textfOldPassWord;
@property (nonatomic, strong) UITextField *textfNewPassWord;
@property (nonatomic, strong) UIImageView *imaVLineName;
@property (nonatomic, strong) UIImageView *imaVLinePassWord;
@property (nonatomic, strong) UIButton *doneBtn;

@end

@implementation HDChangePasswordViewController

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

-(void)eyeBtnClick:(HDEyeBtn *)btn
{
    [btn setIsOn:!btn.isOn];
    if (btn.tag == 1000)
    {
        _textfOldPassWord.secureTextEntry = !btn.isOn;
    }
    else
    {
        _textfNewPassWord.secureTextEntry = !btn.isOn;
    }
}

- (void)initViews
{
    _textfOldPassWord = [[UITextField alloc] initWithFrame:CGRectMake(30, 64+50, APP_CONTENT_WIDTH-90, 30)];
    
    _textfOldPassWord.backgroundColor = [UIColor clearColor];
    _textfOldPassWord.contentMode = UIViewContentModeCenter;
    _textfOldPassWord.returnKeyType = UIReturnKeyDone;
    _textfOldPassWord.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfOldPassWord.delegate = self;
    _textfOldPassWord.secureTextEntry = YES;
    _textfOldPassWord.keyboardType = UIKeyboardTypeASCIICapable;
    [_textfOldPassWord addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    _textfOldPassWord.placeholder = @"请输入原密码";
    [self.view addSubview:_textfOldPassWord];
    
    HDEyeBtn * eyeBtn_old = [[HDEyeBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_textfOldPassWord.frame), CGRectGetMinY(_textfOldPassWord.frame), 30, 30)];
    [self.view addSubview:eyeBtn_old];
    eyeBtn_old.tag = 1000;
    [eyeBtn_old addTarget:self action:@selector(eyeBtnClick:) forControlEvents:UIControlEventTouchUpInside];

    
    _imaVLineName = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                      highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    
    _imaVLineName.frame = CGRectMake(_textfOldPassWord.frame.origin.x,
                                     _textfOldPassWord.frame.origin.y+_textfOldPassWord.frame.size.height,
                                     _textfOldPassWord.frame.size.width+ 30,
                                     3);
    [self.view addSubview:_imaVLineName];
    
    _textfNewPassWord = [[UITextField alloc] initWithFrame:CGRectMake(30,
                                                                   _textfOldPassWord.frame.size.height+_textfOldPassWord.frame.origin.y+20,
                                                                   APP_CONTENT_WIDTH-90,
                                                                   30)];
    
    _textfNewPassWord.backgroundColor = [UIColor clearColor];
    _textfNewPassWord.contentMode = UIViewContentModeCenter;
    _textfNewPassWord.returnKeyType = UIReturnKeyDone;
    _textfNewPassWord.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfNewPassWord.delegate = self;
    _textfNewPassWord.secureTextEntry = YES;
    _textfNewPassWord.keyboardType = UIKeyboardTypeASCIICapable;

    _textfNewPassWord.placeholder = @"请输入新密码";

    [_textfNewPassWord addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    [self.view addSubview:_textfNewPassWord];
    
    HDEyeBtn * eyeBtn_new = [[HDEyeBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_textfOldPassWord.frame), CGRectGetMinY(_textfNewPassWord.frame), 30, 30)];
    [self.view addSubview:eyeBtn_new];
    eyeBtn_new.tag = 2000;
    [eyeBtn_new addTarget:self action:@selector(eyeBtnClick:) forControlEvents:UIControlEventTouchUpInside];

    
    _imaVLinePassWord = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                          highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLinePassWord.frame = CGRectMake(_textfNewPassWord.frame.origin.x,
                                         _textfNewPassWord.frame.origin.y+_textfNewPassWord.frame.size.height,
                                         _textfNewPassWord.frame.size.width + 30,
                                         3);
    [self.view addSubview:_imaVLinePassWord];
    
    
    
    
    _doneBtn = [[UIButton alloc] initWithFrame:CGRectMake(30,
                                                           _textfNewPassWord.frame.origin.y+_textfNewPassWord.frame.size.height+50,
                                                           APP_CONTENT_WIDTH-60,
                                                           44)];
    [_doneBtn setTitle:@"完成" forState:UIControlStateNormal];
    [_doneBtn addTarget:self action:@selector(doneBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    _doneBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
    _doneBtn.backgroundColor = RGBColor(30, 172, 134);
    [self.view addSubview:_doneBtn];
    _doneBtn.enabled = NO;
    _doneBtn.alpha = 0.2;
}

-(void)doneBtnClick:(UIButton *)btn
{
    [self resignAllResponder];
    _doneBtn.enabled = NO;
    HDUserModel * model = [[HDManager sharedInstance]currentUser];
    [[[HDManager sharedInstance]userService]changePassword:model.Id oldPassword:_textfOldPassWord.text newPassword:_textfNewPassWord.text resultBack:^(HDServiceResult *result, id object) {
        
        if (result.resultCode == HD_RESULT_CODE_SUCCESS)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
        
        [result show];
        _doneBtn.enabled = YES;
    }];
}

- (void)textFieldEditChanged:(UITextField *)textField
{
    if ([HDRegularClass checkOutPassWord:_textfOldPassWord.text] && [HDRegularClass checkOutPassWord:_textfNewPassWord.text])
    {
        _doneBtn.enabled = YES;
        _doneBtn.alpha = 1;
    }
    else
    {
        _doneBtn.enabled = NO;
        _doneBtn.alpha = 0.2;
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString * str = [HDCharacterDetectionClass DetectionTextField:textField ChangeCharactersInRange:range replacementString:string type:HD_TextFieldType_PASSWORD ];
    if (str == nil)
    {
        return YES;
    }
    else
    {
        [self resignAllResponder];
        [HDTip showMessage:str];
        return NO;
    }
    
}
-(void)resignAllResponder
{
    [_textfOldPassWord resignFirstResponder];
    [_textfNewPassWord resignFirstResponder];
}


- (void)setNavbar
{
    self.centerView = [HDUICommon getTitleView:@"修改密码"];
    
    self.leftView = [HDUICommon leftBackView:self];
}

-(void)back:(UIButton *)btn
{
    [self.navigationController popToRootViewControllerAnimated:self.animation];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setNavbar];
    [self initViews];
}


@end
