




#import <UIKit/UIKit.h>

@interface HDIndicatorView : UIView
{
    int beginX;//第一个点x的位置
    UIImageView * moveimg;
}
@property (nonatomic,assign) int currentIndex;
- (id)initWithFrame:(CGRect)frame andWithPageCount:(int)count;
@end
