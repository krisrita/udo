//
//  HDCharacterDetectionClass.m
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#define PASSWORD_LENGTH 20

#define PHONENUM_LENGTH 11

#define VERIFICATION_CODE 6
#import "HDLoginDefine.h"
#import "HDCharacterDetectionClass.h"


@implementation HDCharacterDetectionClass

+(NSString *)DetectionTextField:(UITextField *)textField ChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string type:(HDTextFieldType)type
{
    if (type == HD_TextFieldType_PASSWORD)
    {
        return [HDCharacterDetectionClass DetectionPassWordTextField:textField ChangeCharactersInRange:range replacementString:string];
    }
    else if (type == HD_TextFieldType_PASSWORD_PHONE_NUM)
    {
        return [HDCharacterDetectionClass DetectionPhoneNumTextField:textField ChangeCharactersInRange:range replacementString:string];
    }
    else
    {
        return [HDCharacterDetectionClass DetectionVerificationCodeTextField:textField ChangeCharactersInRange:range replacementString:string];
    }
    return @"";
}

+(NSString *)DetectionVerificationCodeTextField:(UITextField *)textField ChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (![HDCharacterDetectionClass PhoneNumishaveTeShuzifu:string])
    {
        NSInteger strLength = textField.text.length - range.length + string.length;
        if (strLength <= VERIFICATION_CODE)
        {
            return nil;
        }
        else
        {
            return TIP_VERIFICATION_CODE_LENGTH_ERROR;
        }
    }
    return TIP_ILLEGAL_CHARACTE;
}



+(NSString *)DetectionPhoneNumTextField:(UITextField *)textField ChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (![HDCharacterDetectionClass PhoneNumishaveTeShuzifu:string])
    {
        NSInteger strLength = textField.text.length - range.length + string.length;
        if (strLength <= PHONENUM_LENGTH)
        {
            return nil;
        }
        else
        {
            return TIP_PHONENUM_LENGTH_ERROR;
        }
    }
    return TIP_ILLEGAL_CHARACTE;
}




+(NSString *)DetectionPassWordTextField:(UITextField *)textField ChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (![HDCharacterDetectionClass PassWordishaveTeShuzifu:string])
    {
        NSInteger strLength = textField.text.length - range.length + string.length;
        if (strLength <= PASSWORD_LENGTH)
        {
            return nil;
        }
        else
        {
            return TIP_PASSWORDLENGTH_ERROR;
        }
    }
    return TIP_ILLEGAL_CHARACTE;
}

+ (BOOL)PhoneNumishaveTeShuzifu:(NSString *)str
{
    NSCharacterSet * nameCharacters = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet];
    NSRange userNameRange = [str rangeOfCharacterFromSet:nameCharacters];
    if (userNameRange.location != NSNotFound)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}



+ (BOOL)PassWordishaveTeShuzifu:(NSString *)str
{
    NSCharacterSet * nameCharacters = [[NSCharacterSet characterSetWithCharactersInString:@"_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"] invertedSet];
    NSRange userNameRange = [str rangeOfCharacterFromSet:nameCharacters];
    if (userNameRange.location != NSNotFound)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}


@end
