//
//  MCR MCRegisterViewController.h
//
//  Created by nobody on 14-2-18.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HDBaseViewController.h"
#import "HDLoginViewController.h"

@interface HDRegisterViewController : HDBaseViewController


@end
