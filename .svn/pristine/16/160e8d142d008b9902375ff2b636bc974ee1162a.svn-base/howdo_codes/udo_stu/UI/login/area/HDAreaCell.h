//
//  HDAreaCell.h
//  udo_stu
//
//  Created by nobody on 15/6/6.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HDAreaViewController.h"

@interface HDAreaCell : UITableViewCell

/// 数据源
@property(nonatomic,strong)id Data;

@property(nonatomic,assign)areaType type;

@end
