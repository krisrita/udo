//
//  HDRegularClass.m
//  udo_stu
//
//  Created by nobody on 15-6-14.
//  All rights reserved.
//

#import "HDRegularClass.h"
#import "RegexKitLite.h"
@implementation HDRegularClass

+(BOOL)checkOutPhoneNumber:(NSString *)phoneNum
{
    NSString *phoneNumRegex = @"(1)[0-9]{10}$";
    return [HDRegularClass checkOutWithRegexStr:phoneNumRegex withCheckOutStr:phoneNum];
}

+(BOOL)checkOutPassWord:(NSString *)passWord
{
    NSString *passWordRegex = @"^[\\dA-Za-z(!@#$%&)]{6,20}$";
    return [HDRegularClass checkOutWithRegexStr:passWordRegex withCheckOutStr:passWord];
}

+(BOOL)checkOutVerificationCode:(NSString *)codeStr
{
    NSString *VerificationCodeRegex = @"\\d{6}";
    return  [HDRegularClass checkOutWithRegexStr:VerificationCodeRegex withCheckOutStr:codeStr];
}

+(BOOL)checkOutNickName:(NSString *)nick
{
    NSString *nickRegex = @"^[a-zA-Z0-9_\u4e00-\u9fa5]+$";
    return  [HDRegularClass checkOutWithRegexStr:nickRegex withCheckOutStr:nick];
}

+(BOOL)checkOutWithRegexStr:(NSString *)RegexStr withCheckOutStr:(NSString *)checkOutStr
{
    if (checkOutStr && [checkOutStr isKindOfClass:[NSString class]] && checkOutStr.length > 0 && RegexStr &&  [RegexStr isKindOfClass:[NSString class]] && RegexStr.length > 0)
    {
        return  [checkOutStr isMatchedByRegex:RegexStr];

    }
    return NO;
}


@end
