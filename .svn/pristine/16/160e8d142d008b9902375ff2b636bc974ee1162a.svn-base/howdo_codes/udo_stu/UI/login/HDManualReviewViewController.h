//
//  HDManualReviewViewController.h
//  udo_stu
//
//  Created by nobody on 6/22/15.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDManualReviewViewController : HDBaseViewController

@end
