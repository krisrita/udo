//
//  HDManualReviewViewController.m
//  udo_stu
//
//  Created by nobody on 6/22/15.
//  All rights reserved.
//

#import "HDManualReviewViewController.h"

@implementation HDManualReviewViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    WS(ws);
    self.leftView = [HDUICommon leftBackView:self];
    self.centerView = [HDUICommon getTitleView:@"人工审核"];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_manual_review"]];
    [self.view addSubview:imageView];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.view).offset(APP_STATUS_HEIGHT + 19.5);
        make.bottom.equalTo(ws.view).offset(-82.5);
        make.left.equalTo(ws.view).offset(96.5/2);
        make.right.equalTo(ws.view).offset(-95.5/2);
    }];
}

- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

@end
