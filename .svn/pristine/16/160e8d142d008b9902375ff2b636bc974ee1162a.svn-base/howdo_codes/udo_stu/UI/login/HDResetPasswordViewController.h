//
//  HDResetPasswordViewController.h
//  udo_stu
//
//  Created by nobody on 15-5-31.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDResetPasswordViewController : HDBaseViewController

@property (nonatomic,copy) NSString * phoneNumStr;
@property (nonatomic,copy) NSString * verificationCodeStr;


@end
