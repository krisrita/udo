//
//  HDAreaCell.m
//  udo_stu
//
//  Created by nobody on 15/6/6.
//  All rights reserved.
//

#import "HDAreaCell.h"

#define cell_font   [UIFont systemFontOfSize:14]


#define buildLabel(label,rect)                          label = [[UILabel alloc] initWithFrame:rect];\
                                                        label.backgroundColor = [UIColor clearColor];\
                                                        label.opaque = NO;\
                                                        label.textAlignment = NSTextAlignmentLeft;\
                                                        label.font = cell_font;\
                                                        label.numberOfLines = 0;\
                                                        [self.contentView addSubview:label];



@interface HDAreaCell ()

@property(nonatomic, strong)UILabel *labName;

@end

@implementation HDAreaCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor clearColor];
    
        CGRect nameRect = CGRectMake(15, 0, 200, 46);
        buildLabel(_labName,nameRect);
        
        UIImageView * jianTouImgV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ic_cell_arrow.png"]];
        jianTouImgV.frame = CGRectMake(APP_CONTENT_WIDTH-24, 17, 8, 14);
        jianTouImgV.tag = 1407041453;
        [self.contentView addSubview:jianTouImgV];
    }
    
    return self;
}

- (void)setData:(id)Data
{
    HDRegionModel * model = (HDRegionModel *)Data;

    if (model && [model respondsToSelector:@selector(name)])
    {
        _labName.text = [model name];
        _Data = Data;
    }
}

@end
