//
//  HDPeopleReviewViewController.m
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#import "HDPeopleReviewViewController.h"

@interface HDPeopleReviewViewController ()

@end

@implementation HDPeopleReviewViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.centerView = [HDUICommon getTitleView:@"人工审核"];
    self.leftView = [HDUICommon leftBackView:self];
    
    
    UIImageView * img = [[UIImageView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.headView.frame) + 20/2, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT-CGRectGetMaxY(self.headView.frame) -(19.5+82.5)/2)];
    img.image = [UIImage imageNamed:@"ic_peoplereview_img.png"];
    [self.view addSubview:img];
    img.contentMode= UIViewContentModeScaleAspectFit;
    
}
-(void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

@end
