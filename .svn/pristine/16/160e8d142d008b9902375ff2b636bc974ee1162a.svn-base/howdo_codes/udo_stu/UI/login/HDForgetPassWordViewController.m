//
//  HDForgetPassWordViewController.m
//  udo_stu
//
//  Created by nobody on 15-5-31.
//  All rights reserved.
//

#import "HDForgetPassWordViewController.h"
#import "HDChangePhoneNumberViewController.h"
#import "RegexKitLite.h"
#import "HDVerifyViewController.h"
#import "HDManualReviewViewController.h"
#import "HDCharacterDetectionClass.h"

@interface HDForgetPassWordViewController ()<UITextFieldDelegate>

@property (nonatomic,strong)UITextField * phoneNum;

@property (nonatomic,strong)UIImageView *imaVLineName;

@property (nonatomic,strong) UIButton * btnNext;
@end

@implementation HDForgetPassWordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setNavbar];
    
    UILabel * lbl = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.headView.frame),APP_CONTENT_WIDTH, 30)];
    lbl.backgroundColor = [UIColor colorWithRed:222.0/255.0 green:222.0/255.0 blue:222.0/255.0 alpha:1];
    [self.view addSubview:lbl];
    lbl.textAlignment = NSTextAlignmentCenter;
    lbl.font = [UIFont systemFontOfSize:12];
    lbl.textColor = [UIColor colorWithRed:137.0/255.0 green:137.0/255.0 blue:137.0/255.0 alpha:1];
    lbl.text = @"请输入您当时注册的手机号";
    
    
    _phoneNum = [[UITextField alloc] initWithFrame:CGRectMake(30, 64+50, APP_CONTENT_WIDTH-60, 30)];
    
    _phoneNum.backgroundColor = [UIColor clearColor];
    _phoneNum.contentMode = UIViewContentModeCenter;
    _phoneNum.returnKeyType = UIReturnKeyDone;
    _phoneNum.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _phoneNum.delegate = self;
    [_phoneNum addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    _phoneNum.secureTextEntry = NO;
    _phoneNum.keyboardType =UIKeyboardTypeNumberPad;

    _phoneNum.placeholder = @"手机号";
    [self.view addSubview:_phoneNum];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textFieldChanged:)
                                                 name:UITextFieldTextDidChangeNotification
                                               object:nil];

    
    _imaVLineName = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                      highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLineName.frame = CGRectMake(_phoneNum.frame.origin.x,
                                     _phoneNum.frame.origin.y+_phoneNum.frame.size.height,
                                     _phoneNum.frame.size.width,
                                     3);
    [self.view addSubview:_imaVLineName];
    
    UIButton *btnForget = [[UIButton alloc] initWithFrame:CGRectMake(_phoneNum.frame.size.width+_phoneNum.frame.origin.x-60,
                                                                     _phoneNum.frame.origin.y+_phoneNum.frame.size.height,
                                                                     70,
                                                                     30)];
    [btnForget addTarget:self action:@selector(btnPhoneNumGiveUpUse:) forControlEvents:UIControlEventTouchUpInside];
    [btnForget setTitle:@"手机号弃用了" forState:UIControlStateNormal];
    [btnForget setTitleColor:[UIColor colorWithRed:(30)/255.0 green:(172)/255.0 blue:(134)/255.0 alpha:1]forState:UIControlStateNormal];
    btnForget.titleLabel.font = [UIFont systemFontOfSize:11];
    btnForget.backgroundColor = [UIColor clearColor];
    [self.view addSubview:btnForget];
    
    
    
    _btnNext = [[UIButton alloc] initWithFrame:CGRectMake(30,
                                                           _imaVLineName.frame.origin.y+_imaVLineName.frame.size.height+50,
                                                           APP_CONTENT_WIDTH-60,
                                                           44)];
    [_btnNext setTitle:@"下一步" forState:UIControlStateNormal];
    [_btnNext addTarget:self action:@selector(btnNext:) forControlEvents:UIControlEventTouchUpInside];
    _btnNext.titleLabel.textAlignment = NSTextAlignmentCenter;
    _btnNext.backgroundColor = [UIColor colorWithRed:(30)/255.0 green:(172)/255.0 blue:(134)/255.0 alpha:1] ;
    [self.view addSubview:_btnNext];
    
    _btnNext.enabled = NO;
    _btnNext.alpha = 0.2;
}

-(void)textFieldChanged:(NSNotification *)not
{
    if ([self checkPhoneNumber: _phoneNum.text])
    {
        _btnNext.enabled = YES;
        _btnNext.alpha = 1;

    }
    else{
        _btnNext.enabled = NO;
        _btnNext.alpha = 0.2;

    }
}

-(void)btnNext:(UIButton *)btn
{
    [self.phoneNum resignFirstResponder];
    if ([self checkPhoneNumber:_phoneNum.text])
    {
        
        [HDLoading startAnimating:@"正在发送验证码..."];
        [[[HDManager sharedInstance]userService]sendForgetPasswordCode:_phoneNum.text resultBack:^(HDServiceResult *result, id object) {
            [HDLoading stopAnimating];
            if (result.resultCode == HD_RESULT_CODE_SUCCESS)
            {
                HDVerifyViewController * verfiy = [[HDVerifyViewController alloc]init];
                verfiy.phoneNumStr = _phoneNum.text;
                verfiy.userType = HDVerifyVCUseType_ForgetPassWord;
                [self.navigationController pushViewController:verfiy animated:YES];
            }
            
            [result show];
 
        }];
        
    }
}

-(void)btnPhoneNumGiveUpUse:(UIButton *)btn
{
    HDManualReviewViewController *viewController = [[HDManualReviewViewController alloc]init];
    [self.navigationController pushViewController:viewController animated:YES];
}
#pragma mark - 输入框事件，监听登录按钮是否可以点击

- (void)textFieldEditChanged:(UITextField *)textField
{
    if ([self checkPhoneNumber:textField.text]) {
        _btnNext.enabled = YES;
    }
}


- (BOOL)checkPhoneNumber:(NSString *)string
{
    if (string && [string isMatchedByRegex:@"(1)[0-9]{10}$"])
    {
        return YES;
    }
    return NO;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _imaVLineName.highlighted = ([textField isEqual:_phoneNum]?YES:NO);
    
    if ([textField isEqual:_phoneNum])
    {
        
    }
    else
    {
        if ([self checkPhoneNumber:_phoneNum.text])
        {
            
        }
        else
        {
        }
    }
    
    return YES;
}

- (void)setNavbar
{
    UILabel *centerTitlelabel = [[UILabel alloc]init];
    centerTitlelabel.text = @"忘记密码";
    centerTitlelabel.backgroundColor = [UIColor clearColor];
    centerTitlelabel.textColor = [UIColor whiteColor];
    centerTitlelabel.font = [UIFont systemFontOfSize:18];
    [centerTitlelabel sizeToFit];
    self.centerView = centerTitlelabel;
    
    self.leftView = [HDUICommon leftBackView:self];
}

-(void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString * str = [HDCharacterDetectionClass DetectionTextField:textField ChangeCharactersInRange:range replacementString:string type:HD_TextFieldType_PASSWORD_PHONE_NUM ];
    if (str == nil)
    {
        return YES;
    }
    else
    {
        [_phoneNum resignFirstResponder];
        [HDTip showMessage:str];
        return NO;
    }
}

@end
