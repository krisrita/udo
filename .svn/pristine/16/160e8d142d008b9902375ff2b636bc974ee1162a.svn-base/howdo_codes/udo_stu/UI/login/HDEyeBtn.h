//
//  HDEyeView.h
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDEyeBtn : UIButton

@property (nonatomic,assign) BOOL isOn;

@end
