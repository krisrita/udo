//
//  HDAreaViewController.h
//  udo_stu
//
//  Created by nobody on 15/6/2.
//  All rights reserved.
//

BOOL backBtnHave ;

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, areaType) {
    area_sheng = 0,
    area_shi,
    area_xian
};
@interface HDAreaViewController : HDBaseViewController

@property (nonatomic, strong) NSMutableArray *aryData;
@property (nonatomic,strong) HDRegionSourceModel *regionSource;
@property (nonatomic,assign) areaType VCAreaType;

@end
