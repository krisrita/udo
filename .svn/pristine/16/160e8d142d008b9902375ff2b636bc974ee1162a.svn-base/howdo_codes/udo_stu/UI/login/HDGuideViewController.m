//
//  HDGuideViewController.m
//  udo_stu
//
//  Created by nobody on 15-5-31.
//  All rights reserved.
//
#define PAGE_COUNT 4

#import "HDGuideViewController.h"
#import "HDRegisterViewController.h"
#import "HDIndicatorView.h"

@interface HDGuideViewController () <UIScrollViewDelegate>

{
    UIScrollView * myScrollView;
    HDIndicatorView * indicator;
}
@end

@implementation HDGuideViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.headView.hidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    myScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT)];
    
    [myScrollView setShowsHorizontalScrollIndicator:NO];
    myScrollView.backgroundColor = [UIColor whiteColor];
    [myScrollView setShowsVerticalScrollIndicator:NO];
    [myScrollView setBounces:YES];
    [myScrollView setScrollEnabled:YES];
    [myScrollView setPagingEnabled:YES];
    myScrollView.delegate = self;
    myScrollView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_guide"]];
    
    NSString *tempStr = @"ic_guide4_";
    
    if (APP_SCREEN_HEIGHT>480)
    {
        tempStr = @"ic_guide_";
    }
    
    for (int i = 0; i < PAGE_COUNT; i++)
    {
        NSString * imgName = [NSString stringWithFormat:@"%@%d",tempStr,i+1];
        UIImage * imgg= [UIImage imageNamed:imgName];
        UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(APP_SCREEN_WIDTH * i , 0, APP_SCREEN_WIDTH, APP_SCREEN_HEIGHT)];
        imgView.image = imgg;
        [myScrollView addSubview:imgView];
    }
    [myScrollView setContentSize:CGSizeMake(APP_SCREEN_WIDTH * PAGE_COUNT, APP_SCREEN_HEIGHT)];
    [self.view addSubview:myScrollView];
    
    indicator = [[HDIndicatorView alloc]initWithFrame:CGRectMake(0, APP_SCREEN_HEIGHT-130, APP_SCREEN_WIDTH, 10) andWithPageCount:PAGE_COUNT];
    [self.view addSubview:indicator];
    
    
    UIButton * loginBtn = [[UIButton alloc]initWithFrame:CGRectMake(20, APP_SCREEN_HEIGHT-94, (APP_CONTENT_WIDTH - 30 - 30 )/2, 40)];
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    loginBtn.backgroundColor = [UIColor colorWithRed:0 green:175/255.0 blue:143.0/255.0 alpha:1];
    [loginBtn addTarget:self action:@selector(loginBtnClick) forControlEvents:UIControlEventTouchUpInside];
    loginBtn.layer.cornerRadius = 3;
    [self.view addSubview:loginBtn];
    
    
    UIButton * registerBtn = [[UIButton alloc]initWithFrame:CGRectMake(APP_SCREEN_WIDTH - 15 - CGRectGetWidth(loginBtn.frame), APP_SCREEN_HEIGHT-94, (APP_CONTENT_WIDTH - 30 - 30 )/2, 40)];
    [registerBtn setTitle:@"注册" forState:UIControlStateNormal];
    registerBtn.backgroundColor = [UIColor grayColor];
    
    registerBtn.backgroundColor = [UIColor colorWithRed:50/255.0 green:77/255.0 blue:94/255.0 alpha:1];
    registerBtn.layer.cornerRadius = 3;
    [registerBtn addTarget:self action:@selector(registerBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:registerBtn];
}

-(void)loginBtnClick
{
    HDLoginViewController * loginVC  =[[HDLoginViewController alloc]init];
    [self.navigationController pushViewController:loginVC animated:YES];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView;
{
    CGFloat pageWidth = scrollView.frame.size.width;
    int currentPage = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    [indicator setCurrentIndex:currentPage];
}


-(void)registerBtnClick
{
    HDRegisterViewController * loginVC  =[[HDRegisterViewController alloc]init];
    [self.navigationController pushViewController:loginVC animated:YES];
}

@end
