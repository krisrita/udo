//
//  HDChangePasswordViewController.h
//  udo_stu
//
//  Created by nobody on 15-6-7.
//  All rights reserved.
//

#import "HDBaseViewController.h"

///修改密码
@interface HDChangePasswordViewController : HDBaseViewController

@end
