//
//  HDTimerBtn.h
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDTimerBtn : UIButton

-(void)addTimer;


@end
