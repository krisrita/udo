//
//  HDAreaModel.h
//  udo_stu
//
//  Created by nobody on 15/6/2.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDAreaModel : NSObject

@property (nonatomic, copy) NSString *strName;

@property (nonatomic, copy) NSString *strID;

@end
