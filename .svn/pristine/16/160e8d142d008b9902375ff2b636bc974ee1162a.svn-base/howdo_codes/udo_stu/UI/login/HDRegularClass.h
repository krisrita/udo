//
//  HDRegularClass.h
//  udo_stu
//
//  Created by nobody on 15-6-14.
//  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HDRegularClass : NSObject

+(BOOL)checkOutPhoneNumber:(NSString *)phoneNum;

+(BOOL)checkOutPassWord:(NSString *)passWord;

+(BOOL)checkOutVerificationCode:(NSString *)codeStr;

+(BOOL)checkOutNickName:(NSString *)nick;

@end
