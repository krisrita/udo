//
//  HDResetPasswordViewController.m
//  udo_stu
//
//  Created by nobody on 15-5-31.
//  All rights reserved.
//

#import "HDResetPasswordViewController.h"
#import "HDLoginViewController.h"
#import "HDRegularClass.h"
#import "HDEyeBtn.h"
#import "HDCharacterDetectionClass.h"
#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

@interface HDResetPasswordViewController ()
{
    UIButton *doneBtn;
}

@property (nonatomic, strong) UITextField *textPassword;
@property (nonatomic, strong) UIImageView *imaVLineName;

@end

@implementation HDResetPasswordViewController

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

-(void)eyeBtnClick:(HDEyeBtn *)btn
{
    [btn setIsOn:!btn.isOn];
    _textPassword.secureTextEntry = !btn.isOn;

}

- (void)textFieldEditChanged:(UITextField *)textField
{
    if ( [HDRegularClass checkOutPassWord:_textPassword.text])
    {
        doneBtn.enabled = YES;
        doneBtn.alpha = 1;
        
    }
    else
    {
        doneBtn.enabled = NO;
        doneBtn.alpha = 0.2;
        
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UILabel *centerTitlelabel = [[UILabel alloc]init];
    centerTitlelabel.text = @"重置密码";
    centerTitlelabel.backgroundColor = [UIColor clearColor];
    centerTitlelabel.textColor = [UIColor whiteColor];
    centerTitlelabel.font = [UIFont systemFontOfSize:18];
    [centerTitlelabel sizeToFit];
    self.centerView = centerTitlelabel;
    
    self.leftView = [HDUICommon leftBackView:self];

    _textPassword = [[UITextField alloc] initWithFrame:CGRectMake(30, 64+50, APP_CONTENT_WIDTH-90, 30)];
    _textPassword.backgroundColor = [UIColor clearColor];
    _textPassword.contentMode = UIViewContentModeCenter;
    _textPassword.returnKeyType = UIReturnKeyDone;
    _textPassword.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textPassword.delegate = self;
    [_textPassword addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    _textPassword.secureTextEntry = YES;
    _textPassword.placeholder = @"新密码";
    [self.view addSubview:_textPassword];
    
    [_textPassword addTarget:self
                          action:@selector(textFieldEditChanged:)
                forControlEvents:UIControlEventEditingChanged];

    HDEyeBtn * eyeBtn_old = [[HDEyeBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_textPassword.frame), CGRectGetMinY(_textPassword.frame), 30, 30)];
    [self.view addSubview:eyeBtn_old];
    eyeBtn_old.tag = 1000;
    [eyeBtn_old addTarget:self action:@selector(eyeBtnClick:) forControlEvents:UIControlEventTouchUpInside];

    _imaVLineName = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                      highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLineName.frame = CGRectMake(_textPassword.frame.origin.x,
                                     _textPassword.frame.origin.y+_textPassword.frame.size.height,
                                     _textPassword.frame.size.width + 30,
                                     3);
    [self.view addSubview:_imaVLineName];
    
    doneBtn = [[UIButton alloc] initWithFrame:CGRectMake(30,
                                                           _imaVLineName.frame.origin.y+_imaVLineName.frame.size.height+50,
                                                           APP_CONTENT_WIDTH-60,
                                                           44)];
    [doneBtn setTitle:@"完成" forState:UIControlStateNormal];
    [doneBtn addTarget:self action:@selector(doneBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    doneBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
    doneBtn.backgroundColor = RGBColor(30, 172, 134);
    [self.view addSubview:doneBtn];
    doneBtn.enabled = NO;
    doneBtn.alpha = 0.2;

}

-(void)back:(UIButton *)btn
{
    [self.navigationController popToRootViewControllerAnimated:self.animation];
}


- (void)doneBtnClick:(UIButton *)btn
{
    [[[HDManager sharedInstance] userService]forgetPassword:self.phoneNumStr password:self.textPassword.text   verificationCode:self.verificationCodeStr resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS)
        {
            NSArray * ary = [self.navigationController viewControllers];
            for (UIViewController * viewCon in ary) {
                if ([viewCon isKindOfClass:[HDLoginViewController class]]) {
                    [self.navigationController popToViewController:viewCon animated:YES];
                }
            }
        }
        [result show];
    }];
}

- (BOOL)isPassWord:(NSString *)str
{
    NSString *passWordRegex = @"^[\\dA-Za-z(!@#$%&)]{6,16}$";
    NSPredicate *passWordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passWordRegex];
    return [passWordTest evaluateWithObject:str];
    
    return NO;
}

#pragma mark - UItextFieldView的代理方法

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _imaVLineName.highlighted = ([textField isEqual:_textPassword]?YES:NO);
    
    if ([textField isEqual:_textPassword])
    {
        
    }
    else
    {
        
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([textField isEqual:_textPassword])
    {
        [HDCharacterDetectionClass DetectionTextField:textField ChangeCharactersInRange:range replacementString:string type:HD_TextFieldType_PASSWORD];
    }
    doneBtn.enabled = [self isPassWord: _textPassword.text];
    doneBtn.alpha = (doneBtn.enabled?1:0.2);
    return YES;
}


#pragma mark -  点击任意一个输入框的清除按钮 将登录按钮变成不可以点击

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    doneBtn.enabled = NO;
    doneBtn.alpha = 0.2;
    
    return YES;
}

#pragma mark - 点击return键代理

- (BOOL)textFieldShouldReturn:(UITextField *)textField{

    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [_textPassword resignFirstResponder];
}



@end
