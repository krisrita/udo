//
//  HDCharacterDetectionClass.h
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//


typedef NS_ENUM(NSInteger, HDTextFieldType) {
    HD_TextFieldType_PASSWORD = 0,
    HD_TextFieldType_PASSWORD_PHONE_NUM = 1,
    HD_TextFieldType_VERIFICATION_CODE
};


@interface HDCharacterDetectionClass : NSObject


+(NSString *)DetectionTextField:(UITextField *)textField
        ChangeCharactersInRange:(NSRange)range
              replacementString:(NSString *)string
                           type:(HDTextFieldType)type;


@end
