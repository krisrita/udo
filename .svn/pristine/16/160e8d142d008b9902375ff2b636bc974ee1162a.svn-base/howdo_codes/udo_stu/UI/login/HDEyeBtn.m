//
//  HDEyeView.m
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#import "HDEyeBtn.h"
@interface HDEyeBtn ()

@end

@implementation HDEyeBtn

-(id)initWithFrame:(CGRect)frame
{
    self  = [super initWithFrame:frame];
    if (self) {
        self.isOn = NO;
        [self setIsOn:NO];
    }
    return self;
}


-(void)setIsOn:(BOOL)isOn
{
    if (isOn)
    {
        [self setImage:[UIImage imageNamed:@"btn_ic_eye_on"] forState:UIControlStateNormal];
    }
    else
    {
        [self setImage:[UIImage imageNamed:@"btn_ic_eye_off"] forState:UIControlStateNormal];
    }
    _isOn = isOn;
}
@end
