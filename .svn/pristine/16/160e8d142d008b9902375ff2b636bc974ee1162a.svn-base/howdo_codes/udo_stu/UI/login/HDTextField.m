

#import "HDTextField.h"

@implementation HDTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawPlaceholderInRect:(CGRect)rect
{
    [[UIColor colorWithRed:208.0/255.0 green:214.0/255.0 blue:217.0/255.0 alpha:1.0]setFill];
    [[self placeholder] drawInRect:rect withFont:[UIFont systemFontOfSize:14]];
    
}
@end
