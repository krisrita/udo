//
//  HDLoginDefine.h
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#ifndef udo_stu_HDLoginDefine_h
#define udo_stu_HDLoginDefine_h

#define TIP_PHONE_NUM_FORMAT_ERRRO @"手机号码格式错误"

/**
 *  字符非法
 */
#define TIP_ILLEGAL_CHARACTE @"不能输入非法字符"

#define TIP_PASSWORDLENGTH_ERROR @"密码长度6-20位"

#define TIP_PHONENUM_LENGTH_ERROR @"手机号码长度应为11位"

#define TIP_VERIFICATION_CODE_LENGTH_ERROR @"验证码长度应为6位"


/**
 *  用户信息发生改变
 */
#define NOTIFICATION_CURRENT_USER_INFO_CHANGE @"NOTIFICATION_CURRENT_USER_INFO_CHANGE"

#define NOTIFICATION_LOGIN_SUCCESS @"NOTIFICATION_LOGIN_SUCCESS"

#endif
