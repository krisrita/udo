
typedef void (^HDViewPushed)(void);
typedef void (^HDViewPoped)(void);
typedef void (^HDLoginBlockBack)(HDCommonResult *result);
typedef void (^HDPhoneRegisterBlockBack)(HDCommonResult *result,id object);

#import <UIKit/UIKit.h>
#import "HDBaseViewController.h"
#import "HDTextField.h"

@interface HDLoginViewController : HDBaseViewController

@end
