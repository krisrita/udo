//
//  HDVerifyViewController.m
//  udo_stu
//
//  Created by nobody on 15-5-31.
//  All rights reserved.
//
#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

#import "HDVerifyViewController.h"
#import "RegexKitLite.h"
#import "HDResetPasswordViewController.h"
#import "HDPersonCenterViewController.h"
#import "HDEyeBtn.h"
#import "HDTimerBtn.h"
#import "HDCharacterDetectionClass.h"
#import "HDRegularClass.h"
@interface HDVerifyViewController ()

{
    UITextField * _verificationCodeTextF;
    UIImageView * _imaVLineverificationCode;
    UIButton * _btnLogin;
}

@end

@implementation HDVerifyViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setNavbar];
    
    UILabel * lbl = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.headView.frame),APP_CONTENT_WIDTH, 30)];
    lbl.backgroundColor = [UIColor colorWithRed:222.0/255.0 green:222.0/255.0 blue:222.0/255.0 alpha:1];
    [self.view addSubview:lbl];
    lbl.textAlignment = NSTextAlignmentCenter;
    lbl.font = [UIFont systemFontOfSize:12];
    lbl.textColor = [UIColor colorWithRed:137.0/255.0 green:137.0/255.0 blue:137.0/255.0 alpha:1];
    NSString * text = [NSString stringWithFormat:@"已向手机手机%@发送验证短信，请注意查收",self.phoneNumStr];
    lbl.text = text;
    [self.view addSubview:lbl];
    
    _verificationCodeTextF = [[UITextField alloc] initWithFrame:CGRectMake(30, CGRectGetMaxY(lbl.frame) +20, APP_CONTENT_WIDTH - 284/2 - 60  -15, 30)];
    _verificationCodeTextF.backgroundColor = [UIColor clearColor];
    _verificationCodeTextF.contentMode = UIViewContentModeCenter;
    _verificationCodeTextF.returnKeyType = UIReturnKeyDone;
    _verificationCodeTextF.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _verificationCodeTextF.delegate = self;
    [_verificationCodeTextF addTarget:self
                               action:@selector(textFieldEditChanged:)
                     forControlEvents:UIControlEventEditingChanged];
    _verificationCodeTextF.secureTextEntry = NO;
    _verificationCodeTextF.placeholder = @"验证码";
    _verificationCodeTextF.keyboardType = UIKeyboardTypeNumberPad;
    [self.view addSubview:_verificationCodeTextF];

    
    _imaVLineverificationCode = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                                  highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLineverificationCode.frame = CGRectMake(_verificationCodeTextF.frame.origin.x,
                                                 _verificationCodeTextF.frame.origin.y+_verificationCodeTextF.frame.size.height,
                                                 _verificationCodeTextF.frame.size.width,
                                                 3);
    [self.view addSubview:_imaVLineverificationCode];
    
    
    HDTimerBtn * timerLbl = [[HDTimerBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_verificationCodeTextF.frame) +30,CGRectGetMinY( _verificationCodeTextF.frame),APP_CONTENT_WIDTH - 30 -(CGRectGetMaxX(_verificationCodeTextF.frame) +30), 30)];
    [self.view addSubview:timerLbl];
    [timerLbl addTimer];
    [timerLbl addTarget:self action:@selector(getVerificationCode) forControlEvents:UIControlEventTouchUpInside];
    
    _btnLogin = [[UIButton alloc] initWithFrame:CGRectMake(30,
                                                           CGRectGetMaxY(_imaVLineverificationCode.frame)+50,
                                                           APP_CONTENT_WIDTH-60,
                                                           44)];
    [_btnLogin setTitle:@"下一步" forState:UIControlStateNormal];
    [_btnLogin addTarget:self action:@selector(nextBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    _btnLogin.titleLabel.textAlignment = NSTextAlignmentCenter;
    _btnLogin.backgroundColor = RGBColor(30, 172, 134);
    [self.view addSubview:_btnLogin];
    _btnLogin.enabled = NO;
    _btnLogin.alpha = 0.2;

}

-(void)getVerificationCode
{
    if (self.userType == HDVerifyVCUseType_ChangePhoneNum)
    {
        [[[HDManager sharedInstance] userService] sendVerificationCode:self.phoneNumStr resultBack:^(HDServiceResult *result, id object)
         {
             [result show];
         }];
    }
    else if (HDVerifyVCUseType_ForgetPassWord)
    {
        [[[HDManager sharedInstance]userService]sendForgetPasswordCode:self.phoneNumStr resultBack:^(HDServiceResult *result, id object) {
            [result show];
        }];
    }
}


-(void)nextBtnClick:(UIButton *)btn
{
    if (self.userType == HDVerifyVCUseType_ChangePhoneNum)
    {
        [self changePhoneNum];
    }
    else
    {
        if (self.phoneNumStr && [self.phoneNumStr isKindOfClass:[NSString class]] && self.phoneNumStr.length > 0 &&  _verificationCodeTextF.text && [_verificationCodeTextF.text isKindOfClass:[NSString class]] && _verificationCodeTextF.text.length > 0)
        {
            HDResetPasswordViewController * hd = [[HDResetPasswordViewController alloc]init];
            hd.phoneNumStr = self.phoneNumStr;
            hd.verificationCodeStr = _verificationCodeTextF.text;
            [self.navigationController pushViewController:hd animated:YES];

        }
    }
}

- (void)textFieldEditChanged:(UITextField *)textField
{
    if ([HDRegularClass checkOutPassWord:_verificationCodeTextF.text] )
    {
        _btnLogin.enabled = YES;
        _btnLogin.alpha = 1;
    }
    else
    {
        _btnLogin.enabled = NO;
        _btnLogin.alpha = 0.2;
    }
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString * str = [HDCharacterDetectionClass DetectionTextField:textField ChangeCharactersInRange:range replacementString:string type:HD_TextFieldType_VERIFICATION_CODE];
    if (str == nil)
    {
        return YES;
    }
    else
    {
        [_verificationCodeTextF resignFirstResponder];
        [HDTip showMessage:str];
        return NO;
    }
    return YES;
}


-(void)changePhoneNum
{
    HDUserModel * model = [[HDManager sharedInstance]currentUser];
    if (self.passWordStr && [self.passWordStr isKindOfClass:[NSString class]] && self.passWordStr.length > 0 && self.phoneNumStr && [self.phoneNumStr isKindOfClass:[NSString class]] && [self.phoneNumStr length] > 0)
    {
        [[[HDManager sharedInstance]userService]changeMobilephone:model.Id password:self.passWordStr newMobilephone:self.phoneNumStr verificationCode:_verificationCodeTextF.text resultBack:^(HDServiceResult *result, id object) {
            if (result.resultCode == HD_RESULT_CODE_SUCCESS)
            {
                model.mobilephone = [self.phoneNumStr integerValue];
                [[HDManager sharedInstance]setCurrentUser:model];
                NSArray * ary = [self.navigationController viewControllers];
                for (UIViewController * vc in ary) {
                    if ([vc isKindOfClass:[HDPersonCenterViewController class]]) {
                        [self.navigationController popToViewController:vc animated:YES];
                    }
                }
            }
            [result show];
            
        }];
    }
    else
    {
        NSLog(@"HDVerifyViewController 参数有空");
    }

}


- (void)setNavbar
{
    self.centerView = [HDUICommon getTitleView:@"验证"];
    self.leftView = [HDUICommon leftBackView:self];
}
-(void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}


@end
