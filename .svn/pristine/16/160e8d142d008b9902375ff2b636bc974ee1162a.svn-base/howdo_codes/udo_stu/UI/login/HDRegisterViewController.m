//
//  MCR MCRegisterViewController.m
//
//  Created by nobody on 14-2-18.
//  All rights reserved.
//
#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]
#import "RegexKitLite.h"
#define EMAIL_Y     30
#define EMAIL_X     20
#define CONTROL_SPACE   20
#define SIGNINBUTTON_TAG    100
#define MOVEVALUE 70
#define PASSWOEDREGEX @"/^[^\s]{6,16}$/"

#import "HDRegisterViewController.h"
#import "HDTextField.h"
#import "HDTip.h"
#import "HDAreaViewController.h"
#import "HDEyeBtn.h"
#import "HDTimerBtn.h"
#import "HDRegularClass.h"
#import "HDLoginDefine.h"
#import "HDCharacterDetectionClass.h"

@interface HDRegisterViewController ()<UITextFieldDelegate>

@property (nonatomic, strong) UITextField *textfPhoneNum;
@property (nonatomic, strong) UITextField *textfPassWord;
@property (nonatomic,strong) UITextField *verificationCodeTextF;
@property (nonatomic, strong) UIImageView *phoneNumimaVLine;
@property (nonatomic, strong) UIImageView *imaVLinePassWord;
@property (nonatomic,strong) UIImageView *imaVLineverificationCode;
@property (nonatomic, strong) UIButton *btnLogin;

@end

@implementation HDRegisterViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidChangeNotification object:nil];
}

- (void)setNavbar
{
    UILabel *centerTitlelabel = [[UILabel alloc]init];
    centerTitlelabel.text = @"注册";
    centerTitlelabel.backgroundColor = [UIColor clearColor];
    centerTitlelabel.textColor = [UIColor whiteColor];
    centerTitlelabel.font = [UIFont systemFontOfSize:18];
    [centerTitlelabel sizeToFit];
    self.centerView = centerTitlelabel;
    
    self.leftView = [HDUICommon leftBackView:self];

}

-(void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

-(void)eyeBtnClick:(HDEyeBtn *)btn
{
    [btn setIsOn:!btn.isOn];
    _textfPassWord.secureTextEntry = !btn.isOn;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setNavbar];

    _textfPhoneNum = [[UITextField alloc] initWithFrame:CGRectMake(30, 64+50, APP_CONTENT_WIDTH-60, 30)];
    _textfPhoneNum.backgroundColor = [UIColor clearColor];
    _textfPhoneNum.contentMode = UIViewContentModeCenter;
    _textfPhoneNum.returnKeyType = UIReturnKeyDone;
    _textfPhoneNum.keyboardType = UIKeyboardTypeNumberPad;
    _textfPhoneNum.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfPhoneNum.delegate = self;
    [_textfPhoneNum addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    _textfPhoneNum.secureTextEntry = NO;
    _textfPhoneNum.placeholder = @"手机号";
    [self.view addSubview:_textfPhoneNum];
    
    _phoneNumimaVLine = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                      highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _phoneNumimaVLine.frame = CGRectMake(_textfPhoneNum.frame.origin.x,
                                     _textfPhoneNum.frame.origin.y+_textfPhoneNum.frame.size.height,
                                     _textfPhoneNum.frame.size.width,
                                     3);
    [self.view addSubview:_phoneNumimaVLine];
    
    _textfPassWord = [[UITextField alloc] initWithFrame:CGRectMake(30,
                                                                   _textfPhoneNum.frame.size.height+_textfPhoneNum.frame.origin.y+20,
                                                                   APP_CONTENT_WIDTH-90,
                                                                   30)];
    
    _textfPassWord.backgroundColor = [UIColor clearColor];
    _textfPassWord.contentMode = UIViewContentModeCenter;
    _textfPassWord.returnKeyType = UIReturnKeyDone;
    _textfPassWord.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfPassWord.delegate = self;
    _textfPassWord.keyboardType = UIKeyboardTypeASCIICapable;
    _textfPassWord.secureTextEntry = YES;
    _textfPassWord.placeholder = @"密码";
    [_textfPassWord addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    [self.view addSubview:_textfPassWord];
    
    HDEyeBtn * eyeBtn_old = [[HDEyeBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_textfPassWord.frame), CGRectGetMinY(_textfPassWord.frame), 30, 30)];
    [self.view addSubview:eyeBtn_old];
    eyeBtn_old.tag = 1000;
    [eyeBtn_old addTarget:self action:@selector(eyeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    _imaVLinePassWord = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                          highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLinePassWord.frame = CGRectMake(_textfPassWord.frame.origin.x,
                                         _textfPassWord.frame.origin.y+_textfPassWord.frame.size.height,
                                         _textfPassWord.frame.size.width + 30,
                                         3);
    [self.view addSubview:_imaVLinePassWord];
    
    
    
    _verificationCodeTextF = [[UITextField alloc] initWithFrame:CGRectMake(30, CGRectGetMaxY(_imaVLinePassWord.frame) +20, APP_CONTENT_WIDTH - 284/2 - 60  -15, 30)];
    
    _verificationCodeTextF.backgroundColor = [UIColor clearColor];
    _verificationCodeTextF.contentMode = UIViewContentModeCenter;
    _verificationCodeTextF.returnKeyType = UIReturnKeyDone;
    _verificationCodeTextF.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _verificationCodeTextF.delegate = self;
    _verificationCodeTextF.secureTextEntry = NO;
    _verificationCodeTextF.placeholder = @"验证码";
    _verificationCodeTextF.keyboardType = UIKeyboardTypeNumberPad;
    [self.view addSubview:_verificationCodeTextF];
    [_verificationCodeTextF addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    
    _imaVLineverificationCode = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                      highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLineverificationCode.frame = CGRectMake(_verificationCodeTextF.frame.origin.x,
                                     _verificationCodeTextF.frame.origin.y+_verificationCodeTextF.frame.size.height,
                                     _verificationCodeTextF.frame.size.width,
                                     3);
    [self.view addSubview:_imaVLineverificationCode];

    
    HDTimerBtn * timerBtn = [[HDTimerBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_verificationCodeTextF.frame) +30,CGRectGetMinY( _verificationCodeTextF.frame),APP_CONTENT_WIDTH - 30 -(CGRectGetMaxX(_verificationCodeTextF.frame) +30), 30)];
    [timerBtn addTarget:self action:@selector(getVerificationCode:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:timerBtn];

    _btnLogin = [[UIButton alloc] initWithFrame:CGRectMake(30,
                                                           CGRectGetMaxY(_imaVLineverificationCode.frame)+50,
                                                           APP_CONTENT_WIDTH-60,
                                                           44)];
    [_btnLogin setTitle:@"下一步" forState:UIControlStateNormal];
    [_btnLogin addTarget:self action:@selector(registerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    _btnLogin.titleLabel.textAlignment = NSTextAlignmentCenter;
    _btnLogin.backgroundColor = RGBColor(30, 172, 134);
    [self.view addSubview:_btnLogin];
    _btnLogin.enabled = NO;
    _btnLogin.alpha = 0.2;
    
    UIButton *termsButton = [[UIButton alloc] init];
    [termsButton setTitleColor:UIColorFromRGB(130, 130, 130) forState:UIControlStateNormal];
    termsButton.titleLabel.font = [UIFont systemFontOfSize:12];
    [termsButton addTarget:self action:@selector(termsButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:termsButton];
    
    NSString *btnTitle = @"注册表示您同意注册协议";
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:btnTitle];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [btnTitle length])];
    [attributedString addAttribute:(NSString *)NSForegroundColorAttributeName
                             value:UIColorFromRGB(34, 177, 139)
                             range:NSMakeRange(7, 4)];
    [termsButton setAttributedTitle:attributedString forState:UIControlStateNormal];
    
    WS(ws);
    [termsButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.view).offset(-49);
        make.centerX.equalTo(ws.view.mas_centerX);
        make.width.equalTo(@(300));
    }];
}

-(void)getVerificationCode:(HDTimerBtn *)btn
{
    [self resignAllResponder];
    if ([HDRegularClass checkOutPhoneNumber:_textfPhoneNum.text])
    {
        [self resignAllResponder];
        if (_textfPhoneNum.text && _textfPhoneNum.text.length > 0)
        {
            [[[HDManager sharedInstance] userService] sendVerificationCode:_textfPhoneNum.text resultBack:^(HDServiceResult *result, id object)
             {
                 if (result.resultCode == HD_RESULT_CODE_SUCCESS)
                 {
                     [btn addTimer];
                 }
                 [result show];
             }];
        }
    }
    else
    {
        [HDTip showMessage:TIP_PHONE_NUM_FORMAT_ERRRO];
    }
}

-(void)resignAllResponder
{
    [_textfPassWord resignFirstResponder];
    [_textfPhoneNum resignFirstResponder];
    [_verificationCodeTextF resignFirstResponder];

}

-(void)registerBtnClick:(UIButton *)btn
{
    [self resignAllResponder];
    [self registerServerWithPhoneNum:_textfPhoneNum.text password:_textfPassWord.text verificationCode:_verificationCodeTextF.text];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_textfPhoneNum resignFirstResponder];
    [_textfPassWord resignFirstResponder];
    [_verificationCodeTextF resignFirstResponder];
}

#pragma mark - 输入框事件，监听登录按钮是否可以点击

- (void)textFieldEditChanged:(UITextField *)textField
{
    if([HDRegularClass checkOutPassWord:_textfPassWord.text] && [HDRegularClass checkOutPhoneNumber:_textfPhoneNum.text] && [HDRegularClass checkOutVerificationCode:_verificationCodeTextF.text])
    {
        _btnLogin.enabled = YES;
        _btnLogin.alpha = 1;
    }
    else
    {
        _btnLogin.enabled = NO;
        _btnLogin.alpha = .2;
    }
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _imaVLinePassWord.highlighted = ([textField isEqual:_textfPassWord]?YES:NO);
    _phoneNumimaVLine.highlighted = ([textField isEqual:_textfPhoneNum]?YES:NO);
    _imaVLineverificationCode.highlighted = ([textField isEqual:_verificationCodeTextF]?YES:NO);
    return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    HDTextFieldType Type = 0;
    if ([textField isEqual:_textfPhoneNum])
    {
        Type = HD_TextFieldType_PASSWORD_PHONE_NUM;
    }
    else if ([textField isEqual:_textfPassWord])
    {
        Type = HD_TextFieldType_PASSWORD;
    }
    else
    {
        Type = HD_TextFieldType_VERIFICATION_CODE;
    }
    NSString * str = [HDCharacterDetectionClass DetectionTextField:textField ChangeCharactersInRange:range replacementString:string type:Type];
    if (str == nil)
    {
        return YES;
    }
    else
    {
        [self resignAllResponder];
        [HDTip showMessage:str];
        return NO;
    }
    return YES;
}


-(void)registerServerWithPhoneNum:(NSString *)phoneNumStr password:(NSString *)passwordStr verificationCode:(NSString *)verificationCodeStr
{
    [[[HDManager sharedInstance]userService] registerByMobilephone:phoneNumStr password:passwordStr verificationCode:verificationCodeStr resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS)
        {
            if (object && [object isKindOfClass:[HDUserModel class]])
            {
                HDUserModel * user =(HDUserModel *)object;
                [[HDManager sharedInstance]setCurrentUser:user];
            
                if(user.provId == 0)
                {
                    HDAreaViewController * area = [[HDAreaViewController alloc]init];
                    backBtnHave = NO;
                    [self.navigationController pushViewController:area animated:YES];
                }
            }
            else
            {
                [HDTip showMessage:@"注册失败"];
            }
        }
        else
        {
            [result show];
        }
    }];
}


- (void)termsButtonClick:(id)sender
{
    [HDWebViewController jumpToWebViewWithUrlType:self urlType:URL_TYPE_TERMS title:@"注册协议"];
}


@end
