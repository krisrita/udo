//
//  HDAreaViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/2.
//  All rights reserved.
//

HDRegionModel * proData = nil;
HDRegionModel * cityData = nil;

#import "HDAreaViewController.h"
#import "HDAreaCell.h"
#import "HDPersonCenterViewController.h"
#import "HDLoading.h"
#import "HDLoginDefine.h"
@interface HDAreaViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tvew;

@end

@implementation HDAreaViewController

-(void)dealloc
{
    ((MLNavigationController *)self.navigationController).canDragBack = YES;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    ((MLNavigationController *)self.navigationController).canDragBack = backBtnHave;
    
    UILabel *centerTitlelabel = [[UILabel alloc]init];
    centerTitlelabel.backgroundColor = [UIColor clearColor];
    centerTitlelabel.textColor = [UIColor whiteColor];
    centerTitlelabel.font = [UIFont systemFontOfSize:18];
    
    if (self.VCAreaType == area_sheng) {
        centerTitlelabel.text = @"省";
        proData = nil; cityData = nil;
    } else if (self.VCAreaType == area_shi) {
        centerTitlelabel.text = @"市";
    } else if (self.VCAreaType == area_xian) {
        centerTitlelabel.text = @"县/区";
    }
    
    [centerTitlelabel sizeToFit];
    self.centerView = centerTitlelabel;

    if (backBtnHave) self.leftView = [HDUICommon leftBackView:self];

    [self initViews];
    
    [self initValues];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [HDLoading stopAnimating];
}

-(void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - ***************** Init Views *****************
- (void)initViews
{
    _tvew = [[UITableView alloc] initWithFrame:CGRectMake(0,
                                                                      64,
                                                                      APP_CONTENT_WIDTH,
                                                                      APP_CONTENT_HEIGHT-64)
                                                     style:UITableViewStylePlain];
    _tvew.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tvew.delegate = self;
    _tvew.dataSource = self;
    [self.view addSubview:_tvew];
}

#pragma mark - ************* 初始化变量 *************
- (void)initValues
{
    if (!self.aryData)
    {
        [HDLoading startAnimating];
        self.aryData = [NSMutableArray array];
        __weak HDAreaViewController * weakSelf = self;
        [[HDManager sharedInstance].userService getRegionSource:^(HDServiceResult *result, id object) {
            HDRegionSourceModel *regionSource = (HDRegionSourceModel *)object;
            weakSelf.regionSource = regionSource;
            NSArray *provinces = regionSource.getProvinces;
            weakSelf.aryData = [NSMutableArray arrayWithArray:provinces];
            [weakSelf.tvew reloadData];
            [HDLoading stopAnimating];
        }];
    }
}

- (areaType)getNextVCtype:(areaType)type
{
    switch (type)
    {
        case area_sheng:
            
            return area_shi;
            
            break;
            
        case area_shi:
            
            return area_xian;
            
            break;
            
        case area_xian:
            
            return area_xian;
            
            break;
            
        default:
            break;
    }
}


#pragma mark - ************* delegate *************

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 46.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.0f;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _aryData.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *areaIdentifier = @"areaIdentifier";
    HDAreaCell *cell = [tableView dequeueReusableCellWithIdentifier:areaIdentifier];
    if (cell == nil)
    {
        cell = [[HDAreaCell alloc] initWithStyle:UITableViewCellStyleDefault
                                            reuseIdentifier:areaIdentifier];
    }
    if (indexPath.row < self.aryData.count)
    {
        HDRegionModel * model = [self.aryData objectAtIndex:indexPath.row];
        if (model) {
            [cell setData:model];
        }
    }
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    HDAreaCell * cell = (HDAreaCell *)[tableView cellForRowAtIndexPath:indexPath];
    if (cell && [cell isKindOfClass:[HDAreaCell class]])
    {
        HDRegionModel * model = [cell Data];
        if (self.VCAreaType == area_sheng)
        {
            NSMutableArray * tempAry = (NSMutableArray *)[self.regionSource getCitys:model.Id];
            if (tempAry && [tempAry isKindOfClass:[NSArray class]] && tempAry.count > 0)
            {
                proData = model;
                HDAreaViewController *controller = [[HDAreaViewController alloc] init];
                controller.aryData = tempAry;
                // 是否是直辖市
                BOOL isGovernmentCity = [model.name isEqualToString:@"北京"] || [model.name isEqualToString:@"天津"] || [model.name isEqualToString:@"重庆"] || [model.name isEqualToString:@"上海"];
                controller.VCAreaType = isGovernmentCity ? area_xian : area_shi;
                controller.regionSource = self.regionSource;
                [self.navigationController pushViewController:controller animated:YES];
            } else {
                [self changeReginWithProReginData:model cityRegionData:nil countyRegionData:nil];
            }
        }
        else if (self.VCAreaType == area_shi)
        {
            NSMutableArray * tempAry = (NSMutableArray *)[self.regionSource getCitys:model.Id];
            if (tempAry && [tempAry isKindOfClass:[NSArray class]] && tempAry.count > 0)
            {
                cityData = model;
                HDAreaViewController *controller = [[HDAreaViewController alloc] init];
                controller.aryData = tempAry;
                controller.VCAreaType = area_xian;
                [self.navigationController pushViewController:controller animated:YES];
            }
            else
            {
                [self changeReginWithProReginData:proData cityRegionData:model countyRegionData:nil];
            }
        }
        else if(self.VCAreaType ==  area_xian)
        {
            [self changeReginWithProReginData:proData cityRegionData:cityData countyRegionData:model];
        }
    }
}


-(void)changeReginWithProReginData:(HDRegionModel *)pro cityRegionData:(HDRegionModel *)city countyRegionData:(HDRegionModel *)county
{
    HDUserModel * user = [[HDManager sharedInstance]currentUser];

    if (pro.Id > 0)
    {
        [[[HDManager sharedInstance]userService]changeRegion:user.Id provinceId:proData.Id cityId:city.Id regionId:county.Id?county.Id:0 resultBack:^(HDServiceResult *result, id object) {
            if (result.resultCode == HD_RESULT_CODE_SUCCESS)
            {
                user.provId = proData.Id;
                user.cityId = cityData.Id;
                user.regionId = county.Id;
                user.proName = pro.name;
                user.cityName = city.name;
                user.regionName = county.name;
                [[HDManager sharedInstance]setCurrentUser:user];
                for (UIViewController * vc in [self.navigationController viewControllers])
                {
                    if ([vc isKindOfClass:[HDPersonCenterViewController class]])
                    {
                        [self.navigationController popToViewController:vc animated:YES];
                    }
                    else
                    {
                        [self.navigationController dismissViewControllerAnimated:YES completion:NULL];
                        [[NSNotificationCenter defaultCenter]postNotificationName:NOTIFICATION_LOGIN_SUCCESS object:nil];
                    }
                }
            }
            [result show];
        }];

    }
}

@end
