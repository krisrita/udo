//
//  HDPeopleReviewViewController.h
//  udo_stu
//
//  Created by kaola on 15/6/22.
//  All rights reserved.
//

#import "HDBaseViewController.h"

@interface HDPeopleReviewViewController : HDBaseViewController

@end
