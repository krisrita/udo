//
//  HDVerifyViewController.h
//  udo_stu
//
//  Created by nobody on 15-5-31.
//  All rights reserved.
//

/**
 *
 */
typedef enum {
    /** 修改电话 */
    HDVerifyVCUseType_ChangePhoneNum,
    /** 忘记密码 */
    HDVerifyVCUseType_ForgetPassWord

} HDVerifyVCUseType;


#import "HDBaseViewController.h"

//验证界面
@interface HDVerifyViewController : HDBaseViewController

@property (nonatomic,assign)HDVerifyVCUseType userType;

/**用于忘记密码的参数*/
@property (nonatomic,copy)NSString * phoneNumStr;

/**用于修改手机号码的参数*/
@property (nonatomic,copy)NSString * passWordStr;

@end
