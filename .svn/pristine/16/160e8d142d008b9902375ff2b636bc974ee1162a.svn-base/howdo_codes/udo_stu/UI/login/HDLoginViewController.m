//
//  MCLoginViewController.m
//
//  Created by nobody on 14-2-17.
//  All rights reserved.
//


#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

#define RKL_METHOD_PREPEND(x) x

#define LOGIN_BTN_TAG 1000
#define LOOK_BTN_TAG 2000
#define REGISTER_BTN_TAG 3000
#define SIGNINBUTTON_TAG    100
#import "HDLoginDefine.h"
#import "HDLoginViewController.h"
#import "HDForgetPassWordViewController.h"
#import "RegexKitLite.h"
#import "HDAreaViewController.h"
#import "HDRegularClass.h"
#import "HDEyeBtn.h"
#import "HDCharacterDetectionClass.h"

@interface HDLoginViewController ()<UITextFieldDelegate>

@property (nonatomic, strong) UITextField *textfPhoneNum;
@property (nonatomic, strong) UITextField *textfPassWord;
@property (nonatomic, strong) UIImageView *imaVLineName;
@property (nonatomic, strong) UIImageView *imaVLinePassWord;
@property (nonatomic, strong) UIButton *btnLogin;

@end

@implementation HDLoginViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UITextFieldTextDidChangeNotification
                                                  object:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = YES;
    ((MLNavigationController *)self.navigationController).canDragBack = YES;
}


- (void)setNavbar
{
    UILabel *centerTitlelabel = [[UILabel alloc]init];
    centerTitlelabel.text = @"登录";
    centerTitlelabel.backgroundColor = [UIColor clearColor];
    centerTitlelabel.textColor = [UIColor whiteColor];
    centerTitlelabel.font = [UIFont systemFontOfSize:18];
    [centerTitlelabel sizeToFit];
    self.centerView = centerTitlelabel;
    
    self.leftView = [HDUICommon leftBackView:self];
    
}

-(void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

-(void)initView
{
    [self setNavbar];
    self.view.userInteractionEnabled  = YES;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setNavbar];
    self.view.backgroundColor = RGBColor(255.0, 255.0, 255.0);
    
    [self initViews];
}

- (void)initViews
{
    /// 用户名
    _textfPhoneNum = [[UITextField alloc] initWithFrame:CGRectMake(30, 64+50, APP_CONTENT_WIDTH-60, 30)];
    _textfPhoneNum.backgroundColor = [UIColor clearColor];
    _textfPhoneNum.contentMode = UIViewContentModeCenter;
    _textfPhoneNum.returnKeyType = UIReturnKeyDone;
    _textfPhoneNum.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfPhoneNum.delegate = self;
    _textfPhoneNum.keyboardType =UIKeyboardTypeNumberPad;
    [_textfPhoneNum addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    _textfPhoneNum.secureTextEntry = NO;
    _textfPhoneNum.placeholder = @"手机号";
    [self.view addSubview:_textfPhoneNum];
    
    _imaVLineName = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                      highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLineName.frame = CGRectMake(_textfPhoneNum.frame.origin.x,
                                     _textfPhoneNum.frame.origin.y+_textfPhoneNum.frame.size.height,
                                     _textfPhoneNum.frame.size.width,
                                     3);
    [self.view addSubview:_imaVLineName];
    
    _textfPassWord = [[UITextField alloc] initWithFrame:CGRectMake(30,
                                                                   _textfPhoneNum.frame.size.height+_textfPhoneNum.frame.origin.y+20,
                                                                   APP_CONTENT_WIDTH-60 - 30,
                                                                   30)];
    
    _textfPassWord.backgroundColor = [UIColor clearColor];
    _textfPassWord.contentMode = UIViewContentModeCenter;
    _textfPassWord.returnKeyType = UIReturnKeyDone;
    _textfPassWord.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfPassWord.delegate = self;
    _textfPassWord.secureTextEntry = YES;
    _textfPassWord.placeholder = @"密码";

    [_textfPassWord addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    [self.view addSubview:_textfPassWord];
    
    HDEyeBtn * eyeBtn = [[HDEyeBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_textfPassWord.frame), CGRectGetMinY(_textfPassWord.frame), 30, 30)];
    [self.view addSubview:eyeBtn];
    [eyeBtn addTarget:self action:@selector(eyeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    _imaVLinePassWord = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                          highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _imaVLinePassWord.frame = CGRectMake(_textfPassWord.frame.origin.x,
                                         _textfPassWord.frame.origin.y+_textfPassWord.frame.size.height,
                                         _imaVLineName.frame.size.width,
                                         3);
    [self.view addSubview:_imaVLinePassWord];
    
    
    UIButton *btnForget = [[UIButton alloc] initWithFrame:CGRectMake(_textfPassWord.frame.size.width+_textfPassWord.frame.origin.x-30,
                                                                     _textfPassWord.frame.origin.y+_textfPassWord.frame.size.height,
                                                                     50,
                                                                     30)];
    [btnForget addTarget:self action:@selector(btnForgetClick:) forControlEvents:UIControlEventTouchUpInside];
    [btnForget setTitle:@"忘记密码" forState:UIControlStateNormal];
    [btnForget setTitleColor:RGBColor(30, 172, 134) forState:UIControlStateNormal];
    btnForget.titleLabel.font = [UIFont systemFontOfSize:11];
    btnForget.backgroundColor = [UIColor clearColor];
    [self.view addSubview:btnForget];
    
    _btnLogin = [[UIButton alloc] initWithFrame:CGRectMake(30,
                                                           _textfPassWord.frame.origin.y+_textfPassWord.frame.size.height+50,
                                                           APP_CONTENT_WIDTH-60,
                                                           44)];
    [_btnLogin setTitle:@"登录" forState:UIControlStateNormal];
    [_btnLogin addTarget:self action:@selector(loginClick:) forControlEvents:UIControlEventTouchUpInside];
    _btnLogin.titleLabel.textAlignment = NSTextAlignmentCenter;
    _btnLogin.backgroundColor = RGBColor(30, 172, 134);
    [self.view addSubview:_btnLogin];
    _btnLogin.enabled = NO;
    _btnLogin.alpha = 0.2;
}

-(void)eyeBtnClick:(HDEyeBtn *)btn
{
    btn.isOn = !btn.isOn;
    if (btn.isOn)
    {
        _textfPassWord.secureTextEntry = NO;
    }
    else
    {
        _textfPassWord.secureTextEntry = YES;
    }
}

- (void)btnForgetClick:(UIButton *)btn
{
    HDForgetPassWordViewController * forgetPass = [[HDForgetPassWordViewController alloc]init];
    [self.navigationController pushViewController:forgetPass animated:YES];
}

-(void)resignAllresponer
{
    [_textfPassWord resignFirstResponder];
    [_textfPhoneNum resignFirstResponder];
}

- (void)loginClick:(UIButton *)btn
{
    if (![self checkPhoneNumber:_textfPhoneNum.text])
    {
        return;
    }
    else if (![self isPassWord:_textfPassWord.text])
    {
        NSLog(@"密码长度啊 特殊字符什么的也不合法");
    }
    else
    {
        [self resignAllresponer];
        [[[HDManager sharedInstance] userService]loginByMobilephone:_textfPhoneNum.text password:_textfPassWord.text resultBack:^(HDServiceResult *result, id object) {
            if (result.resultCode == HD_RESULT_CODE_SUCCESS)
            {
                if (object && [object isKindOfClass:[HDUserModel class]])
                {
                    HDUserModel * user = (HDUserModel *)object;
                    [[HDManager sharedInstance]setCurrentUser:object];
                    if(user.provId == 0)
                    {
                        HDAreaViewController * area = [[HDAreaViewController alloc]init];
                        backBtnHave = NO;
                        [self.navigationController pushViewController:area animated:YES];
                    }
                    else
                    {
                        [[NSNotificationCenter defaultCenter]postNotificationName:NOTIFICATION_LOGIN_SUCCESS object:nil];

                        [self.navigationController dismissViewControllerAnimated:YES completion:NULL];
                    }
                }
            }
            else
            {
                [HDTip showMessage:result.resultDesc];
            }
        }];
    }
}

#pragma mark - 检查手机号是否正确（只判断第一位是否为1）

- (BOOL)checkPhoneNumber:(NSString *)string
{
    if ([string isMatchedByRegex:@"(1)[0-9]{10}$"])
    {
        return YES;
    }
    return NO;
}
- (BOOL)checkPhoneNumber:(NSString *)phone passWord:(NSString *)Password
{
    if ([self checkPhoneNumber:phone] && [self isPassWord:Password])
    {
        return YES;
    }
    return NO;
}

- (BOOL)ishaveTeShuzifu:(NSString *)str
{
    NSCharacterSet * nameCharacters = [[NSCharacterSet characterSetWithCharactersInString:@"_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"] invertedSet];
    NSRange userNameRange = [str rangeOfCharacterFromSet:nameCharacters];
    if (userNameRange.location != NSNotFound)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

- (BOOL)isPassWord:(NSString *)str
{
    NSString *passWordRegex = @"^[\\dA-Za-z(!@#$%&)]{6,16}$";
    NSPredicate *passWordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passWordRegex];
    return [passWordTest evaluateWithObject:str];
    
    return NO;
}

#pragma mark - 输入框事件，监听登录按钮是否可以点击

- (void)textFieldEditChanged:(UITextField *)textField
{
    if ([HDRegularClass checkOutPhoneNumber:_textfPhoneNum.text] && [HDRegularClass checkOutPassWord:_textfPassWord.text])
    {
        _btnLogin.enabled = YES;
        _btnLogin.alpha = 1;
    }
    else
    {
        _btnLogin.enabled = NO;
        _btnLogin.alpha = 0.2;
    }
}


#pragma mark - UItextFieldView的代理方法

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _imaVLinePassWord.highlighted = ([textField isEqual:_textfPhoneNum]?NO:YES);
    _imaVLineName.highlighted = ([textField isEqual:_textfPhoneNum]?YES:NO);
    return YES;
}

-(void)resignAllResponder
{
    [_textfPassWord resignFirstResponder];
    [_textfPhoneNum resignFirstResponder];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    HDTextFieldType Type = 0;
    if ([textField isEqual:_textfPassWord])
    {
        Type = HD_TextFieldType_PASSWORD;
    }
    else if ([textField isEqual:_textfPhoneNum])
    {
        Type = HD_TextFieldType_PASSWORD_PHONE_NUM;
    }
    NSString * str = [HDCharacterDetectionClass DetectionTextField:textField ChangeCharactersInRange:range replacementString:string type:Type];
    if (str == nil)
    {
        return YES;
    }
    else
    {
        [self resignAllResponder];
        [HDTip showMessage:str];
        return NO;
    }
    _btnLogin.enabled = [self checkPhoneNumber:_textfPhoneNum.text passWord:_textfPassWord.text];
    _btnLogin.alpha = (_btnLogin.enabled?1:0.2);
    return YES;
}

@end
