//
//  HDChangePhoneNumberViewController.m
//  udo_stu
//
//  Created by nobody on 15-6-7.
//  All rights reserved.
//

#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]


#import "HDChangePhoneNumberViewController.h"
#import "HDRegularClass.h"
#import "HDVerifyViewController.h"
#import "HDEyeBtn.h"
#import "HDCharacterDetectionClass.h"

@interface HDChangePhoneNumberViewController ()

@property (nonatomic, strong) UITextField *textfPassWord;
@property (nonatomic, strong) UITextField *textfPhoneNum;
@property (nonatomic, strong) UIImageView *passWordLine;
@property (nonatomic, strong) UIImageView *phoneNumLine;
@property (nonatomic, strong) UIButton *btnLogin;

@end

@implementation HDChangePhoneNumberViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    UILabel *centerTitlelabel = [[UILabel alloc]init];
    centerTitlelabel.text = @"修改手机号";
    centerTitlelabel.backgroundColor = [UIColor clearColor];
    centerTitlelabel.textColor = [UIColor whiteColor];
    centerTitlelabel.font = [UIFont systemFontOfSize:18];
    [centerTitlelabel sizeToFit];
    self.centerView = centerTitlelabel;
    
    self.leftView = [HDUICommon leftBackView:self];
    
    
    _textfPassWord = [[UITextField alloc] initWithFrame:CGRectMake(30, 64+50, APP_CONTENT_WIDTH-90, 30)];
    
    _textfPassWord.backgroundColor = [UIColor clearColor];
    _textfPassWord.contentMode = UIViewContentModeCenter;
    _textfPassWord.returnKeyType = UIReturnKeyDone;
    _textfPassWord.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfPassWord.delegate = self;
    _textfPassWord.secureTextEntry = YES;
    [_textfPassWord addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    _textfPassWord.placeholder = @"请输入密码";
    [self.view addSubview:_textfPassWord];
    
    HDEyeBtn * eyeBtn = [[HDEyeBtn alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_textfPassWord.frame), CGRectGetMinY(_textfPassWord.frame), 30, 30)];
    [self.view addSubview:eyeBtn];
    [eyeBtn addTarget:self action:@selector(eyeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    _passWordLine = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                      highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _passWordLine.frame = CGRectMake(_textfPassWord.frame.origin.x,
                                     _textfPassWord.frame.origin.y+_textfPassWord.frame.size.height,
                                     _textfPassWord.frame.size.width + 30,
                                     3);
    [self.view addSubview:_passWordLine];
    

    _textfPhoneNum = [[UITextField alloc] initWithFrame:CGRectMake(30,
                                                                   _textfPassWord.frame.size.height+_textfPassWord.frame.origin.y+20,
                                                                   APP_CONTENT_WIDTH-60,
                                                                   30)];
    
    _textfPhoneNum.backgroundColor = [UIColor clearColor];
    _textfPhoneNum.contentMode = UIViewContentModeCenter;
    _textfPhoneNum.returnKeyType = UIReturnKeyDone;
    _textfPhoneNum.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textfPhoneNum.delegate = self;
    _textfPhoneNum.keyboardType =UIKeyboardTypeNumberPad;
    _textfPhoneNum.placeholder = @"请输入新手机号";
    
    // textfield添加编辑事件
    [_textfPhoneNum addTarget:self
                       action:@selector(textFieldEditChanged:)
             forControlEvents:UIControlEventEditingChanged];
    [self.view addSubview:_textfPhoneNum];
    
    _phoneNumLine = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"ic_login_line.png"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]
                                          highlightedImage:[[UIImage imageNamed:@"ic_logoin_green"] stretchableImageWithLeftCapWidth:10 topCapHeight:0]];
    _phoneNumLine.frame = CGRectMake(_textfPhoneNum.frame.origin.x,
                                         _textfPhoneNum.frame.origin.y+_textfPhoneNum.frame.size.height,
                                         _textfPhoneNum.frame.size.width,
                                         3);
    [self.view addSubview:_phoneNumLine];
    
    
    
    
    _btnLogin = [[UIButton alloc] initWithFrame:CGRectMake(30,
                                                           _textfPhoneNum.frame.origin.y+_textfPhoneNum.frame.size.height+50,
                                                           APP_CONTENT_WIDTH-60,
                                                           44)];
    [_btnLogin setTitle:@"下一步" forState:UIControlStateNormal];
    [_btnLogin addTarget:self action:@selector(nextBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    _btnLogin.titleLabel.textAlignment = NSTextAlignmentCenter;
    _btnLogin.backgroundColor = RGBColor(30, 172, 134);
    [self.view addSubview:_btnLogin];
    _btnLogin.enabled = NO;
    _btnLogin.alpha = 0.2;
}
-(void)eyeBtnClick:(HDEyeBtn *)btn
{
    [btn setIsOn:!btn.isOn];
    _textfPassWord.secureTextEntry = !btn.isOn;
}
-(void)nextBtnClick:(UIButton *)btn
{
    [self resignAllResponder];
    _btnLogin.enabled = NO;
    if (_textfPhoneNum.text && _textfPhoneNum.text.length > 0 &&  _textfPassWord.text && _textfPassWord.text.length > 0)
    {
        HDUserModel * model = [[HDManager sharedInstance]currentUser];
        [[[HDManager sharedInstance]userService]checkBeforeChangeMobilephone:[model Id] password:_textfPassWord.text newMobilephone:_textfPhoneNum.text resultBack:^(HDServiceResult *result, id object) {
            if (result.resultCode == HD_RESULT_CODE_SUCCESS)
            {
                [[[HDManager sharedInstance] userService] sendVerificationCode:_textfPhoneNum.text resultBack:^(HDServiceResult *result, id object)
                 {
                     if (result.resultCode == HD_RESULT_CODE_SUCCESS)
                     {
                         HDVerifyViewController * verfity = [[HDVerifyViewController alloc]init];
                         verfity.phoneNumStr = _textfPhoneNum.text;
                         verfity.passWordStr = _textfPassWord.text;
                         verfity.userType = HDVerifyVCUseType_ChangePhoneNum;
                         [self.navigationController pushViewController:verfity animated:YES];
                     }
                     [result show];
                     _btnLogin.enabled =  YES;
                 }];
            }
            else
            {
                [result show];
                _btnLogin.enabled = YES;
            }
        }];
    }
}

-(void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (BOOL)ishaveTeShuzifu:(NSString *)str
{
    NSCharacterSet * nameCharacters = [[NSCharacterSet characterSetWithCharactersInString:@"_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"] invertedSet];
    NSRange userNameRange = [str rangeOfCharacterFromSet:nameCharacters];
    if (userNameRange.location != NSNotFound)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

- (BOOL)isPassWord:(NSString *)str
{
    if (str.length>=6 && str.length<=20)
    {
        if ([self ishaveTeShuzifu:str])
        {
            return NO;
        }
        return YES;
    }
    return NO;
}



#pragma mark - 输入框事件，监听登录按钮是否可以点击

- (void)textFieldEditChanged:(UITextField *)textField
{
    if ([HDRegularClass checkOutPhoneNumber:_textfPhoneNum.text] && [HDRegularClass checkOutPassWord:_textfPassWord.text])
    {
        _btnLogin.enabled = YES;
        _btnLogin.alpha = 1;
    }
    else
    {
        _btnLogin.enabled = NO;
        _btnLogin.alpha = .2;
    }
}

-(void)resignAllResponder
{
    [_textfPhoneNum resignFirstResponder];
    [_textfPassWord resignFirstResponder];
}
#pragma mark - UItextFieldView的代理方法


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    HDTextFieldType Type = 0;
    if ([textField isEqual:_textfPassWord])
    {
        Type = HD_TextFieldType_PASSWORD;
    }
    else if ([textField isEqual:_textfPhoneNum])
    {
        Type = HD_TextFieldType_PASSWORD_PHONE_NUM;
    }
    NSString * str = [HDCharacterDetectionClass DetectionTextField:textField ChangeCharactersInRange:range replacementString:string type:Type];
    if (str == nil)
    {
        return YES;
    }
    else
    {
        [self resignAllResponder];
        [HDTip showMessage:str];
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _passWordLine.highlighted = ([textField isEqual:_textfPassWord]?YES:NO);
    _phoneNumLine.highlighted = ([textField isEqual:_textfPhoneNum]?YES:NO);
    return YES;
}

#pragma mark -  点击任意一个输入框的清除按钮 将登录按钮变成不可以点击

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    _btnLogin.enabled = NO;
    _btnLogin.alpha = 0.2;
    
    return YES;
}


@end
