#import "HDIndicatorView.h"

#define  pointSpacing  25

@implementation HDIndicatorView

- (id)initWithFrame:(CGRect)frame andWithPageCount:(int)count
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.frame = frame;
        int pointWidth = frame.size.height;
        if (count%2 == 0)
        {
            beginX = APP_SCREEN_WIDTH/2 - pointSpacing/2 - pointWidth - (pointWidth + pointSpacing) * (count/2-1);
        }
        else
        {
            beginX = APP_SCREEN_WIDTH/2 - pointWidth/2 - (pointWidth +pointSpacing)*(count - 1)/2;
        }
     
        for (int i = 0 ; i < count; i++)
        {
            UIImageView * imgView = [[UIImageView alloc]initWithFrame:CGRectMake(beginX + i *(pointSpacing + pointWidth), 0, pointWidth, pointWidth)];
            imgView.image = [UIImage imageNamed:@"ic_guide_point"];
            [self addSubview:imgView];
        }
        if (count)
        {
            moveimg = [[UIImageView alloc]initWithFrame:CGRectMake(beginX-3.5, -5, 17.5, 20)];
            moveimg.image = [UIImage imageNamed:@"ic_guide_logo"];
            self.currentIndex = 0;
            [self addSubview:moveimg];
        }
    }
    return self;
}

-(void)setCurrentIndex:(int)tempIndex
{
    if (tempIndex != self.currentIndex)
    {
        [UIView animateWithDuration:.1 delay:0 options:0 animations:^{
            CGFloat x = moveimg.frame.origin.x + (tempIndex - self.currentIndex)*(self.frame.size.height + pointSpacing );
            moveimg.frame = CGRectMake(x, moveimg.frame.origin.y, moveimg.frame.size.width, moveimg.frame.size.height);
            
        } completion:^(BOOL finished) {
            _currentIndex = tempIndex;
        }];

    }

}



@end
