
#import <UIKit/UIKit.h>

@interface HDTextField : UITextField

@end
