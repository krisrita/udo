//
//  HDMainViewController.m
//  udo_stu
//
//  Created by nobody on 15/5/31.
//  All rights reserved.
//

#import "HDMainViewController.h"
#import "HDMainCell.h"
#import "HDGuideViewController.h"
#import "MLNavigationController.h"
#import "HDShareProxy.h"
#import "HDCourseDetailViewController.h"
#import "HDMainBlankPageView.h"
#import "HDNetworkConfig.h"
#import "HDLoginProxy.h"

@interface HDMainViewController ()<HDTableViewDelegate>
{
    NSInteger _lastCourseId;
    NSInteger uid;
    NSInteger cat_type;
    NSInteger easy_type;
    NSInteger sort_type;
}

@property (nonatomic,strong)HDTableView *hdTableView;

@end

@implementation HDMainViewController

#pragma mark - Life Cycle

//- (void)dealloc {
//    [[NSNotificationCenter defaultCenter] removeObserver:self];
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:[UIImage imageNamed:@"btn_share_default"] forState:0];
    [rightButton setFrame:CGRectMake(0, 0, 44, 44)];
    [rightButton addTarget:self action:@selector(rightViewClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.rightView = rightButton;
    self.leftView = [HDUICommon leftBackView:self];
    self.centerView = [HDUICommon getTitleView:self.schoolModel.name];
    [self initLoadView];
    
    _lastCourseId = 0;
    [self requestData:_lastCourseId];
}

#pragma mark - Init View
- (void)initLoadView
{
    HDTableView *hdTableView = [[HDTableView alloc]initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT) rowHeightType:HD_CELL_HEIGHT_TYPE_FIXED cellClassName:[HDMainCell class] blankViewClass:[HDMainBlankPageView class] refreshType:HD_TABLE_REFRESH_UPDOWN];
    self.hdTableView = hdTableView;
    self.hdTableView.HDTableIsRefreshing = YES;
    hdTableView.hdTableViewDelegate = self;
    [self.view addSubview:self.hdTableView];

    hdTableView.tableViewEdgeinsets = UIEdgeInsetsMake(CGRectGetMaxY(self.headView.frame), 0, 0, 0);
    [self.view bringSubviewToFront:self.headView];
}

#pragma mark - Network Request
- (void)requestData:(NSInteger)lastCourseId
{
    __weak __typeof(self)weakSelf = self;
    [[HDManager sharedInstance].courseService getCourseList:self.schoolModel.Id lastCourseId:lastCourseId resultBack:^(HDServiceResult *result, NSArray *items) {
        if (!weakSelf) return;
        __strong __typeof(weakSelf)strongSelf = weakSelf;
        if (HD_RESULT_CODE_SUCCESS == result.resultCode || HD_RESULT_CODE_EMPTY == result.resultCode) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (0 == lastCourseId) {
                    [strongSelf.hdTableView setTableDataWithAry:items];
                }else {
                    [strongSelf.hdTableView tableAppendDataWithAry:items];
                }
            });
        }else if (HD_RESULT_CODE_NETWORK_FAILURE == result.resultCode) {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if (0 == lastCourseId) {
                    [strongSelf.hdTableView setTableDataWithAry:nil];
                    [strongSelf.hdTableView setTableNetworkFailure];
                }
            });
        }else if (HD_RESULT_CODE_FAILURE == result.resultCode)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [strongSelf.hdTableView setTableDataWithAry:nil];
            });
        }
        
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (0 == lastCourseId) {
                strongSelf.hdTableView.HDTableIsRefreshing = NO;
            }else {
                strongSelf.hdTableView.HDTableIsLoadingMore = NO;
            }
        });
        
    }];
}

#pragma mark - CustomDelegate
#pragma mark HDTableViewDelegate
///下拉刷新代理方法
- (void)HDTableViewDidTriggerRefresh:(HDTableView*)pullTableView
{
    _lastCourseId = 0;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self requestData:_lastCourseId];
    });
}

- (void)HDTableViewDidTriggerLoadMore:(HDTableView*)pullTableView
{
    HDCourseModel *model = [[self.hdTableView getTableDataAry] lastObject];
    _lastCourseId = model.Id;
    
    [self requestData:_lastCourseId];
}

-(void)HDTableViewDidSelected:(id)data didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HDCourseDetailViewController *courseDetailViewController = [[HDCourseDetailViewController alloc]init];
    courseDetailViewController.courseModel = data;
    
    [self.navigationController pushViewController:courseDetailViewController animated:YES];
}

#pragma mark - Event Response
- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:self.animation];
}

- (void)rightViewClicked:(UIButton *)sender
{
    [[HDShareProxy sharedInstance]share:self title:SHARE_TITLE text:SHARE_CONTENT imageUrl:SHARE_IMAGE_URL image:nil resourceUrl:[HDNetworkConfig getModuleUrl:URL_TYPE_SHARE] completion:^(HDCommonResult *result) {
        [HDTip showMessage:@"分享成功"];
    } viewPoped:nil viewDissMissed:nil];
}

@end
