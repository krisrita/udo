//
//  HDMainBlankPageView.h
//  udo_stu
//
//  Created by nobody on 15/6/20.
//  All rights reserved.
//

#import "HDBlankPageView.h"

@interface HDMainBlankPageView : HDBlankPageView

@end
