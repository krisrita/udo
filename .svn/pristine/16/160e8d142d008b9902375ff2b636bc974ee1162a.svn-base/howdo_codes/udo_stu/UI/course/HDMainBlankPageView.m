//
//  HDMainBlankPageView.m
//  udo_stu
//
//  Created by nobody on 15/6/20.
//  All rights reserved.
//

#import "HDMainBlankPageView.h"

@implementation HDMainBlankPageView


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.Label.text = @"暂无相关数据";
        self.imgView.image  = [UIImage imageNamed:@"ic_no_net"];
        self.Label.textColor = [UIColor blackColor];
    }
    return self;
}

- (id)initWithFrameIfNetworkFailure:(CGRect)frame
{
    self = [super initWithFrameIfNetworkFailure:frame];
    if (self)
    {
        self.Label.text = @"网络不给力,请稍后重试";
        self.imgView.image  = [UIImage imageNamed:@"ic_no_net"];
        self.Label.textColor = [UIColor blackColor];
    }
    return self;
}
@end
