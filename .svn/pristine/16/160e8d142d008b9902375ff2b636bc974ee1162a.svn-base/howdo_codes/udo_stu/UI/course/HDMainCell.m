//
//  MCMainCell.m
//
//  Created by nobody on 14-2-24.
//  . All rights reserved.
//
#define CELL_XSPACE  5
#define CELL_YSPACE  5
#import "HDMainCell.h"
#import "HDCourseModel.h"
@interface HDMainCell ()

@property (nonatomic ,strong)UILabel *titleLabel;
@property (nonatomic ,strong)UILabel *subTitleLabel;
@property (nonatomic ,strong)UILabel *learnNumLabel;
@property (nonatomic ,strong)UILabel *upLabel;
@property (nonatomic ,strong)UILabel *downLabel;
@property (nonatomic ,strong)HDImageView *moocImageView;
@property (nonatomic ,strong)UIImageView *upImageView;
@property (nonatomic ,strong)UIImageView *downImageView;
@property (nonatomic ,strong)UIImageView *videoImageView;
@property (nonatomic,strong)UIView *lineView;
@end

@implementation HDMainCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        // Initialization code
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        _moocImageView = [[HDImageView alloc]init];
        [self.contentView addSubview:_moocImageView];
        
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.numberOfLines = 1;
        _titleLabel.font = [UIFont systemFontOfSize:15];;
        _titleLabel.textColor = UIColorFromRGB(33, 33, 33);
        _titleLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_titleLabel];
        
        _subTitleLabel = [[UILabel alloc]init];
        _subTitleLabel.numberOfLines = 1;
        _subTitleLabel.textAlignment = NSTextAlignmentCenter;
        _subTitleLabel.font = [UIFont systemFontOfSize:12];;

        _subTitleLabel.textColor = [UIColor whiteColor];
        _subTitleLabel.backgroundColor = UIColorFromRGB(235, 125, 10);
        [self.contentView  addSubview:_subTitleLabel];
        
        UIImage *videoImage = [UIImage imageNamed:@"video"];
        UIImageView *videoImageView = [[UIImageView alloc]initWithImage:videoImage];
        self.videoImageView = videoImageView;
        [self.contentView addSubview:videoImageView];
        
        _learnNumLabel = [[UILabel alloc]init];
        _learnNumLabel.backgroundColor = [UIColor clearColor];
        _learnNumLabel.font = [UIFont systemFontOfSize:12];;
        _learnNumLabel.textColor = UIColorFromRGB(29, 29, 29);

        [self.contentView addSubview:_learnNumLabel];
        
        
        UIImage *upImage = [UIImage imageNamed:@"up"];
        UIImageView *upImageView = [[UIImageView alloc]initWithImage:upImage];
        self.upImageView =upImageView;
        [self.contentView addSubview:upImageView];
        
        _upLabel = [[UILabel alloc]init];
        _upLabel.font = [UIFont systemFontOfSize:12];;
        _upLabel.backgroundColor = [UIColor clearColor];
        _upLabel.textColor = UIColorFromRGB(29, 29, 29);

        [self.contentView addSubview:_upLabel];
        
        UIImage *downImage = [UIImage imageNamed:@"down"];
        UIImageView *downImageView = [[UIImageView alloc]initWithImage:downImage];
        self.downImageView = downImageView;
        [self.contentView addSubview:downImageView];
        
        _downLabel = [[UILabel alloc]init];
        _downLabel.font = [UIFont systemFontOfSize:12];;
        _downLabel.backgroundColor = [UIColor clearColor];
        _downLabel.textColor = UIColorFromRGB(29, 29, 29);

        [self.contentView addSubview:_downLabel];
        
        
        UIView *lineView = [[UIView alloc]init];
        lineView.backgroundColor = UIColorFromRGB(34, 177, 139);
        self.lineView = lineView;
        [self.contentView addSubview:lineView];
        
    }
    return self;
}
-(void)setCellData:(id)cellData
{
    [super setCellData:cellData];
    HDCourseModel *courseModel = (HDCourseModel *)cellData;
    
    [_moocImageView setHDImageURL:[NSURL URLWithString:[courseModel.imageUrl medium]] placeholderImage:[[UIImage imageNamed:@"course_ placeholder"] resizableImageWithCapInsets:UIEdgeInsetsMake(15, 15, 15, 15)] imageType:HD_IMAGE_SQUARE];
    _titleLabel.text = courseModel.name;
    self.learnNumLabel.text = [NSString stringWithFormat:@"%ld",(long)courseModel.watchedNum];
    self.upLabel.text = [NSString stringWithFormat:@"%ld",(long)courseModel.likedNum];
    self.downLabel.text = [NSString stringWithFormat:@"%ld",(long)courseModel.dislikedNum];
    if (!courseModel.lastChapterSeq&&!courseModel.lastSectionSeq) {
        self.subTitleLabel.text = [NSString stringWithFormat:@"还没有学过任何章节"];
    } else {
        // 观看记录
        if (courseModel.type == HDCouseListTypeCourse) {
          self.subTitleLabel.text = [NSString stringWithFormat:@"上次观看至%@.%@",conversionstring(courseModel.lastChapterSeq),conversionstring(courseModel.lastSectionSeq)];
        } else if (courseModel.type == HDCouseListTypePaper) {
            self.subTitleLabel.text = [NSString stringWithFormat:@"观看至%@", courseModel.last_section_name];
        }
    }
 
    [self setSubviewsLayout];
}

-(void)setSubviewsLayout
{
    WS(ws);
//     HDCourseModel *courseModel = self.cellData;
    
    [self.moocImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.contentView.mas_centerY).offset(-1);
        make.left.equalTo(ws.contentView).offset(15);
        make.width.equalTo(@(120));
        make.height.equalTo(@(120));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.moocImageView.mas_top).offset(0);
        make.left.equalTo(ws.moocImageView.mas_right).offset(15);
        make.right.equalTo(ws.contentView).offset(-15);
    }];

    [self.subTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.titleLabel.mas_bottom).offset(29.5);
        make.left.equalTo(ws.moocImageView.mas_right).offset(15);
        make.right.equalTo(ws.contentView).offset(-40);
        make.height.equalTo(@(21));
    }];
    [self.videoImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.contentView).offset(-15);
        make.left.equalTo(ws.moocImageView.mas_right).offset(15);
       
    }];

    [self.learnNumLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.videoImageView.mas_centerY);
        make.left.equalTo(ws.videoImageView.mas_right).offset(3);
        
    }];
    [self.upImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.videoImageView);
        make.left.equalTo(ws.videoImageView.mas_right).offset(40);
        
    }];
    [self.upLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.upImageView.mas_centerY);
        make.left.equalTo(ws.upImageView.mas_right).offset(3);
        
    }];
    [self.downImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.videoImageView).offset(3);
        make.left.equalTo(ws.upImageView.mas_right).offset(40);
        
    }];
    [self.downLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(ws.upLabel.mas_centerY);
        make.left.equalTo(ws.downImageView.mas_right).offset(3);
        
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.contentView.mas_bottom);
        make.width.equalTo(@(APP_SCREEN_WIDTH));
        make.height.equalTo(@(3));
    }];
}

+(float)fixedHeight
{
    return 152;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
}


@end
