//
//  MCMainCell.h
//
//  Created by nobody on 14-2-24.
//  . All rights reserved.
//

#import "HDTableViewCell.h"

/**
 *  课程列表cell
 */
@interface HDMainCell : HDTableViewCell

+(float)fixedHeight;

@end
