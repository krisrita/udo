//
//  HDMainViewController.h
//  udo_stu
//
//  Created by nobody on 15/5/31.
//  All rights reserved.
//

#import "HDBaseViewController.h"
#import "HDAreaViewController.h"

/**
 *  某一个学校的课程列表
 */
@interface HDMainViewController : HDBaseViewController

@property (nonatomic, strong) HDSchoolModel *schoolModel;

@end
