//
//  HDBaseInfoAlertView.h
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPersonCenterViewController;

typedef enum baseButtonType
{
    baseSureType = 0,
    baseDissmissType,
    
}_baseButtonType;

typedef enum baseSex
{
    sexNan = 0,
    sexNv,
    
}_baseSex;

@protocol AlertDelegate <NSObject>

- (void)ClickIndex:(NSUInteger)index withText:(NSString *)text sex:(HDGender)sex;

@end

@interface HDBaseInfoAlertView : UIView

@property(nonatomic,weak)id<AlertDelegate> delegate;

- (id)initWithFrame:(CGRect)frame withRootVC:(HDPersonCenterViewController *)VC;

- (void)show;
- (void)dismiss;

@end
