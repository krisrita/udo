//
//  HDAlertView.m
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDAlertView.h"
#import "HDPersonCenterViewController.h"
#import "HDRegularClass.h"

@interface HDAlertView ()
<
UITextFieldDelegate,
UIAlertViewDelegate
>

@property (nonatomic, strong) UILabel *titleLal; // 标题
@property (nonatomic, strong) UIView *CusShowView;      // 自定义的白色显示区域
@property (nonatomic, strong) UIView *bgview;           // 黑色透明背景
@property (nonatomic, strong) UIButton *ensureButton;  // 确定按钮
@property (nonatomic, strong) UIButton *cancleButton;  // 取消按钮
@property (nonatomic, strong) UITextField *nameTextView; // 输入框

@end

@implementation HDAlertView

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (id)initWithFrame:(CGRect)frame withRootVC:(HDPersonCenterViewController *)VC defaultStr:(NSString *)defaultStr
{
    self = [super initWithFrame:[UIScreen mainScreen].bounds];
    
    if (self)
    {
        self.frame = [UIScreen mainScreen].bounds;
        
        self.userInteractionEnabled = YES;
                
        [VC.view addSubview:self];

        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT)];
        bgView.backgroundColor = [UIColor blackColor];
        bgView.userInteractionEnabled = YES;
        bgView.alpha = .6;
        [self addSubview:bgView];
        
        _CusShowView = [[UIView alloc]init];
        _CusShowView.frame = CGRectMake( 30, 165, APP_CONTENT_WIDTH-60, 150);
        [_CusShowView setBackgroundColor:[UIColor whiteColor]];
        _CusShowView.layer.borderWidth = 1;
        _CusShowView.layer.cornerRadius = 6;
        _CusShowView.layer.borderColor = [UIColor clearColor].CGColor;
        _CusShowView.userInteractionEnabled = YES;
        [self addSubview:_CusShowView];
        
        _titleLal = [[UILabel alloc] initWithFrame:CGRectMake( 0, 20, _CusShowView.frame.size.width, 20 )];
        _titleLal.text = @"个性签名";
        _titleLal.textColor = [UIColor blackColor];
        _titleLal.textAlignment = NSTextAlignmentCenter;
        _titleLal.font = [UIFont boldSystemFontOfSize:17];
        _titleLal.backgroundColor = [UIColor clearColor];
        [_CusShowView addSubview:_titleLal];
        
        [self initNessaryView:defaultStr];
    }
    
    return self;
}

-(void)initNessaryView:(NSString *)str
{
    UIView * nameTextBianKuang = [[UIView alloc] initWithFrame:CGRectMake( 20-5
                                                                        , _titleLal.frame.size.height+_titleLal.frame.origin.y+20
                                                                        , _CusShowView.frame.size.width-40+10
                                                                        , 32 )];
    nameTextBianKuang.userInteractionEnabled = YES;
    nameTextBianKuang.layer.borderWidth      = 0.5;
    nameTextBianKuang.layer.cornerRadius     = 2;
    nameTextBianKuang.layer.borderColor      = [UIColor grayColor].CGColor;
    [_CusShowView addSubview:nameTextBianKuang];
    
    _nameTextView = [[UITextField alloc] init];
    [_nameTextView setFrame:CGRectMake( 30-5, _titleLal.frame.size.height+_titleLal.frame.origin.y+20, _CusShowView.frame.size.width-50+10, 32 )];
    [_nameTextView setBackgroundColor:[UIColor clearColor]];
    [_nameTextView setFont:[UIFont systemFontOfSize:14]];
    [_nameTextView setPlaceholder:@"签名（字数不大于20）"];
    [_nameTextView setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [_nameTextView setDelegate:self];
    _nameTextView.text = str;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textFieldChange) name:UITextFieldTextDidChangeNotification object:nil];

    [_CusShowView addSubview:_nameTextView];
    
    _cancleButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _cancleButton.frame = CGRectMake( 0, _CusShowView.frame.size.height-44, _CusShowView.frame.size.width/2, 44 );
    [_cancleButton setTitle:@"取消" forState:UIControlStateNormal];
    [_cancleButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _cancleButton.titleLabel.font = [UIFont systemFontOfSize:17];
    _cancleButton.backgroundColor = [UIColor clearColor];
    _cancleButton.opaque = NO;
    [_CusShowView addSubview:_cancleButton];
    
    _ensureButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _ensureButton.frame = CGRectMake( _CusShowView.frame.size.width/2, _CusShowView.frame.size.height-44, _CusShowView.frame.size.width/2, 44 );
    [_ensureButton setTitle:@"确定" forState:UIControlStateNormal];
    [_ensureButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _ensureButton.titleLabel.font = [UIFont systemFontOfSize:17];
    _ensureButton.backgroundColor = [UIColor clearColor];
    _ensureButton.opaque = NO;
    [_CusShowView addSubview:_ensureButton];
    
    _cancleButton.tag = dissmissType;
    _ensureButton.tag = sureType;
    
    [_ensureButton addTarget:self action:@selector(ButtonPress:) forControlEvents:UIControlEventTouchUpInside];
    [_cancleButton addTarget:self action:@selector(ButtonPress:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *labHeng = [[UILabel alloc] initWithFrame:CGRectMake(0, _cancleButton.frame.origin.y, _CusShowView.frame.size.width, 0.5)];
    labHeng.backgroundColor = [UIColor grayColor];
    [_CusShowView addSubview:labHeng];
    
    UILabel *labShu = [[UILabel alloc] initWithFrame:CGRectMake(_cancleButton.frame.size.width, _cancleButton.frame.origin.y, 0.5, _cancleButton.frame.size.height)];
    labShu.backgroundColor = [UIColor grayColor];
    [_CusShowView addSubview:labShu];
}


-(void)textFieldChange
{
    if (_nameTextView.text.length>20)
    {
        [_nameTextView resignFirstResponder];
        if (_nameTextView.text.length>=20)
        {
            _nameTextView.text=[_nameTextView.text substringToIndex:20];
            [_nameTextView becomeFirstResponder];
        }
    }
}

- (void)ButtonPress:(UIButton *)btn
{
    switch (btn.tag)
    {
        case dissmissType:
            
            [self dismiss];
            
            break;
        case sureType:
            
            [self sureClick];
            
            break;
            
        default:
            break;
    }
}

- (void)sureClick
{
    if (_nameTextView.text && _nameTextView.text.length > 0) {
        if ( self.delegate && [self.delegate respondsToSelector:@selector(ClickIndex:withText:)] )
        {
            [self.delegate ClickIndex:sureType withText:_nameTextView.text];
        }
        
        [self dismiss];
    }
}

#pragma mark 显示 消失 ==== 弹窗

- (void)show
{
    CAKeyframeAnimation * animation;
    animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.1;
    animation.delegate = self;
    animation.removedOnCompletion = YES;
    animation.fillMode = kCAFillModeForwards;
    
    NSMutableArray * values = [NSMutableArray array];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    
    [_CusShowView.layer addAnimation:animation forKey:nil];
}

- (void)dismiss
{
    [_nameTextView resignFirstResponder];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0.0;
        [self removeFromSuperview];
    }];
    
}

@end
