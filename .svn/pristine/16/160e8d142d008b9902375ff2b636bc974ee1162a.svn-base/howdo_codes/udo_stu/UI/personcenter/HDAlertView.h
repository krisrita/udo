//
//  HDAlertView.h
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@class HDPersonCenterViewController;

typedef enum buttonType
{
    sureType = 0,
    dissmissType,
    
}_buttonType;

@protocol CustomerAlertDelegate <NSObject>

- (void)ClickIndex:(NSUInteger)index withText:(NSString *)text;

@end

@interface HDAlertView : UIView

@property(nonatomic,weak)id<CustomerAlertDelegate> delegate;

- (id)initWithFrame:(CGRect)frame withRootVC:(HDPersonCenterViewController *)VC defaultStr:(NSString *)defaultStr;

- (void)show;
- (void)dismiss;

@end
