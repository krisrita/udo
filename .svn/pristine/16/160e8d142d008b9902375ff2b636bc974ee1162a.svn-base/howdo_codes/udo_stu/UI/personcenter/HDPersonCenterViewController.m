
//
//  HDPersonCenterViewController.m
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDPersonCenterViewController.h"
#import "HDAlertView.h"
#import "HDBaseInfoAlertView.h"
#import "HDAreaViewController.h"
#import "HDChangePhoneNumberViewController.h"
#import "HDGenderImageView.h"
#import "UIImage+Alpha.h"
#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

@interface HDPersonCenterViewController ()<AlertDelegate,CustomerAlertDelegate,UIActionSheetDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate>

{
    UIImageView *viewTop; // 最上边那块大的带背景色和头像的地方
    UILabel *labGeXing;   // 个性签名
    UILabel *labArea;     // 地区
    UILabel *labPhone;    // 电话
}

@property (nonatomic,strong) UIButton *nickNameBtn;
@property (nonatomic,strong) HDGenderImageView *imagVSex;
@property (nonatomic,copy) NSString *strGernel;
@property (nonatomic,copy) NSString *strArea;
@property (nonatomic,copy) NSString *strPhone;
@property (nonatomic,strong)HDImageView *headImageView;

@end

@implementation HDPersonCenterViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    

    self.view.backgroundColor = RGBColor(230, 231, 233);
    
    [self initNesseryViews];
    self.headView.hidden = YES;
    UIButton * leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    [leftBtn setImage:[UIImage imageNamed:@"btn_close"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(leftMenu:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:leftBtn];

    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setVauleModelUser:[[HDManager sharedInstance]currentUser]];
    ((MLNavigationController *)self.navigationController).canDragBack = YES;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [HDLoading stopAnimating];
}
-(void)leftMenu:(UIButton *)sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:NULL];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)initNesseryViews
{
    HDUserModel * currentUer = [[HDManager sharedInstance]currentUser];
    
    viewTop = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, 532/2)];
    viewTop.backgroundColor = [UIColor colorWithRed:30.0/255.0 green:177.0/255.0 blue:138.0/255.0 alpha:1.0];
    viewTop.userInteractionEnabled = YES;
    [self.view addSubview:viewTop];
    
    _headImageView = [[HDImageView alloc] initWithFrame:CGRectMake((APP_CONTENT_WIDTH - 273/2.0)/2, 173/2.0,273/2.0, 273/2.0)];
    _headImageView.backgroundColor = [UIColor clearColor];
    [_headImageView addTarget:self action:@selector(headImageViewClicked)];
    [viewTop addSubview:_headImageView];
    _headImageView.layer.cornerRadius = _headImageView.frame.size.height/2;
    _headImageView.clipsToBounds = YES;
    
    _nickNameBtn = [[UIButton alloc] initWithFrame:CGRectMake(15, viewTop.frame.size.height-22, 100, 16)];
    _nickNameBtn.backgroundColor = [UIColor clearColor];
    _nickNameBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    _nickNameBtn.titleLabel.textColor = [UIColor whiteColor];
    [viewTop addSubview:_nickNameBtn];
    [_nickNameBtn addTarget:self action:@selector(changeUserInfo:) forControlEvents:UIControlEventTouchUpInside];
    
    self.imagVSex = [[HDGenderImageView alloc]initWithCGPoint:CGPointMake(CGRectGetMaxX(_nickNameBtn.frame) + 10,
                                                           CGRectGetMinY(_nickNameBtn.frame) -5) WithGender:currentUer.gender];
    
    [viewTop addSubview:self.imagVSex];
    [self.imagVSex addTarget:self action:@selector(changeUserInfo:) forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView *imgVGeXing = [[UIImageView alloc] initWithFrame:CGRectMake(13, viewTop.frame.size.height+viewTop.frame.origin.y+14, APP_CONTENT_WIDTH-26, 45)];
    imgVGeXing.image = [UIImage imageNamed:@"beijingkuang"];
    imgVGeXing.userInteractionEnabled = YES;
    [self.view addSubview:imgVGeXing];
    
    
    labGeXing = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, imgVGeXing.frame.size.width-55, imgVGeXing.frame.size.height)];
    labGeXing.textColor = RGBColor(117, 117, 117);
    labGeXing.backgroundColor = [UIColor clearColor];
    labGeXing.font = [UIFont systemFontOfSize:14];
    labGeXing.userInteractionEnabled = YES;
    [imgVGeXing addSubview:labGeXing];
    
    UIImageView *imgVYou3 = [[UIImageView alloc] initWithFrame:CGRectMake(imgVGeXing.frame.size.width-15-8, 15, 8, 14)];
    imgVYou3.image = [UIImage imageNamed:@"arrow---right"];
    [imgVGeXing addSubview:imgVYou3];
    
    UIImageView *imgVPhone = [[UIImageView alloc] initWithFrame:CGRectMake(13,
                                                                           imgVGeXing.frame.size.height+imgVGeXing.frame.origin.y+14,
                                                                           APP_CONTENT_WIDTH-26,
                                                                           90)];
    imgVPhone.image = [UIImage imageNamed:@"beijingkuang"];
    imgVPhone.userInteractionEnabled = YES;
    [self.view addSubview:imgVPhone];
    
    UILabel *labLine = [[UILabel alloc] initWithFrame:CGRectMake(13, 45, imgVGeXing.frame.size.width-26, 0.5)];
    labLine.backgroundColor = RGBColor(169, 169, 169);
    [imgVPhone addSubview:labLine];
    
    UIImageView *imgVSchool = [[UIImageView alloc] initWithFrame:CGRectMake(13, 15, 17, 14)];
    imgVSchool.image = [UIImage imageNamed:@"school"];
    imgVSchool.userInteractionEnabled = YES;
    [imgVPhone addSubview:imgVSchool];
    
    labArea = [[UILabel alloc] initWithFrame:CGRectMake(imgVSchool.frame.size.width+imgVSchool.frame.origin.x+13,
                                                        0,
                                                        imgVGeXing.frame.size.width-55,
                                                        imgVGeXing.frame.size.height)];
    labArea.textColor = RGBColor(117, 117, 117);
    labArea.backgroundColor = [UIColor clearColor];
    labArea.font = [UIFont systemFontOfSize:14];
    labArea.userInteractionEnabled = YES;
    [imgVPhone addSubview:labArea];
    
    UIImageView *imgVYou = [[UIImageView alloc] initWithFrame:CGRectMake(imgVPhone.frame.size.width-15-8, 15, 8, 14)];
    imgVYou.image = [UIImage imageNamed:@"arrow---right"];
    [imgVPhone addSubview:imgVYou];
    
    UIImageView *imgvDianHua = [[UIImageView alloc] initWithFrame:CGRectMake(13, 15+45, 17, 14)];
    imgvDianHua.image = [UIImage imageNamed:@"dianhuat"];
    imgvDianHua.userInteractionEnabled = YES;
    [imgVPhone addSubview:imgvDianHua];
    
    labPhone = [[UILabel alloc] initWithFrame:CGRectMake(imgvDianHua.frame.size.width+imgvDianHua.frame.origin.x+13,
                                                        45,
                                                        imgVGeXing.frame.size.width-55,
                                                        imgVGeXing.frame.size.height)];
    labPhone.textColor = RGBColor(117, 117, 117);
    labPhone.backgroundColor = [UIColor clearColor];
    labPhone.font = [UIFont systemFontOfSize:14];
    labPhone.userInteractionEnabled = YES;
    [imgVPhone addSubview:labPhone];
    
    UIImageView *imgVYou2 = [[UIImageView alloc] initWithFrame:CGRectMake(imgVPhone.frame.size.width-15-8, 15+45, 8, 14)];
    imgVYou2.image = [UIImage imageNamed:@"arrow---right"];
    [imgVPhone addSubview:imgVYou2];
    
    UIButton * btnGexingClick = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, imgVGeXing.frame.size.width, imgVGeXing.frame.size.height)];
    btnGexingClick.backgroundColor = [UIColor clearColor];
    [imgVGeXing addSubview:btnGexingClick];
    
    UIButton * btnDiQuClick = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, imgVPhone.frame.size.width, imgVPhone.frame.size.height/2)];
    btnDiQuClick.backgroundColor = [UIColor clearColor];
    [imgVPhone addSubview:btnDiQuClick];
    
    UIButton * btnDianHClick = [[UIButton alloc] initWithFrame:CGRectMake(0, 45, imgVPhone.frame.size.width, imgVPhone.frame.size.height/2)];
    btnDianHClick.backgroundColor = [UIColor clearColor];
    [imgVPhone addSubview:btnDianHClick];
    
    btnGexingClick.tag = 1;
    btnDiQuClick.tag = 2;
    btnDianHClick.tag = 3;
    
    [btnGexingClick addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
    [btnDiQuClick addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
    [btnDianHClick addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
}
-(void)changeUserInfo:(UIButton *)btn
{
    HDBaseInfoAlertView *alertBase = [[HDBaseInfoAlertView alloc] initWithFrame:[UIScreen mainScreen].bounds withRootVC:self];
    
    alertBase.delegate = self;
    [alertBase show];

}

- (void)clickBtn:(UIButton *)btn
{
    switch (btn.tag)
    {
        case 1:
            [self clickGeXing];
            break;
       
        case 2:
            [self clickDiQu];
            break;
       
        case 3:
            [self clickDianH];
            break;

        default:
            break;
    }
}

- (void)clickGeXing
{
    NSLog(@"个性");
    HDAlertView *alertGexing = [[HDAlertView alloc] initWithFrame:[UIScreen mainScreen].bounds withRootVC:self defaultStr:_modelUser.signature];
    alertGexing.delegate = self;
    [alertGexing show];
}

- (void)clickDiQu
{
    MyLog(@"地区");
    HDAreaViewController * area = [[HDAreaViewController alloc]init];
    backBtnHave = YES;
    [self.navigationController pushViewController:area animated:YES];
    
}

- (void)clickDianH
{
    MyLog(@"修改手机号,电话");
    HDChangePhoneNumberViewController * changePhone = [[HDChangePhoneNumberViewController alloc]init];
    [self.navigationController pushViewController:changePhone animated:YES];

}

- (void)UIImageView:(id)sender
{
    
    
}

- (void)headImageViewClicked
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"更改头像" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"打开相册", @"拍照", nil];
    [actionSheet showInView:self.view];
}
#pragma mark - UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0: {
            //打开相册
            UIImagePickerController *picker = [[UIImagePickerController alloc] init];
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate = self;
            //设置选择后的图片可被编辑
            picker.allowsEditing = YES;
            [self presentViewController:picker animated:YES completion:nil];
        }
            break;
        case 1: {
            //手机拍照
            UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
                UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                picker.delegate = self;
                //设置拍照后的图片可被编辑
                picker.allowsEditing = YES;
                picker.sourceType = sourceType;
                [self presentViewController:picker animated:YES completion:nil];
            } else {
                //模拟器没有
            }
        }
            break;
            
        default:
            break;

        }
}
#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    UIImage *newImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    UIImage *resizeImage = [newImage imageEqualRatioScaledToSize:CGSizeMake(370, 370)];
    [self savaClicked:resizeImage];
    [picker dismissViewControllerAnimated:YES completion:nil];
        
        
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)savaClicked:(UIImage *)image
{
    [self.view setUserInteractionEnabled:NO];
    NSData *imageData = UIImageJPEGRepresentation(image, 0.5);
    NSLog(@"%ld",(long)[HDManager sharedInstance].currentUser.Id);
    HDUserModel * model = [[HDManager sharedInstance]currentUser];
    
    [HDLoading startAnimating];
    [[HDManager sharedInstance].userService changeHeadImage:[HDManager sharedInstance].currentUser.Id imageData:imageData resultBack:^(HDServiceResult *result, id object) {
        if (result.resultCode == HD_RESULT_CODE_SUCCESS)
        {
            if (object && [object isKindOfClass:[NSString class]]) {
                HDHeadImageUrl * url = [HDHeadImageUrl imageUrlWithName:object];
                model.imageUrl = url;
                [[HDManager sharedInstance]setCurrentUser:model];
                [self setVauleModelUser:model];
            }
        }
        else{
            [HDTip showMessage:@"头像修改失败" inView:self.view];
        }
        [self.view setUserInteractionEnabled:YES];
        [HDLoading stopAnimating];
    }];
}

- (void)setVauleModelUser:(HDUserModel *)modelUser
{
    if (!modelUser) return;

    _modelUser = modelUser;
    
    [_headImageView setHDImageURL:[NSURL URLWithString:[modelUser.imageUrl medium]]placeholderImage:[UIImage imageNamed:@"btn_personal_head.png"] imageType:HD_IMAGE_CIRCLE];
    
    NSString * nickName = nil;
    if (modelUser.nickname && [modelUser.nickname isKindOfClass:[NSString class]] && modelUser.nickname.length > 0)
    {
        nickName = modelUser.nickname;
    }
    else
    {
        nickName = @"用户名";
    }
    CGSize sizeName = [nickName sizeWithFont:[UIFont systemFontOfSize:14]
                                           constrainedToSize:CGSizeMake(MAXFLOAT, 16)
                                               lineBreakMode:NSLineBreakByCharWrapping];
    _nickNameBtn.frame = CGRectMake(_nickNameBtn.frame.origin.x, _nickNameBtn.frame.origin.y, sizeName.width, 16);
    [_nickNameBtn setTitle:nickName forState:UIControlStateNormal];
    
    self.imagVSex.frame = CGRectMake(CGRectGetMaxX(_nickNameBtn.frame) + 6,
                              self.imagVSex.frame.origin.y,
                              self.imagVSex.frame.size.width,
                              self.imagVSex.frame.size.height);
    
    [self.imagVSex setGender:modelUser.gender];
    
    NSString *signatureStr = [NSString stringWithFormat:@"个性签名 ：%@", modelUser.signature ? modelUser.signature : @""];
    if ([modelUser.signature isKindOfClass:[NSString class]])
    {
        signatureStr = (modelUser.signature && modelUser.signature.length > 0) ? signatureStr : @"个性签名 ：这个人很懒，什么也没有写！";
    }
    labGeXing.text = signatureStr ;
    
    NSString *areaStr = [NSString stringWithFormat:@"%@ %@ %@",modelUser.proName?modelUser.proName:@"",modelUser.cityName?modelUser.cityName:@"",modelUser.regionName?modelUser.regionName:@""];
    areaStr = areaStr.length > 0?areaStr:@"未知区域";
    labArea.text = areaStr ;
    
    NSInteger phone = modelUser.mobilephone;
    if (phone > 0) {
        labPhone.text = [NSString stringWithFormat:@"%ld",(long)phone] ;
    }
}


#pragma mark ********** delegate ************

- (void)ClickIndex:(NSUInteger)index withText:(NSString *)text
{

    [[[HDManager sharedInstance]userService] changeSignature:[[[HDManager sharedInstance] currentUser] Id] signature:text resultBack:^(HDServiceResult *result, id object) {
        [HDTip showMessage:result.resultDesc];
        if (result.resultCode == HD_RESULT_CODE_SUCCESS)
        {
            HDUserModel * model =  [[HDManager sharedInstance]currentUser];
            model.signature = text;
            [[HDManager sharedInstance]setCurrentUser:model];
            [self setVauleModelUser:model];
        }
    }];
    
}

- (void)ClickIndex:(NSUInteger)index withText:(NSString *)text sex:(HDGender)sex
{
    HDUserModel * user = [[HDManager sharedInstance]currentUser];

    if (![[[[HDManager sharedInstance] currentUser] nickname] isEqualToString:text])
    {
        [[[HDManager sharedInstance]userService]changeNickname:user.Id nickname:text resultBack:^(HDServiceResult *result, id object) {
            if (result.resultCode == HD_RESULT_CODE_SUCCESS)
            {
                user.nickname = text;
                [[HDManager sharedInstance]setCurrentUser:user];
            }
            [result show];
            [self setVauleModelUser:user];
        }];
    }
    
    if (user.gender != sex)
    {
        [[[HDManager sharedInstance]userService]changeGender:user.Id gender:sex resultBack:^(HDServiceResult *result, id object) {
            if (result.resultCode == HD_RESULT_CODE_SUCCESS)
            {
                user.gender = sex;
                [[HDManager sharedInstance]setCurrentUser:user];
            }

            [result show];
            [self setVauleModelUser:user];
        }];
    }
    
    
}

@end
