//
//  HDPersonCenterViewController.h
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HDUserModel.h"

@interface HDPersonCenterViewController : HDBaseViewController

@property (nonatomic,strong)HDUserModel *modelUser;

@end
