


//
//  HDBaseInfoAlertView.m
//  udo_stu
//
//  Created by nobody on 15/6/14.
//  All rights reserved.
//

#import "HDBaseInfoAlertView.h"
#import "HDPersonCenterViewController.h"
#import "HDRegularClass.h"
@interface HDBaseInfoAlertView ()
<
UITextFieldDelegate,
UIAlertViewDelegate
>

{
    UIButton *btnNan;
    UIButton *btnNv;
}

@property (nonatomic, strong) UILabel *titleLal; // 标题

@property (nonatomic, assign) HDGender sex; // 性别

@property (nonatomic, strong) UIView *CusShowView;      // 自定义的白色显示区域
@property (nonatomic, strong) UIView *bgview;           // 黑色透明背景
@property (nonatomic, strong) UIButton *ensureButton;  // 确定按钮
@property (nonatomic, strong) UIButton *cancleButton;  // 取消按钮
@property (nonatomic, strong) UITextField *nameTextView; // 输入框

@end

@implementation HDBaseInfoAlertView

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [self.layer removeAllAnimations];
}

- (id)initWithFrame:(CGRect)frame withRootVC:(HDPersonCenterViewController *)VC
{
    self = [super initWithFrame:[UIScreen mainScreen].bounds];
    
    if (self)
    {
        self.frame = [UIScreen mainScreen].bounds;
        
//        // 加载window上
        UIWindow * newWindow = [UIApplication sharedApplication].keyWindow;
//        if ( !newWindow )
//        {
//            newWindow = [[UIApplication sharedApplication].windows objectAtIndex:0];
//        }
        [newWindow addSubview:self];
        
//        [VC.view addSubview:self];
        
        // 黑色背景
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT)];
        bgView.backgroundColor = [UIColor blackColor];
        bgView.alpha = .6;
        bgView.userInteractionEnabled = YES;
        [self addSubview:bgView];
        
        //显示区域
        _CusShowView = [[UIView alloc]init];
        _CusShowView.frame = CGRectMake( 30, 165, APP_CONTENT_WIDTH-60, 212);
        [_CusShowView setBackgroundColor:[UIColor whiteColor]];
        _CusShowView.layer.borderWidth = 1;
        _CusShowView.layer.cornerRadius = 6;
        _CusShowView.layer.borderColor = [UIColor clearColor].CGColor;
        _CusShowView.userInteractionEnabled = YES;
        [self addSubview:_CusShowView];
        
        //标题
        _titleLal = [[UILabel alloc] initWithFrame:CGRectMake( 0, 20, _CusShowView.frame.size.width, 20 )];
        _titleLal.text = @"基本信息";
        _titleLal.textColor = [UIColor blackColor];
        _titleLal.textAlignment = NSTextAlignmentCenter;
        _titleLal.font = [UIFont boldSystemFontOfSize:17];
        _titleLal.backgroundColor = [UIColor clearColor];
        [_CusShowView addSubview:_titleLal];
        
        // 初始化重要组件 (输入框 确定、取消按钮)
        [self initNessaryView];
        
    }
    
    return self;
}

-(void)initNessaryView
{
    // 标签
    UILabel *labName = [[UILabel alloc] initWithFrame:CGRectMake(0,
                                                                 _titleLal.frame.size.height+_titleLal.frame.origin.y+25,
                                                                 68,
                                                                 20)];
    labName.text = @"姓名 ：";
    labName.textColor = [UIColor blackColor];
    labName.font = [UIFont systemFontOfSize:14];
    labName.textAlignment = NSTextAlignmentRight;
    [_CusShowView addSubview:labName];
    
    // 输入框边框
    UIView * nameTextBianKuang = [[UIView alloc] initWithFrame:CGRectMake( 20-5+50
                                                                          , _titleLal.frame.size.height+_titleLal.frame.origin.y+20+32
                                                                          , _CusShowView.frame.size.width-40+10-50
                                                                          , 0.5 )];
    nameTextBianKuang.userInteractionEnabled = YES;
    nameTextBianKuang.backgroundColor = [UIColor grayColor];
    [_CusShowView addSubview:nameTextBianKuang];
    
    // 输入框
    _nameTextView = [[UITextField alloc] init];
    [_nameTextView setFrame:CGRectMake( 30-5+50,
                                       _titleLal.frame.size.height+_titleLal.frame.origin.y+20,
                                       _CusShowView.frame.size.width-100+10,
                                       32 )];
    [_nameTextView setBackgroundColor:[UIColor clearColor]];
    [_nameTextView setReturnKeyType:UIReturnKeyDone];
    [_nameTextView setFont:[UIFont systemFontOfSize:14]];
    [_nameTextView setPlaceholder:@"昵称（字数不大于6）"];
    _nameTextView.delegate = self;
    [_nameTextView setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [_nameTextView setDelegate:self];
    [_CusShowView addSubview:_nameTextView];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textFieldChange) name:UITextFieldTextDidChangeNotification object:nil];

    
    // 性别
    UILabel *labSex = [[UILabel alloc] initWithFrame:CGRectMake(0,
                                                                _nameTextView.frame.size.height+_nameTextView.frame.origin.y+23,
                                                                68,
                                                                20)];
    labSex.text = @"性别 ：";
    labSex.textColor = [UIColor blackColor];
    labSex.font = [UIFont systemFontOfSize:14];
    labSex.textAlignment = NSTextAlignmentRight;
    [_CusShowView addSubview:labSex];
    
    // 男
    btnNan = [[UIButton alloc] initWithFrame:CGRectMake(labSex.frame.origin.x+labSex.frame.size.width+20,
                                                                  _nameTextView.frame.size.height+_nameTextView.frame.origin.y+10,
                                                                  49,
                                                                  49)];
    [btnNan setImage:[UIImage imageNamed:@"xiaonan.png"] forState:UIControlStateNormal];
    btnNan.backgroundColor = [UIColor clearColor];
    [_CusShowView addSubview:btnNan];
    
    
    // 女
    btnNv = [[UIButton alloc] initWithFrame:CGRectMake(labSex.frame.origin.x+labSex.frame.size.width+100,
                                                                  _nameTextView.frame.size.height+_nameTextView.frame.origin.y+10,
                                                                  49,
                                                                  49)];
    [btnNv setImage:[UIImage imageNamed:@"xiaonv.png"] forState:UIControlStateNormal];
    btnNv.backgroundColor = [UIColor clearColor];
    [_CusShowView addSubview:btnNv];
    
    
    [btnNan addTarget:self action:@selector(btnsexClick:) forControlEvents:UIControlEventTouchUpInside];
    [btnNv addTarget:self action:@selector(btnsexClick:) forControlEvents:UIControlEventTouchUpInside];
    
    // 取消按钮
    _cancleButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _cancleButton.frame = CGRectMake( 0,
                                     _CusShowView.frame.size.height-44,
                                     _CusShowView.frame.size.width/2,
                                     44 );
    [_cancleButton setTitle:@"取消" forState:UIControlStateNormal];
    [_cancleButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _cancleButton.titleLabel.font = [UIFont systemFontOfSize:17];
    _cancleButton.backgroundColor = [UIColor clearColor];
    _cancleButton.opaque = NO;
    [_CusShowView addSubview:_cancleButton];
    
    // 确定按钮
    _ensureButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _ensureButton.frame = CGRectMake( _CusShowView.frame.size.width/2, _CusShowView.frame.size.height-44, _CusShowView.frame.size.width/2, 44 );
    [_ensureButton setTitle:@"确定" forState:UIControlStateNormal];
    [_ensureButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _ensureButton.titleLabel.font = [UIFont systemFontOfSize:17];
    _ensureButton.backgroundColor = [UIColor clearColor];
    _ensureButton.opaque = NO;
    [_CusShowView addSubview:_ensureButton];
    
    // type类型
    _cancleButton.tag = baseDissmissType;
    _ensureButton.tag = baseSureType;
    
    // 点击事件
    [_ensureButton addTarget:self action:@selector(ButtonPress:) forControlEvents:UIControlEventTouchUpInside];
    [_cancleButton addTarget:self action:@selector(ButtonPress:) forControlEvents:UIControlEventTouchUpInside];
    
    // 分割线
    UILabel *labHeng = [[UILabel alloc] initWithFrame:CGRectMake(0, _cancleButton.frame.origin.y, _CusShowView.frame.size.width, 0.5)];
    labHeng.backgroundColor = [UIColor grayColor];
    [_CusShowView addSubview:labHeng];
    
    UILabel *labShu = [[UILabel alloc] initWithFrame:CGRectMake(_cancleButton.frame.size.width, _cancleButton.frame.origin.y, 0.5, _cancleButton.frame.size.height)];
    labShu.backgroundColor = [UIColor grayColor];
    [_CusShowView addSubview:labShu];
    [self setUserModel:[[HDManager sharedInstance] currentUser]];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.3 animations:^{
        
        _CusShowView.frame = CGRectMake(_CusShowView.frame.origin.x, 165 - 80, _CusShowView.frame.size.width, _CusShowView.frame.size.height);
    }];

    return YES;
}

-(void)textFieldChange
{
    NSInteger kMaxLength = 6;
    UITextField *textField = _nameTextView;
    NSString *toBeString = textField.text;
    NSString *lang = [[UITextInputMode currentInputMode] primaryLanguage];
    if ([lang isEqualToString:@"zh-Hans"]) {
        UITextRange *selectedRange = [textField markedTextRange];
        UITextPosition *position = [textField positionFromPosition:selectedRange.start offset:0];
        if (!position) {
            if (toBeString.length > kMaxLength) {
                textField.text = [toBeString substringToIndex:kMaxLength];
            }
        }
        else{
            
        }
    }
    else{
        if (toBeString.length > kMaxLength) {
            textField.text = [toBeString substringToIndex:kMaxLength];
        }
    }
}


-(void)setUserModel:(HDUserModel *)model
{
    if (model.nickname && [model.nickname isKindOfClass:[NSString class]] && model.nickname.length > 0) {
        _nameTextView.text = model.nickname;
    }
    _nameTextView.text = model.nickname;
    
    [self setGender:model.gender];
}

-(void)setGender:(HDGender)gender
{
    if (gender == HD_GENDER_UNKNOWN)
    {
        btnNan.alpha = .2;
        btnNv.alpha = .2;
    }
    else if (gender == HD_GENDER_FEMALE)
    {
        btnNv.alpha = 1;
        btnNan.alpha = .2;
    }else if (gender == HD_GENDER_MALE)
    {
        btnNan.alpha = 1;
        btnNv.alpha = .2;
    }
    _sex = gender;
}

- (void)btnsexClick:(UIButton *)btn
{

    if ([btn isEqual:btnNan])
    {
        _sex = HD_GENDER_MALE;
    }
    else
    {
        _sex = HD_GENDER_FEMALE;
    }
    [self setGender:_sex];
}

- (void)ButtonPress:(UIButton *)btn
{
    switch (btn.tag)
    {
        case baseDissmissType:// 弹窗消失
            
            [self dismiss];
            
            break;
        case baseSureType://预约
            
            [self sureClick];
            
            break;
            
        default:
            break;
    }
}

- (void)sureClick
{
    if ([HDRegularClass checkOutNickName:_nameTextView.text] && _nameTextView.text.length > 0 && _nameTextView.text.length < 7)
    {
        if ( self.delegate && [self.delegate respondsToSelector:@selector(ClickIndex:withText:sex:)] )
        {
            [self.delegate ClickIndex:baseSureType withText:_nameTextView.text sex:_sex];
        }
        [self dismiss];
  
    }
    else
    {
        [self.nameTextView resignFirstResponder];
        [HDTip showMessage:@"昵称为2-16位中英文、数字及下划线" complete:^{
            [self.nameTextView becomeFirstResponder];
        }];

    }
}

#pragma mark 显示 消失 ==== 弹窗

/// 显示
- (void)show
{
    CAKeyframeAnimation * animation;
    animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.1;
    animation.delegate = self;
    animation.removedOnCompletion = YES;
    animation.fillMode = kCAFillModeForwards;
    
    NSMutableArray * values = [NSMutableArray array];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    
    [_CusShowView.layer addAnimation:animation forKey:nil];
}

/// 消失
- (void)dismiss
{
    [_nameTextView resignFirstResponder];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0.0;
        [self removeFromSuperview];
    }];
    
}

@end

