//
//  HDGenderImageView.h
//  udo_stu
//
//  Created by kaola on 15/6/21.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDGenderImageView : UIButton

-(id)initWithCGPoint:(CGPoint)point WithGender:(HDGender)gender;

-(void)setGender:(HDGender)gender;


@end
