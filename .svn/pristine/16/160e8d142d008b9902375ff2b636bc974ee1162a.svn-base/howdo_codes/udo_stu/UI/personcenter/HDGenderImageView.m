//
//  HDGenderImageView.m
//  udo_stu
//
//  Created by kaola on 15/6/21.
//  All rights reserved.
//

#import "HDGenderImageView.h"

@implementation HDGenderImageView

-(id)initWithCGPoint:(CGPoint)point WithGender:(HDGender)gender
{
    self = [super initWithFrame:CGRectMake(point.x, point.y, 24, 24)];
    if (self)
    {
        [self setGender:gender];

    }
    return self;
}

-(void)setGender:(HDGender)gender
{
    if (gender == HD_GENDER_UNKNOWN)
    {
        [self setImage: nil forState:UIControlStateNormal];

    }
    else if (gender == HD_GENDER_FEMALE)
    {
        [self setImage: [UIImage imageNamed:@"xiaonv.png"] forState:UIControlStateNormal];
    }
    else if (gender == HD_GENDER_MALE)
    {
        [self setImage:[UIImage imageNamed:@"xiaonan.png"] forState:UIControlStateNormal];
    }
}

@end
