//
//  AppDelegate.h
//  udo_stu
//
//  Created by nobody on 15/5/28.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

