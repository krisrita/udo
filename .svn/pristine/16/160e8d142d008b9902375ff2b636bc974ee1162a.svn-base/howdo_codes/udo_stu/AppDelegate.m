//
//  AppDelegate.m
//  udo_stu
//
//  Created by nobody on 15/5/28.
//  All rights reserved.
//

#import "AppDelegate.h"
#import "MLNavigationController.h"
#import "HDMainViewController.h"
#import "HDMenuViewController.h"
#import "PPRevealSideViewController.h"
#import "HDGuideViewController.h"
#import "HDLoginProxy.h"
#import "HDGuideViewController.h"
#import "HDSchoolViewController.h"
#import <Fabric/Fabric.h>
#import <Crashlytics/Crashlytics.h>
#import <AFNetworkActivityLogger.h>


@interface AppDelegate ()

@property (nonatomic, strong) PPRevealSideViewController *revealSideViewController;
@property (nonatomic, strong) UIImageView *splashView;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [Fabric with:@[CrashlyticsKit]];
    
#if DEBUG
    [[AFNetworkActivityLogger sharedLogger] startLogging];
#endif

    // Override point for customization after application launch.
    [application setStatusBarStyle:UIStatusBarStyleLightContent];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    self.splashView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, APP_CONTENT_WIDTH, APP_CONTENT_HEIGHT)];
    [self.splashView setImage:[UIImage imageNamed:@"bg_splash.jpg"]];
    [self.window addSubview:self.splashView];
    [self.window makeKeyAndVisible];
    
    [[HDManager sharedInstance] initialize];
    
    [[[NSOperationQueue alloc] init] addOperationWithBlock:^{
        [[HDUpgrade sharedInstance] checkNewVersion:YES];
    }];
    
    [self performSelector:@selector(loadMainViewController) withObject:nil afterDelay:2.0];
    
    return YES;
}

- (void)loadMainViewController
{
    [self.splashView removeFromSuperview];
  
    if ([[HDManager sharedInstance]isLogined])
    {
        [self showMainViewController];
    }
    else
    {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loginSuccess) name:NOTIFICATION_LOGIN_SUCCESS object:nil];
        HDGuideViewController * guide = [[HDGuideViewController alloc]init];
        MLNavigationController * guideNav =[[MLNavigationController alloc]initWithRootViewController: guide];
        guideNav.hidesBottomBarWhenPushed = YES;
        guideNav.navigationBarHidden = YES;
        self.window.rootViewController = guideNav;
    }
}

- (void)showMainViewController
{
    HDSchoolViewController *mainViewController = [[HDSchoolViewController alloc]init];
    MLNavigationController *mainNavigationController = [[MLNavigationController alloc]initWithRootViewController:mainViewController];
    mainNavigationController.navigationBarHidden = YES;
    
    
    self.revealSideViewController =[[PPRevealSideViewController alloc] initWithRootViewController:mainNavigationController];
    [self.revealSideViewController resetOption:PPRevealSideOptionsShowShadows];
    self.revealSideViewController.modalPresentationStyle= UIModalPresentationCurrentContext;
    
    HDMenuViewController *menuViewController = [[HDMenuViewController alloc] init];
    [self.revealSideViewController preloadViewController:menuViewController
                                                 forSide:PPRevealSideDirectionLeft
                                              withOffset:OFFSET];
    
    self.window.rootViewController = self.revealSideViewController;
}

- (void)loginSuccess
{
    [self showMainViewController];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:NOTIFICATION_LOGIN_SUCCESS object:nil];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    
}

- (void)applicationDidEnterBackground:(UIApplication *)application {

}

- (void)applicationWillEnterForeground:(UIApplication *)application {
  
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    
}

- (void)applicationWillTerminate:(UIApplication *)application {

}

@end
