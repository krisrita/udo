//
//  HDManager.m
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import "HDManager.h"
#import "HDNetworkConfig.h"
#import "HDLoginDefine.h"
@interface HDManager ()

@property (nonatomic, assign,readwrite) BOOL isLogined;
@end

@implementation HDManager

+ (instancetype)sharedInstance
{
    static HDManager *instance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

-(void)getLocalUserInfo
{
    NSDictionary * userDic = [[NSUserDefaults standardUserDefaults]objectForKey:HD_LOGINUSER_INFO_KEY];
    if (userDic && [userDic isKindOfClass:[NSDictionary class]])
    {
        HDUserModel * user = [HDUserModel modelWithData:userDic];
        if (user && user.Id > 0)
        {
            self.isLogined = YES;
            self.currentUser = user;
        }
        else
        {
            self.isLogined = NO;
        }
    }
}

-(void)setCurrentUser:(HDUserModel *)currentUser
{
    _currentUser = currentUser;

    NSDictionary * dic =[currentUser toDictionay];
    if (dic)
    {
        [[NSUserDefaults standardUserDefaults]setObject:dic forKey:HD_LOGINUSER_INFO_KEY];
        [[NSUserDefaults standardUserDefaults]synchronize];
        self.isLogined = YES;
    }
    else
    {
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:HD_LOGINUSER_INFO_KEY];
        self.isLogined = NO;
    }
    [[NSNotificationCenter defaultCenter]postNotificationName:NOTIFICATION_CURRENT_USER_INFO_CHANGE object:nil];
}

- (instancetype)init
{
    if (self = [super init]) {
        _userService = [[HDUserService alloc] init];
        _courseService = [[HDCourseService alloc] init];
        _appService = [[HDAppService alloc] init];
    }
    return self;
}

- (void)dealloc
{
  
}

- (BOOL)initialize
{
#ifdef DEBUG
    [HDLog setLogLevel:HDLOG_LEVEL_DEBUG];
#else
    [HDLog setLogLevel:HDLOG_LEVEL_ERROR];
#endif
    
    [[HDNetwork sharedInstance] setConfig:[[HDNetworkConfig alloc] init]];
    
    [self getLocalUserInfo];
    
    [[[NSOperationQueue alloc]init]addOperationWithBlock:^{
        [[HDMonitorNetWork managerForDomain] startMonitoring];
    }];
    
    
    return YES;
}


@end
