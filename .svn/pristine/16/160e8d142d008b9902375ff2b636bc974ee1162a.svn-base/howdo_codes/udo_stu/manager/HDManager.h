//
//  HDManager.h
//  HowDo
//
//  Created by nobody on 15/5/26.
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HDCourseService.h"
#import "HDUserService.h"
#import "HDAppService.h"

@interface HDManager : NSObject

@property (nonatomic, readonly) id<HDCourseSeviceDelegate> courseService;
@property (nonatomic, readonly) id<HDUserServiceDelegate> userService;
@property (nonatomic, readonly) id<HDAppServiceDelegate> appService;

@property (nonatomic, assign,readonly) BOOL isLogined;
@property (nonatomic, strong) HDUserModel *currentUser;

+ (instancetype)sharedInstance;
- (BOOL)initialize;

@end
